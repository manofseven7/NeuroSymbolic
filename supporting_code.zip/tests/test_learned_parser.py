import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import learned_parser as l
import text_reasoner as t

class LearnedParserTests(unittest.TestCase):
    def test_teacher_roundtrip_negation_binary_and_ellipsis(self):
        for s in ['The bald eagle does not like the cat','If something is red and rough then it is not cold','Cold, smart things are red','All quiet things are rough','If Dave is smart and Dave is kind then Dave is quiet']:
            w,tags=l.teacher(s);self.assertEqual(l.decode(w,tags),t.sentence(s))
    def test_decoder_rejects_multiple_predicates(self):
        with self.assertRaises(t.ParseError):l.decode(['bob','cold','red'],['F.SUB','F.PRED','F.PRED'])
    def test_variable_fact_not_legal(self):
        with self.assertRaises(t.ParseError):l.decode(['something','cold'],['F.VAR','F.PRED'])
    def test_prediction_does_not_call_reference_parser(self):
        import numpy as np
        obj=l.Parser();obj.roles=np.array(['F.SUB','O','F.PRED']);obj.model.classes_=np.array([0,1,2])
        obj.distributions=lambda s:(['bob','is','red'],np.eye(3))
        original=t.sentence
        try:
            t.sentence=lambda s:(_ for _ in ()).throw(AssertionError('Reference parser called'))
            self.assertEqual(obj.predict('Bob is red'),('fact',(),('red','bob','',True)))
        finally:t.sentence=original

if __name__=='__main__':unittest.main()
