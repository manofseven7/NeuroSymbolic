import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import numpy as np
import search_recovered as s
import probe_program_actions as p

class ProgramTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.b=p.prepare(s.bank(1998))
    def test_program_risk_matches_scalar_sum(self):
        b=self.b;post=b['prior'];z,risk=p.program_decide(b,post)
        direct=[]
        for a in b['actions']:
            loss=((b['pred']!=a)*(1+.5*(b['pred']==b['pred'][0]))).mean(axis=1)
            direct.append(float(loss@post))
        self.assertAlmostEqual(risk,min(direct),places=12)
        self.assertTrue(any(np.array_equal(a,z) for a in b['pred']))
        self.assertGreaterEqual(risk+1e-12,s.decide(b,post)[1])
    def test_vector_program_voi_matches_scalar(self):
        b=self.b;post=b['prior'];Q=len(b['w'].queries);lk=np.zeros((Q,5,len(post)))
        for q,(kind,_) in enumerate(b['w'].queries):
            k=5 if kind=='anchor' else 3
            for o in range(k):lk[q,o]=(b['resp'][:,q]==o)
        scores=p.program_scores(b,post,b['nprior'],0.,'predictive_risk',[],lk)
        for q in [0,16,22]:
            v=p.program_decide(b,post)[1]
            for o in range(5):
                j=post*lk[q,o];mass=j.sum()
                if mass:v-=mass*p.program_decide(b,j/mass)[1]
            self.assertAlmostEqual(v,scores[q],places=12)
    def test_reconstructed_programs_execute_and_supports_replay(self):
        b=self.b
        for i in np.random.default_rng(3).choice(len(b['actions']),10,replace=False):
            counts=p.replay(b,b['actions'][i]);self.assertEqual(counts['invalid'],0);self.assertEqual(counts['predictions_checked'],32)

if __name__=='__main__':unittest.main()
