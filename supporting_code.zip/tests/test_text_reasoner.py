import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import text_reasoner as t
import text_pilot as p
import numpy as np

class TextTests(unittest.TestCase):
    def test_relational_chain_with_binding_and_multiword_entity(self):
        rr=t.parse('The bald eagle sees the cat. If someone sees the cat then they are cold. Cold people are blue.')
        q=t.atom('The bald eagle is blue');label,proof,_=t.run(rr,q)
        self.assertEqual(label,0);self.assertEqual(len(proof),3);self.assertTrue(t.verify(rr,q,label,proof))
    def test_explicit_negation_and_open_world(self):
        rr=t.parse('The cat does not like the dog. If something does not like the dog then it is not red.')
        q=t.atom('The cat is red');label,pf,_=t.run(rr,q);self.assertEqual(label,1);self.assertTrue(t.verify(rr,q,label,pf))
        self.assertEqual(t.run(rr,t.atom('The dog is red'))[0],2)
    def test_ellipsis_conjunction(self):
        rr=t.parse('Bob is cold. Bob is smart. If something is cold and smart then it is green.')
        self.assertEqual(t.run(rr,t.atom('Bob is green'))[0],0)
        self.assertEqual(t.run(rr[1:],t.atom('Bob is green'))[0],2)
    def test_tampered_proof_rejected(self):
        rr=t.parse('Bob is green. Green things are red.');q=t.atom('Bob is red');label,pf,_=t.run(rr,q)
        bad=[dict(n) for n in pf];bad[-1]['atom']=t.atom('Bob is cold');self.assertFalse(t.verify(rr,q,label,bad))
    def test_inconsistency_flag(self):
        rr=t.parse('Bob is red. Bob is not red.');self.assertEqual(t.run(rr,t.atom('Bob is red'))[0],3)
    def test_sentence_evidence_ignores_unqueried_gold_answer(self):
        rr=t.parse('Bob is not red. If something is red and cold then it is smart.');q=t.atom('Bob is red')
        programs,pred,resp,variants=p.build(rr,q)
        for policy in ['entropy','ec2','risk']:
            chosen,trace=p.episode(pred,resp,variants,(1,0,0),1,policy,0.,71)
            self.assertEqual(pred[chosen],1);self.assertEqual(len(trace),1)
    def test_program_bayes_loss_direct(self):
        post=np.array([.2,.3,.5]);pred=np.array([0,1,2]);a,r=p.decision(post,pred,0)
        costs=[sum(post[j]*(int(pred[i]!=pred[j])+.5*int(pred[i]!=pred[j] and pred[j]==0)) for j in range(3)) for i in range(3)]
        self.assertAlmostEqual(r,min(costs));self.assertEqual(a,int(np.argmin(costs)))

if __name__=='__main__':unittest.main()
