import itertools,random,unittest
import z3
from fol_certifier import parse,Compiler
from fol_model_reuse import family,parameterize,run
from fast_model_export import export_model as fast
from export_fol_evidence import export_model as slow
from finite_fol_model import verify_model
from analyze_fol_clarification import policy_values

class ReuseTests(unittest.TestCase):
 def test_strong_controls_identical(self):
  for k,q in [('P(a) ∨ Q(a)','P(a)'),('(P(a) ∨ Q(a)) ∧ P(a)','Q(a)'),('∀x (P(x) → Q(x)) ∧ P(a)','Q(a)'),('∃x P(x)','∀x P(x)'),('P(a) ∧ ¬P(a)','Q(a)'),('P(a)','Q(a)')]:
   answers=[run(parse(k),parse(q),m)['label'] for m in ['exhaustive','early_stop','selector_only','selector_model_reuse','branch_model_reuse']]
   self.assertEqual(len(set(answers)),1,(k,q,answers))
 def test_local_compilation_preserves_binding(self):
  k=parse('∀x ((P(x) ∨ Q(x)) → ∃y (R(x,y) ⊕ S(y)))');q=parse('P(a) ∨ Q(a)');sites,vs=family(k,q);c=Compiler();ss=[z3.Bool('s'+str(i)) for i in range(len(sites))]
  symbolic=parameterize(c,k,{p:i for i,(part,p) in enumerate(sites) if part=='k'},ss)
  for bits,a,b in vs:
   sol=z3.Solver();sol.add(*[s==bool(bit) for s,bit in zip(ss,bits)]);sol.add(symbolic!=c.compile(a));self.assertEqual(sol.check(),z3.unsat)
 def test_compiled_model_tables_match_solver_export(self):
  for kt,qt in [('∀x (P(x) → Q(x)) ∧ P(a)','Q(a)'),('∃x ∃y (R(x,y) ∧ ¬(x=y))','R(a,b)'),('P(a) ∨ Q(a)','Q(a)'),('a=b ∧ P(a)','P(b)')]:
   c=Compiler();k,q=parse(kt),parse(qt);kk,qq=c.compile(k),c.compile(q);s=z3.Solver();s.add(kk,qq);self.assertEqual(s.check(),z3.sat);m=s.model()
   a,b=slow(c,m),fast(c,m);self.assertEqual(a,b);self.assertTrue(verify_model(k,q,b,True))
 def test_witness_tampering_rejected(self):
  c=Compiler();k,q=parse('P(a)'),parse('P(a)');s=z3.Solver();s.add(c.compile(k),c.compile(q));s.check();m=fast(c,s.model());m['relations']['P']['true_tuples']=[];self.assertFalse(verify_model(k,q,m,True))
 def test_randomized_bounded_equivalence(self):
  rng=random.Random(20261028);atoms=['P(a)','Q(a)','R(a)','¬P(a)','¬Q(a)'];ops=['∨','⊕','∧','→']
  for _ in range(24):
   k=parse('('+rng.choice(atoms)+' '+rng.choice(ops)+' '+rng.choice(atoms)+') ∧ ('+rng.choice(atoms)+' '+rng.choice(ops)+' '+rng.choice(atoms)+')');q=parse(rng.choice(atoms))
   expected=run(k,q,'exhaustive')['label']
   for method in ['selector_only','selector_model_reuse','branch_model_reuse']:self.assertEqual(run(k,q,method)['label'],expected)
 def test_clarification_requires_only_relevant_bit(self):
  variants=[{'bits':bits,'label':'True' if bits[1] else 'False'} for bits in itertools.product((0,1),repeat=2)]
  self.assertEqual(policy_values(variants,1,'optimal_certificate'),1.0);self.assertEqual(policy_values(variants,1,'random'),.5)
