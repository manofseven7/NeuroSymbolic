"""Independent numerical and semantic audits of NS-DEEP-002."""
import json
from pathlib import Path
import sys
import unittest
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import deep_test as d

ROOT=Path(__file__).resolve().parents[1]
CFG=json.loads((ROOT/'configs/deep_test_v1.json').read_text())


class DeepNumerics(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.w=d.make_world(1000,CFG)

    def test_ec2_against_explicit_weighted_edges(self):
        self.assertLess(d.validate_scores()['maximum_absolute_error'],1e-12)

    def test_task_queries_do_not_include_heldout_contexts(self):
        w=self.w
        self.assertFalse(set(w.adapt)&set(w.test))
        self.assertEqual(len(w.test),16)
        self.assertTrue(all(q[1] in w.adapt for q in w.queries if q[0]=='task'))

    def test_direct_boolean_program_matches_forward_chaining(self):
        w=self.w;bits=list(d.itertools.product((0,1),repeat=3))
        for h,(mi,bi) in enumerate(w.states):
            b=bits[bi];spec=w.spec
            gate=list(spec['gate'])
            if b[0]:gate[0]=spec['replacement']
            tail=list(spec['tail'])+([spec['extra']] if b[1] else [])
            for j,raw in enumerate(w.contexts):
                semantic=[False]*5
                for i,value in enumerate(raw):semantic[w.mappings[mi][i]]=bool(value)
                main=all(semantic[i] for i in gate+tail)
                alt=(not b[2]) and all(semantic[i] for i in spec['alt']+spec['alt_tail'])
                expected=0 if main or alt else (1 if not any(semantic) else 2)
                self.assertEqual(w.predictions[h,j],expected)

    def test_vectorized_voi_matches_scalar_bayes_expectation(self):
        w=self.w;rng=np.random.default_rng(17)
        for noise in [0.,.1]:
            lk=d.likelihoods(w,noise)
            for policy in ['risk_voi','guarded_risk_voi']:
                p=rng.random(88);p/=p.sum()
                if policy=='guarded_risk_voi':
                    # Exercise both permissive and restrictive terminal action masks.
                    p[w.rules_changed]*=30;p/=p.sum()
                got=d.all_scores(w,p,lk,policy,CFG,noise)
                guard=policy=='guarded_risk_voi'
                base=d.terminal(w,p,CFG,guard)[1]
                expected=[]
                for q in range(len(w.queries)):
                    after=0.
                    for o in range(5):
                        joint=p*lk[q,o];pr=float(joint.sum())
                        if pr:after+=pr*d.terminal(w,joint/pr,CFG,guard)[1]
                    expected.append(base-after)
                np.testing.assert_allclose(got,expected,atol=1e-12)
                if not guard:self.assertGreaterEqual(float(got.min()),-1e-12)

    def test_outside_truth_is_behaviorally_outside_candidate_set(self):
        w=self.w
        self.assertFalse(any(np.array_equal(w.outside[2],v) for v in w.predictions))

    def test_loss_matrix_direct_value(self):
        w=self.w
        for a,h in [(0,1),(7,16),(30,77),(87,2)]:
            error=damage=0
            for j in range(32):
                wrong=w.predictions[a,j]!=w.predictions[h,j]
                error+=wrong
                damage+=wrong and w.predictions[0,j]==w.predictions[h,j]
            self.assertAlmostEqual(w.loss[a,h],(error+.5*damage)/32)

    def test_threshold_counterexample_is_a_real_objective_effect(self):
        w=self.w;p=np.zeros(88);p[0]=.03;p[1]=.97;lk=d.likelihoods(w,.1)
        guarded=d.all_scores(w,p,lk,'guarded_risk_voi',CFG,.1)
        ordinary=d.all_scores(w,p,lk,'risk_voi',CFG,.1)
        self.assertLess(guarded[2],-0.0009)
        self.assertGreaterEqual(ordinary[2],-1e-12)


if __name__=='__main__':unittest.main()
