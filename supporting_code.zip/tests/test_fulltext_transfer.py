import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import fulltext_transfer as f
import text_reasoner as t
from closure_certificate import certify_absence

class RawTransferTests(unittest.TestCase):
    def test_raw_fact_group_pronoun_and_rule_without_metadata(self):
        text='Bob is red. He is young. Harry is blue. He is round. Young, red people are cold.'
        records,info=f.parse_raw(text,['bob','harry'],['red','young','blue','round','cold'])
        y,pf,k=t.run(records,('cold','bob','',True));self.assertEqual(y,0);self.assertTrue(t.verify(records,('cold','bob','',True),0,pf))
    def test_multisentence_rule_fragment(self):
        r,_=f.parse_raw('Bob is red. Red people are young. They are also cold.',['bob'],['red','young','cold'])
        rules=[a for sid,s,a in r if a[0]=='rule'];self.assertEqual(rules[0][2][0],'cold');self.assertEqual(len(rules[0][1]),2)
    def test_absence_certificate_and_tampering(self):
        r=t.parse('Bob is red. Red things are cold.');q=('green','bob','',True);y,pf,k=t.run(r,q);self.assertTrue(certify_absence(r,q,k))
        bad=dict(k);bad.pop(('cold','bob','',True));self.assertFalse(certify_absence(r,q,bad))
    def test_no_reference_fields_required_for_name_induction(self):
        names=f.induce_names([{'theory':'Bob is red. Alan is blue. If red people are blue.'}]*10,['red','blue'])
        self.assertEqual(names,['alan','bob'])

if __name__=='__main__':unittest.main()
