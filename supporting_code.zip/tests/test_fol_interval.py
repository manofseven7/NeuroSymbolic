import random,unittest
import z3
from fol_certifier import parse,Compiler
from fol_model_reuse import family,run as exact
from fol_interval_certifier import bounds,run

class IntervalTests(unittest.TestCase):
 def test_bound_soundness_under_quantifiers_and_polarity(self):
  for text in ['∀x ((P(x) ∨ Q(x)) → ∃y (R(x,y) ⊕ S(y)))','¬(P(a) ∨ Q(a))','(P(a) ⊕ Q(a)) ↔ (R(a) ∨ S(a))','∃x (P(x) ∨ ¬Q(x))']:
   a=parse(text);q=parse('P(a)');sites,variants=family(a,q);c=Compiler();lo,hi=bounds(c,a,{p for part,p in sites if part=='k'})
   for _,v,_ in variants:
    f=c.compile(v)
    for bad in [z3.And(lo,z3.Not(f)),z3.And(f,z3.Not(hi))]:
     s=z3.Solver();s.set(timeout=1000);s.add(bad);self.assertEqual(s.check(),z3.unsat)
 def test_common_models_certify_unknown(self):
  got=run(parse('P(a) ∨ Q(a)'),parse('R(a)'));self.assertEqual(got['label'],'Uncertain');self.assertEqual(got['certificate_kind'],'two_common_models')
 def test_ambiguity_changes_answer(self):self.assertEqual(run(parse('(P(a) ∨ Q(a)) ∧ P(a)'),parse('Q(a)'))['label'],'Abstain')
 def test_random_equivalence(self):
  rng=random.Random(1414);atoms=['P(a)','Q(a)','R(a)','¬P(a)','¬Q(a)'];ops=['∨','⊕','∧','→','↔']
  for _ in range(40):
   k=parse('('+rng.choice(atoms)+' '+rng.choice(ops)+' '+rng.choice(atoms)+') ∧ ('+rng.choice(atoms)+' '+rng.choice(ops)+' '+rng.choice(atoms)+')');q=parse(rng.choice(atoms));self.assertEqual(run(k,q)['label'],exact(k,q,'exhaustive')['label'])
 def test_quantifier_choices_global_not_per_entity(self):
  k=parse('∀x (P(x) ∨ Q(x)) ∧ P(a) ∧ ¬P(b)');q=parse('Q(b)');self.assertEqual(run(k,q)['label'],exact(k,q,'exhaustive')['label'])
