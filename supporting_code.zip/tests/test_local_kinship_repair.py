import unittest
from local_kinship_repair import local_text
class LocalTests(unittest.TestCase):
 def test_irrelevant_append(self):
  s='[Alice] is the mother of [Bob].'
  self.assertEqual(local_text(s,('Alice','Bob')),local_text(s+' [Carl] is tall.',('Alice','Bob')))
 def test_direction(self):
  s='[Alice] is the mother of [Bob].'
  self.assertNotEqual(local_text(s,('Alice','Bob')),local_text(s,('Bob','Alice')))
 def test_delexicalize(self):
  s=local_text('[Alice] is the mother of [Bob].',('Alice','Bob'))
  self.assertNotIn('Alice',s);self.assertIn('SUBJECT',s);self.assertIn('OBJECT',s)
 def test_missing(self):self.assertEqual(local_text('[Alice] is tall.',('Alice','Bob')),'NO_LOCAL_PAIR')
