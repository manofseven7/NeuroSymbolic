import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import evaluate_learned_parser as e
import text_reasoner as t

class RepairTests(unittest.TestCase):
    def test_unqueried_interpretations_never_enter_bank(self):
        texts=['Bob is not red','Bob is red'];options=[[(t.sentence('Bob is red'),0.)],[(t.sentence('Bob is red'),0.)]]
        def forbidden(q):raise AssertionError('Oracle called without query budget')
        r=e.adapt(texts,options,[.1,.9],'risk',0,16,forbidden)
        self.assertEqual(r['prediction'],0);self.assertEqual(r['novel'],0)
    def test_query_admits_missing_interpretation(self):
        texts=['Bob is not red','Bob is red'];options=[[(t.sentence('Bob is red'),0.)],[(t.sentence('Bob is red'),0.)]];calls=[]
        def oracle(q):calls.append(q);return t.sentence(texts[q])
        r=e.adapt(texts,options,[.1,.9],'risk',1,16,oracle)
        self.assertEqual(calls,[0]);self.assertEqual(r['prediction'],1);self.assertEqual(r['novel'],1)
        self.assertTrue(t.verify(r['records'],r['query'],1,r['proof']))
    def test_missing_parse_is_abstention_not_unknown(self):
        r=e.adapt(['Bob is red','Bob is cold'],[[],[(t.sentence('Bob is cold'),0.)]],[.1,.9],'risk',0,16,lambda q:None)
        self.assertEqual(r['prediction'],4);self.assertFalse(r['complete'])

if __name__=='__main__':unittest.main()
