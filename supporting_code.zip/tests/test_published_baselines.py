"""Audit the comparison protocol without importing the GPU model."""
import ast
import json
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'results/published_baselines_v1/payload'

class ProtocolAudit(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        tree = ast.parse((ROOT/'src/run_published_llm_baselines_corrected.py').read_text())
        keep = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in
                ['norm_answer', 'chain', 'faithful_answer', 'htt_answer', 'htt_text_answer']]
        keep += [n for n in tree.body if isinstance(n, ast.Assign) and
                 any(isinstance(t, ast.Name) and t.id in ['LABELS', 'LABEL_PATTERN'] for t in n.targets)]
        # Assignments precede calls; function bodies resolve their globals at call time.
        cls.ns = {'ast': ast, 're': re}
        exec(compile(ast.Module(body=keep, type_ignores=[]), '<audited functions>', 'exec'), cls.ns)

    def test_no_test_annotations(self):
        rows = json.loads((DATA/'test_inputs.json').read_text())
        self.assertEqual(len(rows), 1026)
        self.assertEqual(len({r['id'] for r in rows}), 1026)
        for r in rows:
            self.assertTrue(set(r).isdisjoint({'gold', 'target', 'target_text', 'proof_state', 'genders'}))

    def test_label_boundaries(self):
        norm = self.ns['norm_answer']
        self.assertEqual(norm('Final Answer: great-grandfather.'), '__INVALID__')
        self.assertEqual(norm('Therefore, the answer is mother-in-law.'), 'mother-in-law')

    def test_demonstrations_have_method_steps(self):
        row = json.loads((DATA/'train_42.json').read_text())[0]
        faithful = self.ns['faithful_answer'](row)
        self.assertIn('# 1. How is', faithful)
        self.assertIn('(independent)', faithful)
        self.assertIn(' = ', faithful)
        self.assertIn(' @ ', faithful)
        htt = self.ns['htt_text_answer'](row)
        self.assertIn('path', htt.lower())
        self.assertIn('Therefore, the answer is', htt)

    def test_epignn_inference_target_mask(self):
        source = (ROOT/'src/run_published_epignn.py').read_text()
        tree = ast.parse(source)
        fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'make_data')
        import torch
        from torch_geometric.data import HeteroData
        labels = self.ns['LABELS']
        ns = {'torch': torch, 'HeteroData': HeteroData, 'INDEX': {x:i for i,x in enumerate(labels)}}
        exec(compile(ast.Module(body=[fn], type_ignores=[]), '<target mask>', 'exec'), ns)
        g = {'edges': [[0,1,'mother'],[1,2,'son']], 'query':[0,2], 'target':'daughter'}
        a = ns['make_data'](g)
        b = ns['make_data']({**g, 'target':'uncle'})
        self.assertEqual(a['fw','rel','fw'].target_edge_type.tolist(), [0])
        self.assertTrue(torch.equal(a['fw','rel','fw'].target_edge_type, b['fw','rel','fw'].target_edge_type))

if __name__ == '__main__':
    unittest.main()
