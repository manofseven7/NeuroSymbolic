import unittest
import external_kinship as k
from consistent_kinship import local_pairs,PAIRS,TYPE,INVERSE,SEX,generalized_rules
class ConsistencyTests(unittest.TestCase):
 def test_inverse_types_are_involutions(self):
  for t,inv in INVERSE.items():self.assertEqual(INVERSE[inv],t)
 def test_entity_pairs_require_local_evidence(self):
  p=local_pairs('[A] is the father of [B]. [C] is the mother of [D].')
  self.assertIn(('A','B'),p);self.assertIn(('B','A'),p);self.assertNotIn(('A','C'),p)
 def test_ten_hop_composition_and_proof(self):
  facts={(str(i),str(i+1)):('brother',.9,i) for i in range(10)};rules=[('brother','brother','brother')]
  ex=k.execute(facts,('0','10'),rules)
  self.assertEqual(ex['preferred'],'brother');self.assertTrue(k.verify_proof(ex['proof'],facts,rules));self.assertEqual(len(ex['proof']['support']),10)
 def test_generalization_preserves_target_gender(self):
  r={'proof_state':"[{('A', 'grandfather', 'C'): [('A', 'father', 'B'), ('B', 'father', 'C')]}]"}
  rules,info=generalized_rules([r]);self.assertIn(('mother','mother','grandmother'),rules)
  for a,b,c in rules:self.assertEqual(SEX[b],SEX[c])
