import unittest
import text_reasoner as t
from text_certificate import gate,audit_fol
class TextCertificateTests(unittest.TestCase):
 def options(self,ss):return [[(t.sentence(s),0.)] for s in ss]
 def test_explicit_negation_embedding(self):
  rr=[('s1','Bob is not red',t.sentence('Bob is not red'))];q=t.atom('Bob is red');self.assertTrue(audit_fol(rr,q)['valid']);self.assertEqual(audit_fol(rr,q)['prediction'],1)
 def test_no_contraposition(self):
  rr=[('s1','Bob is not blue',t.sentence('Bob is not blue')),('s2','rule',t.sentence('If someone is red then they are blue'))];self.assertEqual(audit_fol(rr,t.atom('Bob is red'))['prediction'],2)
 def test_positive_and_negative_are_independent(self):
  rr=[('s1','pos',t.sentence('Bob is red')),('s2','neg',t.sentence('Bob is not red'))];self.assertEqual(audit_fol(rr,t.atom('Bob is red'))['prediction'],3)
 def test_family_abstains_when_meaning_changes_answer(self):
  ss=['Bob is red','Bob is blue'];oo=self.options(ss);oo[0].append((t.sentence('Bob is blue'),-1));got=gate(ss,oo);self.assertEqual(got['prediction'],4)
 def test_unused_ambiguity_does_not_block(self):
  ss=['Bob is red','Alice is blue','Bob is red'];oo=self.options(ss);oo[1].append((t.sentence('Alice is green'),-1));got=gate(ss,oo);self.assertEqual(got['prediction'],0)
 def test_unknown_is_not_abstention(self):
  ss=['Bob is red','Bob is blue'];self.assertEqual(gate(ss,self.options(ss))['prediction'],2)
 def test_missing_program_abstains(self):self.assertEqual(gate(['Bob is red'],[[]])['prediction'],4)
