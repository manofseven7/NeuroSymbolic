import unittest
import external_kinship as k
class ExternalKinshipTests(unittest.TestCase):
 def setUp(self):
  self.f={('A','B'):('mother',.9,0),('B','C'):('father',.9,1)};self.rs=[('mother','father','grandfather')]
 def test_composition_and_replay(self):
  x=k.execute(self.f,('A','C'),self.rs);self.assertEqual(x['preferred'],'grandfather');self.assertTrue(k.verify_proof(x['proof'],self.f,self.rs))
 def test_tampered_rule_is_rejected(self):
  x=k.execute(self.f,('A','C'),self.rs);x['proof']['atom'][1]='grandmother';self.assertFalse(k.verify_proof(x['proof'],self.f,self.rs))
 def test_no_rule_no_inferred_edge(self):self.assertEqual(k.execute(self.f,('A','C'),[])['relations'],[])
 def test_ordered_endpoints(self):self.assertEqual(k.execute(self.f,('C','A'),self.rs)['relations'],[])
 def test_no_evaluation_metadata_in_frontend(self):
  a=k.pair_text('[Alice] met [Bob] with [Carol].',('Alice','Carol'));self.assertNotIn('Alice',a);self.assertIn('SUBJECT',a);self.assertIn('OBJECT',a)
 def test_schema_gender_constraint(self):
  self.assertTrue(k.valid_schema(self.rs[0]));self.assertFalse(k.valid_schema(('mother','father','grandmother')))
 def test_family_disagreement_and_two_semantic_corrections(self):
  p={'story':'','query':('A','C'),'pairs':[('A','B'),('B','C')],'options':[[('mother',.9),(k.NONE,.1)],[('father',.9),(k.NONE,.1)]]}
  self.assertFalse(k.family(p,self.rs)['certified']);x=k.correct(p,self.rs,lambda pair:self.f[pair][0]);self.assertTrue(x['certified']);self.assertEqual(len(x['annotations']),2)
 def test_support_sufficient_and_deletion(self):
  x=k.execute(self.f,('A','C'),self.rs);x.update(facts=self.f);a=k.proof_interventions(x,('A','C'),self.rs);self.assertTrue(a['proof_valid']);self.assertTrue(a['support_sufficient']);self.assertTrue(a['support_set_deletion_removes']);self.assertTrue(a['individual_rule_deletions'][0]['removes_conclusion'])
 def test_alternative_support_not_forced_necessary(self):
  f={**self.f,('A','D'):('mother',.8,2),('D','C'):('father',.8,3)};x=k.execute(f,('A','C'),self.rs);x.update(facts=f);self.assertFalse(k.proof_interventions(x,('A','C'),self.rs)['support_set_deletion_removes'])
 def test_upper_path_budget_reports_unresolved(self):
  f={('A','B'):('mother',1.,0),('B','C'):('father',1.,1),('A','D'):('mother',1.,2),('D','C'):('father',1.,3)};self.assertTrue(k.execute(f,('A','C'),self.rs,path_limit=1)['limited'])
 def test_must_may_equals_exhaustive_candidate_decision(self):
  import itertools,random
  rng=random.Random(20)
  for _ in range(40):
   pairs=[('A','B'),('B','C'),('A','D'),('D','C')];opts=[]
   for j in range(4):
    rel='mother' if j%2==0 else 'father';opts.append([(rel,.8),(k.NONE,.2)] if rng.random()<.7 else [(rel,.8),(rel,.2)])
   p={'story':'','query':('A','C'),'pairs':pairs,'options':opts};g=k.family(p,self.rs);sets=[]
   for bits in itertools.product([0,1],repeat=len(g['vary'])):sets.append(tuple(k.execute(k.selected_facts(p,dict(zip(g['vary'],bits))),p['query'],self.rs)['relations']))
   expected=len(set(sets))==1 and len(sets[0])==1;self.assertEqual(g['certified'],expected)
if __name__=='__main__':unittest.main()
