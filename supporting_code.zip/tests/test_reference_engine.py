"""Independent semantic tests for an exact scientific reference engine."""
import itertools
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import preflight as p


class Semantics(unittest.TestCase):
    def test_forward_reasoner_against_direct_boolean_specification(self):
        for mapping,bits in p.HYPOTHESES:
            for raw in p.CONTEXTS:
                semantic=[False]*4
                for i,value in enumerate(raw):semantic[mapping[i]]=bool(value)
                a=2 if bits[0] else 0
                needed=semantic[a] and semantic[1]
                if bits[1]:needed=needed and semantic[0 if a==2 else 2]
                positive=bool(needed or (bits[2] and semantic[3]))
                negative=not semantic[a] and not semantic[1] and not semantic[3]
                expected='entailment' if positive else ('contradiction' if negative else 'unknown')
                self.assertEqual(p.execute(raw,mapping,bits),expected)

    def test_compensating_grounding_and_rule_changes(self):
        rule_only=((0,1,2,3),(1,0,0))
        grounding_only=((2,0,1,3),(0,0,0))
        for raw in p.CONTEXTS:
            self.assertEqual(p.execute(raw,*rule_only),p.execute(raw,*grounding_only))
        self.assertNotEqual(p.answer(p.HYPOTHESES.index(rule_only),('anchor',0,2)),
                            p.answer(p.HYPOTHESES.index(grounding_only),('anchor',0,2)))

    def test_faithfulness_with_redundant_evidence(self):
        r=(p.Rule('a',('p0',),'approve'),p.Rule('b',('p1',),'approve'))
        self.assertEqual(p.label(p.closure({'p0','p1'},r,frozenset({'a'}))),'entailment')
        self.assertEqual(p.label(p.closure({'p0','p1'},r,frozenset({'a','b'}))),'unknown')

    def test_no_explosion_from_inconsistency(self):
        known=p.closure({'approve','!approve'},tuple())
        self.assertEqual(p.label(known),'INCONSISTENT')
        self.assertNotIn('unrelated',known)


if __name__=='__main__':unittest.main()
