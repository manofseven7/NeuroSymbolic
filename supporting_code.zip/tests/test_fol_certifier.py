import unittest
from fol_certifier import *

class FOLTests(unittest.TestCase):
 def answer(self,k,q):return solve(parse(k),parse(q),timeout_ms=1000)['label']
 def test_contraposition(self):self.assertEqual(self.answer('∀x (P(x) → Q(x)) ∧ ¬Q(a)','¬P(a)'),'True')
 def test_open_world(self):self.assertEqual(self.answer('P(a)','Q(a)'),'Uncertain')
 def test_explicit_negative(self):self.assertEqual(self.answer('¬Q(a)','Q(a)'),'False')
 def test_existential(self):self.assertEqual(self.answer('∃x (P(x) ∧ Q(x))','∃y Q(y)'),'True')
 def test_no_unique_names(self):self.assertEqual(self.answer('P(a)','a = b'),'Uncertain')
 def test_equality(self):self.assertEqual(self.answer('P(a) ∧ a = b','P(b)'),'True')
 def test_inconsistent_rejected(self):self.assertEqual(self.answer('P(a) ∧ ¬P(a)','Q(a)'),'Inconsistent')
 def test_scope(self):self.assertEqual(self.answer('∀x P(x) ∧ Q(a)','Q(a)'),'True')
 def test_full_input(self):
  with self.assertRaises(FOLParseError):parse('P(a) junk')
 def test_free_variable(self):
  with self.assertRaises(FOLParseError):solve(parse('P(x)'),parse('P(a)'))
 def test_operator_family(self):
  a=parse('(P(a) ∨ Q(a)) ∧ P(a)');paths=ambiguity_paths(a);self.assertEqual(len(paths),1)
  b=replace_ops(a,{paths[0]:'⊕'});r=[solve(v,parse('Q(a)')) for v in [a,b]]
  self.assertEqual([x['label'] for x in r],['Uncertain','False']);self.assertFalse(certify(r)['certified'])
 def test_unknown_blocks_certification(self):self.assertFalse(certify([{'label':'True'},{'label':'SolverUnknown'}])['certified'])
 def test_arity_conflict(self):
  with self.assertRaises(FOLParseError):solve(parse('P(a) ∧ P(a,b)'),parse('Q(a)'))

 def test_unicode_constant(self):self.assertEqual(self.answer('Won(świątek, year2022)','Won(świątek, year2022)'),'True')
