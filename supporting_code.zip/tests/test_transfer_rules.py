import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import prepare_transfer as d
import transfer_rules as x

class TransferTests(unittest.TestCase):
    def test_metadata_unary_and_variable(self):
        a=d.literals('("Bob" "is" "red" "+")');self.assertEqual(a,[('red','bob','',True)])
        a=d.canonical_rule({'representation':'((("someone" "is" "red" "+") ("someone" "is" "cold" "+")) -> ("someone" "is" "young" "+"))'})
        self.assertEqual(a[2],('young','?x','',True));self.assertEqual(len(a[1]),2)
    def test_naf_not_silently_explicit_negation(self):
        with self.assertRaises(ValueError):d.literals('("Bob" "is" "red" "~")')
    def test_cwa_answer_is_distinct_from_explicit_negative_proof(self):
        facts=[('fact',(),('red','bob','',True))]
        answer,pf,rr,q,present=x.infer(facts,[],[],('cold','bob','',False))
        self.assertTrue(answer);self.assertFalse(present);self.assertFalse(pf)
    def test_negative_query_refuted_by_positive_derivation(self):
        facts=[('fact',(),('red','bob','',True))];rule=('rule',(('red','?x','',True),),('cold','?x','',True))
        answer,pf,rr,q,present=x.infer(facts,['red implies cold'],[rule],('cold','bob','',False))
        self.assertFalse(answer);self.assertTrue(present);self.assertEqual(len(pf),2)
    def test_body_order_canonicalization(self):
        a=('rule',[['red','?x','',True],['cold','?x','',True]],['young','?x','',True]);b=('rule',(('cold','?x','',True),('red','?x','',True)),('young','?x','',True))
        self.assertEqual(d.normalized(a),d.normalized(b))

if __name__=='__main__':unittest.main()
