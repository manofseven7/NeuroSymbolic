import sys,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from analyze_available_baselines import aligned,paired_interval

def row(i='a',seed=42,pred='son',gold='son'):
    return {'id':i,'seed':seed,'hops':4,'prediction':pred,'gold':gold,'correct':int(pred==gold)}

class AvailableScopeAudit(unittest.TestCase):
    def test_missing_story_rejected(self):
        with self.assertRaises(AssertionError):aligned([row()],[row(),row('b')])
    def test_duplicate_rejected(self):
        with self.assertRaises(AssertionError):aligned([row(),row()],[row()])
    def test_changed_gold_rejected(self):
        with self.assertRaises(AssertionError):aligned([row(gold='daughter')],[row()])
    def test_other_seed_cannot_be_substituted(self):
        with self.assertRaises(AssertionError):aligned([row(seed=43)],[row(seed=42)])
    def test_uniform_paired_gain(self):
        ours=[row(i,s) for i in ['a','b'] for s in [42,43,44]]
        base=[row(i,s,pred='daughter') for i in ['a','b'] for s in [42,43,44]]
        result=paired_interval(base,ours)
        self.assertEqual((result['ours_minus_baseline_pp'],result['ci95_low'],result['ci95_high']),(100.,100.,100.))

if __name__=='__main__':unittest.main()
