import sys, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import numpy as np
import search_recovered as s

class SearchTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.b=s.bank(1999)
    def test_priors_and_raw_permutation(self):
        b=self.b
        self.assertAlmostEqual(b['prior'].sum(),1.)
        self.assertAlmostEqual(b['nprior'].sum(),1.)
        # independent direct semantics for original source and single transposition
        w=b['w'];m=w.mappings[1]
        direct=np.array([s.d.evaluate(x,m,w.programs[0]) for x in w.contexts])
        self.assertTrue(any(np.array_equal(p,direct) for p in b['pred']))
        self.assertTrue(np.all(b['pred'][0]==w.predictions[0]))
    def test_truth_in_wide_family_except_exception(self):
        for case in s.CASES[:6]:
            y,_=s.truth(self.b,case)
            self.assertTrue(np.any(np.all(self.b['pred']==y,axis=1)),case)
    def test_certificates_sound_in_clean_monotone_family(self):
        b=self.b;rng=np.random.default_rng(41)
        for i in rng.choice(len(b['pred']),30,replace=False):
            y=b['pred'][i];obs=[]
            for x in rng.permutation(32)[:8]:
                obs.append((int(x),int(y[x])));z,bad=s.cert(obs,b['sub'])
                self.assertFalse(bad);self.assertTrue(np.all(y[z>=0]==z[z>=0]))
    def test_marginals(self):
        b=self.b;p=b['prior'];m=s.marginal(b,p)
        for k in range(3):np.testing.assert_allclose(m[k],((b['pred']==k)*p[:,None]).sum(axis=0),atol=1e-12)
    def test_risk_scores_against_scalar_bayes_branches(self):
        b=self.b;p=b['prior'];noise=.1;Q=len(b['w'].queries);lk=np.zeros((Q,5,len(p)))
        for q,(kind,_) in enumerate(b['w'].queries):
            k=5 if kind=='anchor' else 3
            for o in range(k):lk[q,o]=np.where(b['resp'][:,q]==o,1-noise,noise/(k-1))
        score=s.scores(b,p,b['nprior'],noise,'predictive_risk',[],lk)
        for q in (0,7,16,23):
            want=s.decide(b,p)[1]
            for o in range(5):
                joint=p*lk[q,o];mass=joint.sum()
                if mass:want-=mass*s.decide(b,joint/mass)[1]
            self.assertAlmostEqual(score[q],want,places=11)
    def test_no_heldout_task_query_and_no_seed_reuse(self):
        b=self.b;w=b['w']
        self.assertFalse(set(w.adapt)&set(w.test))
        self.assertTrue(all(i in w.adapt for kind,i in w.queries if kind=='task'))
        import json
        cfg=json.loads((Path(__file__).resolve().parents[1]/'configs/search_recovered.json').read_text())
        self.assertFalse(set(cfg['development_seeds'])&set(cfg['confirmation_seeds']))
    def test_order_violation_detected(self):
        b=self.b;z,bad=s.cert([(0,0),(31,2)],b['sub']);self.assertTrue(bad)

if __name__=='__main__':unittest.main()
