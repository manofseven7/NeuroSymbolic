"""Usable neural-text inference with a separate interpretation-certificate status."""
import argparse,json
from pathlib import Path
import joblib
from text_certificate import infer,explanation,LABELS
ROOT=Path(__file__).resolve().parents[1]
def main():
 p=argparse.ArgumentParser();p.add_argument('--context-file',type=Path,required=True);p.add_argument('--statement',required=True);a=p.parse_args()
 model=joblib.load(ROOT/'results/learned_parser_v1/mlp64.joblib');r=infer(model,a.context_file.read_text(),a.statement)
 y=r.get('top1',4);out={'prediction':LABELS[y],'certificate_status':'certified_over_retained_programs' if r['prediction']!=4 else 'uncertified','certified_answer':LABELS[r['prediction']],'retained_programs':r['bank_size'],'scope':'Controlled English; certificate conditional on retained candidate set containing intended interpretation.'}
 if y!=4:
  chosen=dict(r,prediction=y)
  import text_reasoner as t
  chosen['proof']=t.run(r['records'],r['query'])[1];out['selected_program_explanation']=explanation(chosen)
  out['selected_program_explanation']['family_certificate']=r['certificate'] if r['prediction']!=4 else None
  if r['prediction']==4:out['selected_program_explanation']['proof_scope']='Selected-program proof only; no family-wide certificate was issued.'
 print(json.dumps(out,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
