"""New fixed-design holdout after a stronger lexical baseline was discovered.

The neural component ranks where to request semantic correction; the base
program uses the last-attribute prior. No outcome-driven changes in this run.
"""
import csv,hashlib,json,re,time
from pathlib import Path
import joblib,numpy as np
import transfer_rules as x
from prepare_transfer import normalized

def lexical(text,vocab):
    ws=[w for w in re.findall('[a-z]+',text.lower()) if w in vocab];attrs=set(ws)
    if len(attrs)<2:return None
    head=ws[-1];return ('rule',tuple((b,'?x','',True) for b in sorted(attrs-{head})),(head,'?x','',True))

def scores(options,base):
    entropy=-sum(p*np.log(max(p,1e-12)) for ast,p in options)/np.log(len(options)) if len(options)>1 else 1.
    probability=sum(p for ast,p in options if base is not None and normalized(ast)==normalized(base))
    return float(entropy),float(1-probability)

def main():
    cfg=json.loads(Path('configs/transfer_committee_v1.json').read_text());root=Path('results/transfer_v1');out=Path('results/transfer_committee_v1');out.mkdir(exist_ok=False);start=time.time();data=json.loads((root/'prepared.json').read_text());held=[r for r in data['train'] if r['id'] in cfg['confirmation_ids']];labels=json.loads((root/'target_labels.json').read_text());used={v['text'] for a in labels.values() for v in a};assert all(not(set(r['units'])&used) for r in held)
    vocab=set(json.loads((root/'data_audit.json').read_text())['selected']['vocabulary']);old=json.loads(Path('results/learned_parser_v1/selection.json').read_text());models={'source':joblib.load(Path('results/learned_parser_v1')/(old['selected']+'.joblib')),'adapted':joblib.load(root/'adapted.joblib')};cache={};rows=[];traces=[];checks=dict(derived_literal_proofs=0,invalid=0,reference_aligned=0,certified=0,certified_disagreements=0,absence_cases=0)
    for ti,r in enumerate(held):
        units=r['units'];base=[lexical(s,vocab) for s in units];gold=[x.asttuple(a) for a in r['rule_gold']];cond=[('lexical','none',0,0,[])]
        for budget in [1,2]:
            for seed in cfg['random_seeds']:cond.append(('lexical','random',budget,seed,list(map(int,np.random.default_rng(seed+ti*100).permutation(len(units))[:budget]))))
        for name,model in models.items():
            ss=[]
            for s,a in zip(units,base):
                key=(name,s)
                if key not in cache:cache[key]=x.choices(model,s,vocab)
                ss.append(scores(cache[key],a))
            for pi,policy in enumerate(['neural_entropy','neural_disagreement']):
                order=sorted(range(len(units)),key=lambda j:(-ss[j][pi],j))
                for budget in [1,2]:cond.append((name,policy,budget,0,order[:budget]))
        for name,policy,budget,seed,indices in cond:
            chosen=list(base);admitted=[]
            for j in indices:
                if r['annotation_available'][j]:chosen[j]=gold[j];admitted.append(j)
            full=all(a is not None and normalized(a)==normalized(b) for a,b in zip(chosen,gold));traces.append(dict(theory_id=r['id'],model=name,policy=policy,budget=budget,seed=seed,queries=indices,admitted=admitted,chosen_rules=chosen,full_rule_reference_exact=full))
            for q in r['questions']:
                answer,pf,rr,positive,present=x.infer(r['facts'],units,chosen,q['query']);rows.append(dict(theory_id=r['id'],question_id=q['id'],model=name,policy=policy,budget=budget,seed=seed,correct=int(answer==q['answer']),prediction=int(answer),gold=int(q['answer']),full_rule_reference_exact=int(full),spent=len(indices)))
                if name=='adapted' and policy=='neural_disagreement' and budget==2:
                    if present:
                        valid=x.t.verify(rr,positive,0,pf);used_rules={int(n['id'][1:]) for n in pf if n['id'].startswith('r')};aligned=all(chosen[j] is not None and normalized(chosen[j])==normalized(gold[j]) for j in used_rules);certified=used_rules<=set(admitted)
                        checks['derived_literal_proofs']+=1;checks['invalid']+=not valid;checks['reference_aligned']+=aligned;checks['certified']+=certified;checks['certified_disagreements']+=certified and not aligned
                    else:checks['absence_cases']+=1
        if (ti+1)%100==0:print('fresh holdout theories',ti+1,flush=True)
    with (out/'episodes.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    with (out/'traces.jsonl').open('w') as f:
        for r in traces:f.write(json.dumps(r)+'\n')
    (out/'proof_checks.json').write_text(json.dumps(checks,indent=2));(out/'execution.json').write_text(json.dumps(dict(theories=len(held),unique_questions=sum(len(r['questions']) for r in held),question_policy_rows=len(rows),seconds=time.time()-start,code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope=cfg['scope']),indent=2));print(checks)

if __name__=='__main__':main()
