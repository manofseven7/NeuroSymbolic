"""Reproduce clean-proof, fixed-grammar portability and trace audits."""
import collections,json
from pathlib import Path
import text_reasoner as t
import text_pilot as p

def main():
    out=Path('results/text_pilot_v1');rows=json.loads(Path('third_party/LogicLM_ProofWriter/test.json').read_text())
    counts=collections.Counter();depths=collections.Counter();proofs=invalid=0
    for r in rows:
        rr=t.parse(r['context']);q=t.query(r['question']);y,pf,known=t.run(rr,q);counts[y]+=1
        if y in [0,1]:
            proofs+=1;invalid+=not t.verify(rr,q,y,pf);dd={}
            for node in pf:dd[tuple(node['atom'])]=0 if node['kind']=='fact' else 1+max(dd[tuple(v)] for v in node['parents'])
            depths[max(dd.values())]+=1
    (out/'clean_proof_audit.json').write_text(json.dumps(dict(records=len(rows),label_counts=dict(counts),proofs=proofs,invalid=invalid,executed_proof_depth=dict(depths),depth_note='Depth of chosen computed proof, not a matched gold proof; source subset is depth5 theories, not exclusively five-hop questions.'),indent=2))
    folio=Path('third_party/FOLIO_legacy/data/v0.0/folio-validation.jsonl');fr=[json.loads(x) for x in folio.read_text().splitlines()];n=0;errors=collections.Counter()
    for r in fr:
        context=' '.join(r['premises']) if isinstance(r['premises'],list) else r['premises']
        try:t.parse(context);t.atom(r['conclusion']);n+=1
        except t.ParseError as e:errors[str(e).split(':')[0]]+=1
    (out/'folio_portability.json').write_text(json.dumps(dict(status='exploratory portability stress; not model selection',records=len(fr),fully_parseable=n,parse_failure_counts=dict(errors),source='pinned legacy v0.0, not corrected gated release',gold_FOL_used=False,limitations='No accuracy claimed from unknown fallback; grammar was designed for controlled English and not adapted using this stress.'),indent=2))
    traces=[json.loads(x) for x in (out/'traces.jsonl').read_text().splitlines()]
    for r in traces:
        qs=r['semantic_queries'];m=r['metrics'];assert len(qs)<=m['budget'];assert len({q for q,o in qs})==len(qs);assert len(qs)==m['spent'];assert m['policy']!='static' or not qs
    checked=0
    for i in [0,599]:
        r=rows[i];programs,pred,resp,variants=p.build(t.parse(r['context']),t.query(r['question']))
        for noise in [0.,.1]:
            chosen,trace=p.episode(pred,resp,variants,(1,1,1),2,'risk',noise,i*100+3)
            saved=next(x for x in traces if x['metrics']['id']==r['id'] and x['metrics']['case']=='joint_fault' and x['metrics']['noise']==noise and x['metrics']['budget']==2 and x['metrics']['policy']=='risk')
            assert chosen==saved['metrics']['selected'] and trace==saved['semantic_queries'];checked+=1
    result=dict(traces_checked=len(traces),per_policy=dict(collections.Counter(r['metrics']['policy'] for r in traces)),budget_and_no_repeated_query_checks='PASS',target_label_query_api='No question-answer oracle exists in selector; external gold answer used only for metrics.',convergence_warning='MLP reached fixed maximum 200 iterations without convergence in recorded run; not retuned on test.',exact_episode_replay=checked)
    (out/'verification.json').write_text(json.dumps(result,indent=2));print(dict(clean_proofs=proofs,invalid=invalid,fully_parseable_folio=n,trace_verification=result))

if __name__=='__main__':main()
