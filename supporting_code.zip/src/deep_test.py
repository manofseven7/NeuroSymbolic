"""Equal-budget, held-out symbolic repair benchmark and failure tests.

Guarded VOI is an engineering candidate built on classical decision-theoretic
VOI, not a novel algorithm claim. Deterministic EC2 scores are tested against
explicit edge enumeration; the noisy extension is only a posterior surrogate.
"""
from __future__ import annotations
import argparse
from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import itertools
import json
import math
import os
from pathlib import Path
import resource
import time
import numpy as np
from preflight import Rule, closure, proof_supports

LABELS={'entailment':0,'contradiction':1,'unknown':2,'INCONSISTENT':3}


def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def evidence_entropy(p):
    return float(-(p*np.log2(np.maximum(p,1e-300))).sum())


def signed_label(known):
    pos,neg='approve' in known,'!approve' in known
    return 3 if pos and neg else (0 if pos else (1 if neg else 2))


def facts(x,m):return {('' if v else '!')+f'p{m[i]}' for i,v in enumerate(x)}


def rules_for(spec,bits):
    gate=list(spec['gate'])
    if bits[0]:gate[0]=spec['replacement']
    tail=list(spec['tail'])+([spec['extra']] if bits[1] else [])
    rs=[Rule('gate',tuple('p'+str(i) for i in gate),'mid0'),
        Rule('out',('mid0',)+tuple('p'+str(i) for i in tail),'approve'),
        Rule('alt_gate',tuple('p'+str(i) for i in spec['alt']),'mid1'),
        Rule('reject',tuple('!p'+str(i) for i in range(5)),'!approve')]
    if not bits[2]:rs.append(Rule('alt_out',('mid1',)+tuple('p'+str(i) for i in spec['alt_tail']),'approve'))
    return tuple(rs)


def evaluate(x,m,rs):return signed_label(closure(facts(x,m),rs))


def fault(m,b):
    g=m!=tuple(range(5));r=any(b)
    return int(g)+2*int(r)  # none=0, grounding=1, rules=2, both=3


def ec_edges(p,classes):
    mass=np.bincount(classes,weights=p,minlength=int(max(classes))+1)
    return float((p.sum()**2-(mass**2).sum())/2)


def ec_score(p,classes,response,cost=1):
    """Noiseless EC2 gain. Current posterior weights rescale original live
    weights by one common factor; this does not change the query argmax.
    Branch edge masses are UNNORMALIZED, not posterior gini.
    """
    current=ec_edges(p,classes)
    remain=0.
    for o in np.unique(response):
        joint=p*(response==o)
        remain+=joint.sum()*ec_edges(joint,classes)
    return (current-remain)/cost


def validate_scores():
    rng=np.random.default_rng(812)
    maximum=0.
    for n in range(2,11):
        for _ in range(20):
            p=rng.random(n);p/=p.sum();c=rng.integers(0,3,n);ans=rng.integers(0,3,n)
            direct=0.
            for h in range(n):
                cut=sum(p[i]*p[j] for i in range(n) for j in range(i+1,n)
                        if c[i]!=c[j] and (ans[i]!=ans[h] or ans[j]!=ans[h]))
                direct+=p[h]*cut
            maximum=max(maximum,abs(direct-ec_score(p,c,ans)))
    assert maximum<1e-12
    # Bayes action expected loss equals brute-force sum; guard masks do not use truth.
    return {'ec2_direct_edge_cases':180,'maximum_absolute_error':maximum}


@dataclass
class World:
    seed:int
    spec:dict
    mappings:list
    states:list
    programs:list
    contexts:list
    adapt:list
    test:list
    queries:list
    responses:np.ndarray
    predictions:np.ndarray
    prior:np.ndarray
    classes:np.ndarray
    behavior:np.ndarray
    loss:np.ndarray
    edit:np.ndarray
    mapping_changed:np.ndarray
    rules_changed:np.ndarray
    truths:list
    outside:tuple


def make_world(seed,cfg):
    rng=np.random.default_rng(seed)
    a=list(map(int,rng.permutation(5)))
    gate=a[:int(rng.integers(1,3))]
    unused=[i for i in a if i not in gate]
    tail=[unused[0]]
    extra=unused[1]
    alt=list(map(int,rng.choice(5,size=int(rng.integers(1,3)),replace=False)))
    alt_tail=[] if rng.random()<.5 else [int(rng.choice([i for i in range(5) if i not in alt]))]
    spec={'gate':gate,'tail':tail,'extra':extra,'replacement':unused[-1], 'alt':alt,'alt_tail':alt_tail}
    mappings=[tuple(range(5))]
    for i,j in itertools.combinations(range(5),2):
        m=list(range(5));m[i],m[j]=m[j],m[i];mappings.append(tuple(m))
    bits=list(itertools.product((0,1),repeat=3))
    states=list(itertools.product(range(len(mappings)),range(8)))
    programs=[rules_for(spec,b) for b in bits]
    contexts=list(itertools.product((0,1),repeat=5))
    order=list(map(int,rng.permutation(32)));adapt=order[:16];test=order[16:]
    canonical=list(map(int,rng.choice(32,size=16,replace=False)))
    qs=[('task',i) for i in adapt]+[('anchor',i) for i in range(5)]+[('canonical',i) for i in canonical]
    pred=np.array([[evaluate(x,mappings[mi],programs[bi]) for x in contexts] for mi,bi in states],dtype=np.int8)
    response=[]
    for mi,bi in states:
        row=[]
        for kind,i in qs:
            row.append(mappings[mi][i] if kind=='anchor' else
                       evaluate(contexts[i],mappings[mi] if kind=='task' else mappings[0],programs[bi]))
        response.append(row)
    response=np.array(response,dtype=np.int8)
    classes=np.array([fault(mappings[mi],bits[bi]) for mi,bi in states],dtype=np.int8)
    counts=Counter(map(int,classes));prior=np.array([1/(4*counts[int(c)]) for c in classes])
    # Decisions are consistent programs; losses are computed from candidate models,
    # not from any held-out oracle labels. Inputs have known uniform distribution.
    err=(pred[:,None,:]!=pred[None,:,:]).astype(float)
    source_correct=(pred[0][None,:]==pred).astype(float)
    loss=(err*(1+cfg['damage_weight']*source_correct[None,:,:])).mean(axis=2)
    edit=np.array([sum(v!=i for i,v in enumerate(mappings[mi]))+sum(bits[bi]) for mi,bi in states])
    behavior_map={};beh=[]
    for v in pred:
        key=tuple(map(int,v));behavior_map.setdefault(key,len(behavior_map));beh.append(behavior_map[key])
    truths=[int(rng.choice(np.where(classes==c)[0])) for c in range(4)]
    # A 3-cycle and a new unary rule are deliberately outside the admitted family.
    outside=None
    for cycle in itertools.permutations(range(5),3):
        m=list(range(5));i,j,k=cycle;m[i],m[j],m[k]=j,k,i
        for u in range(5):
            rs=programs[0]+(Rule('new_outside_rule',(f'p{u}',),'approve'),)
            v=np.array([evaluate(x,tuple(m),rs) for x in contexts])
            if not any(np.array_equal(v,p) for p in pred):
                outside=(tuple(m),rs,v);break
        if outside is not None:break
    assert outside is not None and all(q[1] not in test for q in qs if q[0]=='task')
    assert not (pred==3).any()
    return World(seed,spec,mappings,states,programs,contexts,adapt,test,qs,response,pred,prior,classes,
                 np.array(beh),loss,edit,np.array([mi!=0 for mi,bi in states]),
                 np.array([bi!=0 for mi,bi in states]),truths,outside)


def likelihoods(w,noise):
    # Query outcome alphabets: 5 grounding IDs or 3 logical labels.
    lk=np.zeros((len(w.queries),5,len(w.states)),dtype=float)
    for q,(kind,_) in enumerate(w.queries):
        k=5 if kind=='anchor' else 3
        for o in range(k):
            lk[q,o]=np.where(w.responses[:,q]==o,1-noise,noise/(k-1))
    return lk


def terminal(w,p,cfg,guarded=False):
    risks=w.loss@p
    if guarded:
        allow=np.ones(len(p),dtype=bool)
        if p[w.mapping_changed].sum()<cfg['guard_change_posterior']:
            allow &= ~w.mapping_changed
        if p[w.rules_changed].sum()<cfg['guard_change_posterior']:
            allow &= ~w.rules_changed
        risks=np.where(allow,risks,np.inf)
    best=float(risks.min());actions=np.where(np.abs(risks-best)<1e-12)[0]
    a=int(min(actions,key=lambda i:(w.edit[i],int(i))))
    return a,best


def all_scores(w,p,lk,policy,cfg,noise):
    if policy=='random':return np.zeros(len(w.queries))
    joint=lk*p[None,None,:]
    prob=joint.sum(axis=2)
    branch=joint/np.maximum(prob[:,:,None],1e-300)
    if policy=='entropy':
        h=-(branch*np.log2(np.maximum(branch,1e-300))).sum(axis=2)
        return evidence_entropy(p)-(prob*h).sum(axis=1)
    if policy.startswith('ec2_'):
        cl=w.classes if policy=='ec2_fault' else w.behavior
        if not noise:
            return np.array([ec_score(p,cl,w.responses[:,q]) for q in range(len(w.queries))])
        # Posterior-edge surrogate, not full noisy EC2 with expanded latent outcomes.
        return np.array([ec_edges(p,cl)-sum(prob[q,o]*ec_edges(branch[q,o],cl)
                                           for o in range(5) if prob[q,o]>0)
                         for q in range(len(w.queries))])
    guarded=policy=='guarded_risk_voi'
    _,base=terminal(w,p,cfg,guarded)
    # One BLAS call evaluates the posterior Bayes decision for every query outcome.
    flat=branch.reshape(-1,len(p)).T
    risks=w.loss@flat
    if guarded:
        pg=w.mapping_changed.astype(float)@flat
        pr=w.rules_changed.astype(float)@flat
        disallow=(w.mapping_changed[:,None] & (pg[None,:]<cfg['guard_change_posterior']))
        disallow |= (w.rules_changed[:,None] & (pr[None,:]<cfg['guard_change_posterior']))
        risks=np.where(disallow,np.inf,risks)
    after=risks.min(axis=0).reshape(prob.shape)
    return base-(prob*after).sum(axis=1)


def macro_f1(y,z):
    f=[]
    for k in range(3):
        tp=int(((y==k)&(z==k)).sum());fp=int(((y!=k)&(z==k)).sum());fn=int(((y==k)&(z!=k)).sum())
        f.append(2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.)
    return sum(f)/3


def episode(w,truth,scenario,policy,budget,anchor_cost,cfg,cache):
    noise=cfg['oracle_noise_rate'] if scenario=='noisy_10pct' else 0.
    lk=cache[('likelihood',noise)]
    if scenario=='out_of_class':
        m,rs,truepred=w.outside
        gold=np.array([m[i] if k=='anchor' else evaluate(w.contexts[i],m if k=='task' else tuple(range(5)),rs)
                       for k,i in w.queries],dtype=np.int8)
        expected_fault=3
    else:
        gold=w.responses[truth].copy();truepred=w.predictions[truth];expected_fault=int(w.classes[truth])
    # Fixed, query-specific corruption shared by every selector and budget.
    nrng=np.random.default_rng(w.seed*10000+(truth+1)*101+432)
    observed=gold.copy()
    for q,(kind,_) in enumerate(w.queries):
        if nrng.random()<noise:
            alternatives=[o for o in range(5 if kind=='anchor' else 3) if o!=gold[q]]
            observed[q]=int(nrng.choice(alternatives))
    p=w.prior.copy();used=set();spent=0;trace=[];empty=False
    rng=np.random.default_rng(w.seed*100+(truth+1)*7+budget)
    costs=np.array([1 if k=='task' else anchor_cost for k,_ in w.queries])
    selection_time=0.
    while True:
        active=np.where(p>1e-14)[0]
        if len(active)<=1:break
        eligible=[q for q in range(len(w.queries)) if q not in used and costs[q]+spent<=budget
                  and len(set(map(int,w.responses[active,q])))>1]
        if not eligible:break
        t=time.perf_counter()
        key=(policy,noise,p.tobytes())
        if key not in cache:cache[key]=all_scores(w,p,lk,policy,cfg,noise)
        score=cache[key]/costs
        best=max(score[q] for q in eligible)
        ties=[q for q in eligible if abs(score[q]-best)<1e-12]
        q=int(rng.choice(ties));selection_time+=time.perf_counter()-t
        unnorm=p*lk[q,int(observed[q])];normalizer=float(unnorm.sum())
        spent+=int(costs[q]);used.add(q)
        trace.append({'q':q,'kind':w.queries[q][0],'answer':int(observed[q]),'cost':int(costs[q]),'normalizer':normalizer})
        if normalizer<=0:
            empty=True;break
        p=unnorm/normalizer
        if not noise and scenario!='out_of_class':assert p[truth]>0
    if empty:
        action=0;coverage=0.;selerr=0;covered_count=0  # explicit source fallback, not successful repair
    else:
        action,_=terminal(w,p,cfg,policy=='guarded_risk_voi')
        confidence=np.stack([(p[:,None]*(w.predictions[:,w.test]==o)).sum(axis=0) for o in range(3)])
        agreed=confidence.max(axis=0)>=(cfg['selective_confidence'] if noise else 1-1e-12)
        covered_count=int(agreed.sum());coverage=float(agreed.mean())
        sy=confidence.argmax(axis=0)
        selerr=int(((sy!=truepred[w.test])&agreed).sum())
    y=truepred[w.test];z=w.predictions[action,w.test];source=w.predictions[0,w.test]
    correct=source==y;damage=(z!=y)&correct
    err=(z!=y).astype(float)
    rec={'world':w.seed,'truth':int(truth),'fault':expected_fault,'scenario':scenario,'policy':policy,
         'budget':budget,'anchor_cost':anchor_cost,'spent':spent,'queries':len(trace),
         'accuracy':float((z==y).mean()),'macro_f1':macro_f1(y,z),'source_accuracy':float(correct.mean()),
         'damage_fraction_all':float(damage.mean()),'source_correct_n':int(correct.sum()),
         'damaged_n':int(damage.sum()),'damage_conditional':float(damage.sum()/correct.sum()) if correct.any() else 0.,
         'weighted_loss':float((err+cfg['damage_weight']*damage).mean()),
         'fault_exact':int(int(w.classes[action])==expected_fault),
         'state_exact':int(scenario!='out_of_class' and action==truth),
         'coverage':coverage,'selective_errors':selerr,'selective_covered':covered_count,
         'empty_candidate_set':int(empty),'action':action,'selection_seconds':selection_time}
    return rec,trace


def slice_audit(w):
    # Unsafe proposal: only retain rule names used by source proofs on adaptation data.
    used=set()
    for i in w.adapt:
        prov=proof_supports(facts(w.contexts[i],tuple(range(5))),w.programs[0])
        for head in ('approve','!approve'):
            for s in prov.get(head,set()):
                used|={t[5:] for t in s if t.startswith('rule:')}
    # Safe syntactic backward cone over ALL candidate programs and both output signs.
    needed={'approve','!approve'};safe=set()
    union={r for rs in w.programs for r in rs}
    while True:
        new={r for r in union if r.head in needed}
        names={r.name for r in new}
        atoms={a for r in new for a in r.body}
        if names<=safe and atoms<=needed:break
        safe|=names;needed|=atoms
    unsafe_errors=safe_errors=checks=0
    for h,(mi,bi) in enumerate(w.states):
        for j,x in enumerate(w.contexts):
            rs=w.programs[bi]
            unsafe_errors+=evaluate(x,w.mappings[mi],tuple(r for r in rs if r.name in used))!=w.predictions[h,j]
            safe_errors+=evaluate(x,w.mappings[mi],tuple(r for r in rs if r.name in safe))!=w.predictions[h,j]
            checks+=1
    total_names={r.name for r in union}
    return {'world':w.seed,'unsafe_disagreements':int(unsafe_errors),'safe_disagreements':int(safe_errors),
            'checks':checks,'source_used_rule_names':len(used),'safe_rule_names':len(safe),
            'all_rule_names':len(total_names),'safe_rule_fraction':len(safe)/len(total_names)}


def run(config,out):
    if out.exists():raise ValueError('Refusing to overwrite existing experiment output')
    out.mkdir(parents=True)
    cfg=json.loads(config.read_text());start=datetime.now(timezone.utc).isoformat();tic=time.perf_counter()
    checks=validate_scores();rows=[];slices=[]
    with (out/'raw_traces.jsonl').open('w') as f:
        for wi,seed in enumerate(cfg['world_seeds']):
            w=make_world(seed,cfg);slices.append(slice_audit(w))
            world_spec={'seed':seed,'spec':w.spec,'adapt':w.adapt,'test':w.test,'queries':w.queries,
                        'mappings':w.mappings,'truth_ids':w.truths,'outside_mapping':w.outside[0],
                        'outside_rules':[{'name':r.name,'body':r.body,'head':r.head} for r in w.outside[1]]}
            (out/f'world_{seed}.json').write_text(json.dumps(world_spec,indent=2))
            cache={('likelihood',n):likelihoods(w,n) for n in [0.,cfg['oracle_noise_rate']]}
            for scenario in cfg['scenarios']:
                truths=[-1] if scenario=='out_of_class' else w.truths
                for truth in truths:
                    for policy in cfg['policies']:
                        for budget in cfg['budgets']:
                            rec,trace=episode(w,truth,scenario,policy,budget,cfg['anchor_and_rule_cost'],cfg,cache)
                            rec['block']='primary';rows.append(rec)
                            f.write(json.dumps({'metrics':rec,'trace':trace})+'\n')
            if wi<cfg['sensitivity_world_count']:
                for cost in cfg['sensitivity_anchor_costs']:
                    for truth in w.truths:
                        for policy in cfg['policies']:
                            rec,trace=episode(w,truth,'clean',policy,cfg['sensitivity_budget'],cost,cfg,cache)
                            rec['block']='cost_sensitivity';rows.append(rec)
                            f.write(json.dumps({'metrics':rec,'trace':trace})+'\n')
            print(json.dumps({'world':seed,'completed':wi+1,'total':len(cfg['world_seeds']),'episodes':len(rows)}),flush=True)
    import csv
    for name,rr in [('episodes.csv',rows),('slicing_audit.csv',slices)]:
        with (out/name).open('w',newline='') as f:
            wr=csv.DictWriter(f,fieldnames=list(rr[0]));wr.writeheader();wr.writerows(rr)
    summary={'experiment_id':cfg['experiment_id'],'start_utc':start,'end_utc':datetime.now(timezone.utc).isoformat(),
             'runtime_seconds':time.perf_counter()-tic,'worlds':len(cfg['world_seeds']),'episodes':len(rows),
             'states_per_world':88,'heldout_contexts_per_world':16,'numerical_sanity':checks,
             'safe_slice_errors':sum(r['safe_disagreements'] for r in slices),
             'unsafe_slice_errors':sum(r['unsafe_disagreements'] for r in slices),
             'slicing_checks_per_method':sum(r['checks'] for r in slices),
             'mean_safe_rule_fraction':float(np.mean([r['safe_rule_fraction'] for r in slices])),
             'config_sha256':digest(config),'code_sha256':digest(__file__),
             'reasoner_sha256':digest(Path(__file__).with_name('preflight.py')),
             'numpy_version':np.__version__,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
    (out/'execution.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--config',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True);args=ap.parse_args();run(args.config,args.out)
