"""Download and profile the public legacy FOLIO release, pinned to a commit.

This is not the corrected gated Hugging Face release. Do not equate versions.
No model training or logical label verification is performed here.
"""
import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import urllib.request

COMMIT='5d7bb84c7edab3fb358e057d2807f19cf5cf5e2d'
PATHS=['LICENSE','README.md','data/v0.0/folio-train.jsonl','data/v0.0/folio-validation.jsonl']


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--cache',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--offline',action='store_true',help='Reprofile already fetched pinned files')
    args=ap.parse_args()
    args.cache.mkdir(parents=True,exist_ok=True);args.out.mkdir(parents=True,exist_ok=True)
    def fetch(rel):
        u=f'https://raw.githubusercontent.com/Yale-LILY/FOLIO/{COMMIT}/{rel}'
        p=args.cache/rel
        if args.offline:
            content=p.read_bytes()
        else:
            with urllib.request.urlopen(u,timeout=20) as r:content=r.read()
            p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(content)
        return rel,{'url':u,'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest()}
    result=dict(ThreadPoolExecutor(max_workers=4).map(fetch,PATHS))
    profiles={}; stories={}; premise_groups={}; allrows={}
    for split in ['train','validation']:
        rows=[json.loads(l) for l in (args.cache/f'data/v0.0/folio-{split}.jsonl').read_text().splitlines() if l.strip()]
        allrows[split]=rows
        s={str(r.get('story_id',r.get('story-id'))) for r in rows
           if r.get('story_id',r.get('story-id')) is not None}
        stories[split]=s
        normalized=['\n'.join(r['premises']) if isinstance(r['premises'],list) else r['premises'] for r in rows]
        premise_groups[split]=set(normalized)
        profiles[split]={'examples':len(rows),'unique_story_ids':len(s) if s else None,
                         'missing_story_id_rows':sum(r.get('story_id',r.get('story-id')) is None for r in rows),
                         'unique_premise_blocks':len(set(normalized)),
                         'labels':dict(Counter(str(r.get('label')) for r in rows)),
                         'sources':dict(Counter(str(r.get('source')) for r in rows)),
                         'fields':sorted(set().union(*(set(r) for r in rows))),
                         'all_have_fol_fields':all('premises-FOL' in r and 'conclusion-FOL' in r for r in rows),
                         'missing_premises_fol_rows':sum('premises-FOL' not in r for r in rows),
                         'missing_conclusion_fol_rows':sum('conclusion-FOL' not in r for r in rows)}
    data={'dataset':'FOLIO public legacy v0.0','repository_commit':COMMIT,
          'checked_on':'2026-10-27','files':result,'profiles':profiles,
          'train_validation_story_id_overlap':len(stories['train']&stories['validation']) if all(stories.values()) else None,
          'train_validation_identical_premise_blocks':len(premise_groups['train']&premise_groups['validation']),
          'license_text':(args.cache/'LICENSE').read_text(),
          'status':'Downloaded/profiled only; no labels, domain splits, or Horn eligibility certified',
          'version_warning':'Maintainer points to a corrected gated release; this profile is only the explicit public legacy v0.0. Never silently combine releases.'}
    (args.out/'folio_legacy_profile.json').write_text(json.dumps(data,indent=2,ensure_ascii=False))
    print(json.dumps({k:v for k,v in data.items() if k not in ('files','license_text')},indent=2,ensure_ascii=False))


if __name__=='__main__':main()
