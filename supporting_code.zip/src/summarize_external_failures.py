"""Render diagnosis report from post-hoc summary; no model execution."""
from pathlib import Path
import json,csv,hashlib
ROOT=Path(__file__).resolve().parents[1]
def main():
 D=ROOT/'reports/external_failure_diagnosis_v1';p=D/'summary.json';s=json.loads(p.read_text())
 for key in ['all','short_2_3','long_4_10',*[]]:
  x=s[key];cnt=x['failure_counts'];answered=x['seed_question_decisions']-cnt.get('no_extracted_query_path',0)-cnt.get('path_but_no_composed_answer',0);x['preferred_answer_coverage']=answered/x['seed_question_decisions'];x['preferred_answer_accuracy_when_answered']=cnt.get('correct',0)/answered if answered else None
 p.write_text(json.dumps(s,indent=2));short,long=s['short_2_3'],s['long_4_10'];metrics=[('reference_edge_recall','بازیابی روابطِ مسیر مرجع','pct'),('mean_reference_errors','میانگین روابط مرجع جاافتاده یا غلط','num'),('complete_reference_support_fraction','وجود کامل روابط مرجع در برنامهٔ منتخب','pct'),('support_possible_in_family_fraction','امکان حضور روابط مسیر مرجع در خانوادهٔ اولیه','pct'),('preferred_answer_coverage','پوشش پاسخ برنامهٔ منتخب','pct'),('preferred_answer_accuracy_when_answered','صحت در میان پاسخ‌های صادرشدهٔ منتخب','pct'),('oracle_accuracy','صحت با دادن روابط مرجع، سه بذر','pct')]
 with (D/'short_long_comparison.csv').open('w') as f:
  w=csv.writer(f);w.writerow(['metric','short_2_3','long_4_10','unit']);w.writerows([[key,short[key],long[key],unit] for key,label,unit in metrics])
 table='| شاخص | دو/سه‌گامی | چهار تا ده‌گامی |\n|---|---:|---:|\n'
 for key,label,unit in metrics:
  fmt=lambda x:f'{100*x:.2f}٪' if unit=='pct' else f'{x:.2f}'
  table+=f'| {label} | {fmt(short[key])} | {fmt(long[key])} |\n'
 cnt=long['failure_counts'];n=long['seed_question_decisions'];error_table='| وضعیت خروجیِ مسائل بلند | تعداد تصمیم | درصد کل تصمیم‌های بلند |\n|---|---:|---:|\n'
 for key,label in [('no_extracted_query_path','هیچ مسیر جهت‌داری میان دو شخصیت استخراج نشده'),('path_but_no_composed_answer','مسیر هست ولی قواعد پاسخی ترکیب نمی‌کنند'),('only_wrong_relations_derived','فقط رابطه‌های نادرست مشتق شده‌اند'),('gold_derived_but_ranked_wrong','رابطه درست هم مشتق شده اما رتبه‌بندی پاسخ دیگری انتخاب کرده'),('correct','پاسخ درست')]:error_table+=f'| {label} | {cnt.get(key,0)} | {100*cnt.get(key,0)/n:.2f}٪ |\n'
 text='''# ممیزی علت شکست زنجیره‌های بلند

شناسه: NS-EXTERNAL-FAILURE-AUDIT-021؛ تحلیل پسینی روی مدل‌های ثابت آزمایش020، بدون بازآموزی یا تنظیم. تمام۳۳۷۵پیش‌بینی پایه و۳۳۷۵پیش‌بینی با اصلاح بازسازی و با خروجی آرشیو منطبق شدند. واحدهای مستقل همان۱۱۲۵سؤال هستند؛ تکرار سه‌بذری سه مجموعه‌داده مستقل نیست.

## تشخیص اصلی

گلوگاه اصلی این نسخه، ساخت برنامهٔ روابط از متن است. افت فقط حاصل زیادشدن تعداد گام‌ها نیست: کیفیت بازیابی هر رابطه هم با طول داستان پایین می‌آید، و چند خطا در یک زنجیره جمع می‌شوند. موتور ترکیب قواعد با ورودی مرجع هنوز در مسائل بلند بسیار بهتر از ورودی استخراج‌شده عمل می‌کند، هرچند کامل نیست.

'''+table+'''
در ده‌گامی‌ها، بازیابی روابط مسیر مرجع فقط۴٫۹۴٪است و به‌طور متوسط۹٫۴۸رابطهٔ مرجع در هر نمونه غلط یا جاافتاده‌اند. این نرخ با احتمال استقلال خطاها مدل‌سازی نشده؛ از مقایسه مستقیم خروجی‌ها با برنامهٔ مرجع محاسبه شده است.

## عدد پایین صحت، ترکیبی از بی‌پاسخی و پاسخ نادرست است

'''+error_table+f'''
در {100*(1-long['preferred_answer_coverage']):.2f}٪تصمیم‌های بلند، برنامهٔ منتخب اصلاً پاسخ مشتق نکرده است. در معیار صحت کل، بی‌پاسخی نیز خطا حساب می‌شود. کنترل مستقیم همیشه یک برچسب می‌دهد. با این حال، در پاسخ‌های صادرشده نیز فقط{100*long['preferred_answer_accuracy_when_answered']:.2f}٪درست‌اند؛ مشکل صرفاً احتیاط در پاسخ‌دادن نیست. این پوشش پاسخ منتخب را نباید با پوشش گواهی خانواده یکی دانست.

## چرا دو اصلاح کافی نیست؟

در {100*long['more_than_two_reference_errors_fraction']:.2f}٪تصمیم‌های بلند، بیش از دو رابطهٔ مسیر مرجع از ابتدا غلط یا جاافتاده‌اند. میانگین این خطاها از{long['mean_reference_errors']:.2f}به{long['mean_ref_errors_after_two_correction_policy']:.2f}پس از سیاست دو اصلاح می‌رسد؛ هنوز چند پیوند لازم باقی می‌ماند. تنها در{100*long['support_possible_in_family_fraction']:.2f}٪موارد، خانوادهٔ اولیه امکان پوشش همهٔ روابط مسیر مرجع را دارد. این سنجهٔ پوشش همان مسیر مرجع است و نبود مسیر معنایی جایگزین را اثبات نمی‌کند.

## سهم موتور منطق و محدودیت محاسبه

با دادن روابط مرجع به هر سه مجموعه قواعد ثابت، صحت بلند{100*long['oracle_accuracy']:.2f}٪است؛ در کوتاه{100*short['oracle_accuracy']:.2f}٪. این یک ورودی ممتاز و آزمایش تشخیصی است، نه امتیاز سامانهٔ خام‌متن. امتیاز قبلی۹۱٫۸۲٪مربوط به بذر۴۲بود؛ اینجا میانگین سه بذر گزارش می‌شود. فقط{long['path_limit_cases']}تصمیم بلند به محدودیت تعداد مسیر برخورد کرده‌اند، پس سقف محاسباتی علت غالب افت نیست.

## چه چیزی در پیاده‌سازی این ضعف را توضیح می‌دهد؟

استخراجگر مقصد TF-IDFبه‌همراه رگرسیون لجستیک است؛ شبکهٔ عصبی مبدأ برای این حوزه منتقل یا بازآموزی نشده است. هر بذر فقط۲۵۶برنامهٔ آموزشی، با زنجیره‌های دو و سه‌گامی دیده است. در کوتاه، به‌طور متوسط{short['mean_ordered_pairs']:.2f}زوج مرتب شخصیت بررسی می‌شود؛ در بلند{long['mean_ordered_pairs']:.2f}. این تغییر، متن و فضای انتخاب را از شرایط آموزش دور می‌کند. ارتباط آن با افت مشاهده شده روشن است؛ سهم علّی جداگانهٔ اندازه داده، نوع نمایش و تعداد شخصیت‌ها با ابلیشن مستقل اندازه‌گیری نشده است.

برچسب آموزش و اصلاح از برگ‌های اثبات مرجع می‌آید و تمام معنای متن را پوشش نمی‌دهد. یک رابطهٔ معکوس یا مسیر معتبر دیگر ممکن است در مرجع نباشد و برچسب «بدون یال در برنامهٔ مرجع» بگیرد. این محدودیت نظارت می‌تواند به کیفیت استخراج لطمه بزند، اما سهم عددی مستقل آن در این دور تعیین نشده است.

## نتیجه اجرایی

تمرکز اصلاح بعدی باید بر رابط متن به روابط و پوشش مسیرها باشد؛ افزودن قاعده یا شکل مقاله به‌تنهایی این گلوگاه را حل نمی‌کند. این ممیزی هیچ روش تازه‌ای را روی آزمون تنظیم نکرده و نتیجهٔ اصلی آزمون را تغییر نمی‌دهد. سه فایل summary.json، per_question.csv و examples.json به همراه کد بازتولید در بسته حفظ شده‌اند.
'''
 (D/'DIAGNOSIS_FA.md').write_text(text)
 (D/'Audit.json').write_text(json.dumps({'analysis_id':s['analysis_id'],'frozen_hashes_pass':s['frozen_hashes_pass'],'all_base_and_corrected_predictions_match_archive':s['all_base_and_corrected_predictions_match_archive'],'seeds':3,'unique_questions':1125,'base_reconstructions':3375,'corrected_reconstructions':3375,'model_training':False,'test_tuning':False,'core_method_changed':False,'manuscript_changed':False,'diagnostic_script_sha256':hashlib.sha256((ROOT/'src/diagnose_external_failures.py').read_bytes()).hexdigest(),'report_script_sha256':hashlib.sha256((ROOT/'src/summarize_external_failures.py').read_bytes()).hexdigest()},indent=2));print(table);print(error_table)
if __name__=='__main__':main()
