"""One frozen external test. Labels/annotations live only in this harness."""
import csv,json,hashlib,time,joblib,copy
from pathlib import Path
from collections import Counter,defaultdict
import numpy as np
from sklearn.metrics import f1_score
import external_kinship as k
ROOT=Path(__file__).resolve().parents[1]
def rows(name):return list(csv.DictReader((ROOT/'third_party/CLUTRR_external'/name).open(encoding='utf-8-sig')))
def main():
 out=ROOT/'results/external_kinship_v1';frozen=json.loads((out/'FROZEN_BEFORE_TEST.json').read_text())
 for f,h in frozen['sha256'].items():assert hashlib.sha256((ROOT/f).read_bytes()).hexdigest()==h,('changed after freeze',f)
 train=rows('train.csv');validation=rows('validation.csv');by={r['id']:r for r in train+validation};used_ids=set()
 for seed in [42,43,44]:
  rec=json.loads((out/f'frozen_{seed}.json').read_text());used_ids.update(rec['training_ids']+rec['gate_ids']+rec['audit_ids'])
 used_fp={k.story_fingerprint(by[i]['story']) for i in used_ids};raw=rows('test.csv');data=[];excluded=[];seen=set()
 for r in sorted(raw,key=lambda r:hashlib.sha256(r['id'].encode()).hexdigest()):
  fp=k.story_fingerprint(r['story'])
  reason='used_id' if r['id'] in used_ids else 'used_template' if fp in used_fp else 'duplicate_test_template' if fp in seen else None
  if reason:excluded.append({'id':r['id'],'reason':reason})
  else:data.append(r);seen.add(fp)
 assert not {r['id'] for r in data}&used_ids
 (out/'test_split_audit.json').write_text(json.dumps({'raw_test':len(raw),'evaluation_test':len(data),'excluded':excluded,'rules':'label-independent ID and name-normalized story exclusions against all3seeds used training/gate/audit; deduplicate testtemplates','test_ids':[r['id'] for r in data]},indent=2));print('heldout',len(data),'excluded',len(excluded),flush=True)
 output=[];evidence=[];start=time.monotonic();narrative=[]
 for seed in [42,43,44]:
  model=joblib.load(out/f'model_{seed}.joblib');rec=json.loads((out/f'frozen_{seed}.json').read_text());rr={'ungated':rec['candidate_rules'],'greedy_gate':rec['admitted_rules'],'bundle':rec['bundle_rules']};stats=Counter()
  sf=(out/f'predictions_{seed}.jsonl').open('w');ef=(out/f'proofs_{seed}.jsonl').open('w')
  for index,r in enumerate(data):
   t0=time.monotonic();q=k.parse_query(r['query']);p=model.prepare(r['story'],q);gold=r['target_text'];oracle_facts,_=k.supervision(r);pred_facts=k.selected_facts(p);predset={(a,z[0],b) for (a,b),z in pred_facts.items()};refset={(a,z,b) for (a,b),z in oracle_facts.items()};stats['extraction_tp']+=len(predset&refset);stats['extraction_predicted']+=len(predset);stats['extraction_reference']+=len(refset)
   cache={};case=[];base={}
   for label,rules in rr.items():
    key=json.dumps(rules)
    if key not in cache:cache[key]=k.family(p,rules)
    got=cache[key];base[label]=got
    case.append({'method':label+'_0','prediction':got['preferred'],'certified':got['certified'],'certified_answer':got['certified_answer'],'annotations':0,'proof_valid':k.verify_proof(got['proof'],got['facts'],rules) if got['proof'] else None,'family_limited':got['limited']})
   case.extend([{'method':'direct_logistic','prediction':p['direct'],'certified':None,'annotations':0},{'method':'nearest_prototype','prediction':p['prototype'],'certified':None,'annotations':0},{'method':'no_composition','prediction':k.execute(pred_facts,q,[])['preferred'],'certified':None,'annotations':0}])
   lookup={'ungated':'ungated_0','no_composition':'no_composition','direct':'direct_logistic','prototype':'nearest_prototype'};chosen=next(c for c in case if c['method']==lookup[rec['selected_control']]);case.append({**chosen,'method':'validation_selected_control'})
   interventions=[('ungated','uncertainty',True),('bundle','uncertainty',True),('bundle','random',True),('ungated','uncertainty',False)]
   corrections={}
   for label,policy,stop in interventions:
    rules=rr[label];key=(json.dumps(rules),policy,stop)
    if key not in corrections:corrections[key]=k.correct(p,rules,lambda pair:oracle_facts.get(tuple(pair),k.NONE),budget=2,policy=policy,seed=seed+int(hashlib.sha256(r['id'].encode()).hexdigest()[:8],16),stop_on_certificate=stop)
    got=corrections[key];method=label+('_always2' if not stop else '_unc2' if policy=='uncertainty' else '_rand2')
    case.append({'method':method,'prediction':got['preferred'],'certified':got['certified'],'certified_answer':got['certified_answer'],'annotations':len(got['annotations']),'proof_valid':k.verify_proof(got['proof'],got['facts'],rules) if got['proof'] else None,'family_limited':got['limited'],'semantic_requests':got['annotations']})
   audit=k.proof_interventions(base['bundle'],q,rr['bundle'])
   if audit:
    assert audit['proof_valid'] and audit['support_sufficient'];ev={'id':r['id'],'seed':seed,'gold':gold,'preferred':base['bundle']['preferred'],'proof':base['bundle']['proof'],'facts':[[a,b,*v] for (a,b),v in base['bundle']['facts'].items()],'rules':rr['bundle'],'audit':audit};ef.write(json.dumps(ev)+'\n');evidence.append({'id':r['id'],'seed':seed,**audit})
   for c in case:
    c.update(id=r['id'],seed=seed,gold=gold,hops=int(r['task_name'].split('.')[-1]));output.append(c);sf.write(json.dumps(c)+'\n')
   if len(narrative)<9 and index in [0,100,300]:narrative.append({'id':r['id'],'seed':seed,'story':r['story'],'query':q,'gold':gold,'results':case,'proof':base['bundle']['proof']})
   if (index+1)%100==0:sf.flush();ef.flush();print(seed,index+1,'seconds',round(time.monotonic()-start,1),flush=True)
  sf.close();ef.close();(out/f'extraction_{seed}.json').write_text(json.dumps(dict(stats),indent=2))
 methods=sorted({r['method'] for r in output});summary={'experiment_id':'NS-EXTERNAL-KINSHIP-020','questions':len(data),'raw_questions':len(raw),'seeds':[42,43,44],'start_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime(time.time()-(time.monotonic()-start))),'runtime_seconds':time.monotonic()-start,'methods':{},'scope':'Fresh target ontology/task and heldout name-normalized story templates; semi-syntheticcrowdsourced-template data; reusable contract/schema, not learned source-weight transfer'}
 labels=sorted({r['target_text'] for r in data})
 for method in methods:
  sel=[r for r in output if r['method']==method];correct=sum(r['prediction']==r['gold'] for r in sel);cert=[r for r in sel if r.get('certified')];den=len(sel);summary['methods'][method]={'n':den,'accuracy':correct/den,'macro_f1':float(f1_score([r['gold'] for r in sel],[r['prediction'] for r in sel],labels=labels,average='macro',zero_division=0)),'correct':correct,'annotations':sum(r['annotations'] for r in sel),'certified':len(cert),'certificate_coverage':len(cert)/den if 'certified_answer' in sel[0] else None,'accepted_accuracy':sum(r['certified_answer']==r['gold'] for r in cert)/len(cert) if cert else None,'per_seed':{str(seed):{'accuracy':sum(r['prediction']==r['gold'] for r in sel if r['seed']==seed)/len(data),'annotations':sum(r['annotations'] for r in sel if r['seed']==seed)} for seed in [42,43,44]},'invalid_proofs':sum(r.get('proof_valid') is False for r in sel),'limited_families':sum(r.get('family_limited') is True for r in sel)}
 summary['proof_audit']={'selected_proofs':len(evidence),'valid':sum(x['proof_valid'] for x in evidence),'sufficient':sum(x['support_sufficient'] for x in evidence),'support_deletion_removes':sum(x['support_set_deletion_removes'] for x in evidence),'individual_rules_tested':sum(len(x['individual_rule_deletions']) for x in evidence),'individual_rule_deletion_removes':sum(y['removes_conclusion'] for x in evidence for y in x['individual_rule_deletions'])}
 (out/'summary.json').write_text(json.dumps(summary,indent=2));(out/'qualitative_examples.json').write_text(json.dumps(narrative,indent=2));print(json.dumps(summary,indent=2),flush=True)
if __name__=='__main__':main()
