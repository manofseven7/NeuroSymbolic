"""Protocol correction before final comparison: retain NL decomposition and HtT path.
Initial code-only outputs are preserved as an ablation, never branded full FaithfulCoT.
"""
import ast,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];PAY=ROOT/'results/published_baselines_v1/payload';p=PAY/'run_published_llm_baselines.py';s=p.read_text()
start=s.index('def faithful_answer(row):');end=s.index('def htt_answer(row):',start)
replacement='''def faithful_answer(row):
 q,facts,_=chain(row);lines=['# To answer this question, we answer the following subquestions:']
 for i,(a,r,b) in enumerate(reversed(facts),1):
  lines.append(f'# {i}. How is [{b}] related to [{a}]? (independent)')
  lines.append(f'relation({b}, {a}) = {r}')
 lines.append(f'# {len(facts)+1}. Final answer: How is [{q[1]}] related to [{q[0]}]? (depends on the subquestions)')
 lines.append(f'relation({q[1]}, {q[0]}) = '+ ' @ '.join(f'relation({b}, {a})' for a,r,b in reversed(facts)))
 return '\\n'.join(lines)
'''
s=s[:start]+replacement+s[end:]
insert='''\ndef htt_text_answer(row):
 q,facts,_=chain(row)
 triplets=', '.join(f'({a}, {r}, {b})' for a,r,b in facts)
 lines=['We first extract triplets from the document, find the path, then reduce its relations.', 'The triplets include '+triplets+'.', 'The path from '+q[0]+' to '+q[1]+' is '+triplets+'.', 'The relations on the path are '+', '.join(r for a,r,b in facts)+'.', htt_answer(row)]
 return '\\n'.join(lines)
'''
s=s.replace('\ndef query(row):',insert+'\ndef query(row):')
s=s.replace("+htt_answer(r))\n  else:examples.append('Context:","+htt_text_answer(r))\n  else:examples.append('Context:")
s=s.replace('Write the single relations along the path from the asked person to the reference person, one per line.','Write brief numbered natural-language subquestions and a relation assignment for each, following the examples. Order the path from the asked person to the reference person.')
s=s.replace('Extract the ordered path as single relation assignments:', 'To answer this question, write a program to answer the following subquestions:')
s=s.replace("'batch_size':32", "'batch_size':128").replace('range(0,len(remaining),32)','range(0,len(remaining),128)').replace('remaining[start:start+32]','remaining[start:start+128]')
# Closed-label boundaries: do not mistake great-grandfather for grandfather.
s=s.replace("LABEL_PATTERN=r'\\b('","LABEL_PATTERN=r'(?<![\\w-])('").replace("+r')\\b'", "+r')(?![\\w-])'")
ast.parse(s);(ROOT/'src/run_published_llm_baselines_corrected.py').write_text(s);(PAY/'run_published_llm_baselines_corrected.py').write_text(s)
print(len(s));print('corrected text demos',s.count('htt_text_answer(r)'));print('batch ranges128',s.count('range(0,len(remaining),128)'))
