"""Paired cluster bootstrap of exploratory timing; repeats are averaged first."""
import csv,json
from collections import defaultdict
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
def comparison(rows,base,proposed,cluster_key,seed):
    bycase=defaultdict(list)
    for r in rows:bycase[(r['id'],r['method'])].append(r)
    clusters=defaultdict(lambda:np.zeros(4))
    for (qid,method),rr in bycase.items():
        if method!=base:continue
        pp=bycase[(qid,proposed)];group=rr[0][cluster_key] if cluster_key else qid
        clusters[group]+=np.array([np.mean([float(x['runtime_seconds']) for x in rr]),np.mean([float(x['runtime_seconds']) for x in pp]),np.mean([float(x['solver_checks']) for x in rr]),np.mean([float(x['solver_checks']) for x in pp])])
    a=np.array(list(clusters.values()));s=a.sum(0);rng=np.random.default_rng(seed);b=a[rng.integers(len(a),size=(10000,len(a)))].sum(1)
    vals=np.c_[1-b[:,1]/b[:,0],1-b[:,3]/b[:,2]];ci=np.quantile(vals,[.025,.975],axis=0)
    return {'baseline':base,'proposed':proposed,'clusters':len(a),'timing_reduction_percent':100*(1-s[1]/s[0]),'timing_95pct_cluster_interval':(100*ci[:,0]).tolist(),'solver_check_reduction_percent':100*(1-s[3]/s[2]),'checks_95pct_cluster_interval':(100*ci[:,1]).tolist(),'warning':'Exploratory timing, fixed implementation selected after earlier rounds; cluster bootstrap does not remove development selection bias or establish independent NLU performance.'}
def main():
    mainrows=list(csv.DictReader((ROOT/'results/folio_interval_v2/runs.csv').open()));stress=list(csv.DictReader((ROOT/'results/folio_interval_stress/runs.csv').open()));cases={x['id']:x for x in json.loads((ROOT/'results/folio_interval_stress/cases.json').read_text())}
    for r in stress:r['story_id']='story_'+r['id'].split('_')[1] if r['source']=='curated_larger_family' else r['id']
    result={'primary':comparison(mainrows,'incremental_early_stop','interval_gate','story_id',1015),'larger_real':comparison([x for x in stress if x['source']=='curated_larger_family'],'incremental_model_reuse','interval_gate','story_id',1016),'synthetic_strongest':comparison([x for x in stress if x['source']=='fresh_synthetic'],'incremental_model_reuse','interval_gate','story_id',1017)}
    (ROOT/'results/folio_interval_v2/analysis.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if __name__=='__main__':main()
