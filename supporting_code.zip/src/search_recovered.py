"""Recovered, prospectively specified mechanism search; symbolic experiments only.

Shared expanded hypothesis bank, fixed evidence cost, held-out task inputs.
No noiseless certificate guarantee is asserted for noisy observations.
"""
import argparse, csv, hashlib, itertools, json, time
from pathlib import Path
import numpy as np
import deep_test as d

METHODS=['closed_entropy','wide_entropy','wide_ec2','predictive_risk','contrastive_expansion','certificate_frontier','certificate_challenge']
CANDIDATES=METHODS[3:]
CASES=['source','grounding','rules','both','new_unary_cycle','new_pair_cycle','new_exception']

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def cert(obs,sub):
    pos=np.zeros(32,bool);neg=pos.copy();np_=pos.copy();nn=pos.copy()
    for x,y in obs:
        if y==0: pos|=sub[x]; nn|=sub[x]
        elif y==1: neg|=sub[:,x]; np_|=sub[:,x]
        else: np_|=sub[:,x]; nn|=sub[x]
    bad=bool(np.any(pos & np_) or np.any(neg & nn) or np.any(pos & neg))
    out=np.full(32,-1,dtype=int);out[np_ & nn]=2;out[pos]=0;out[neg]=1
    return out,bad

def bank(seed):
    w=d.make_world(seed,{'damage_weight':.5})
    maps=list(itertools.permutations(range(5)))
    clauses=[x for n in (1,2) for x in itertools.combinations(range(5),n)]
    tables=[];pr=[];npr=[];lookup={}
    for b,rs in enumerate(w.programs):
        for j,clause in enumerate([None]+clauses):
            rr=rs if clause is None else rs+(d.Rule('new_clause',tuple(f'p{i}' for i in clause),'approve'),)
            table=tuple(d.evaluate(x,maps[0],rr) for x in w.contexts)
            if table not in lookup:
                lookup[table]=len(tables);tables.append(table);pr.append(0.);npr.append(0.)
            k=lookup[table]
            pr[k]+=(.4 if b==0 else .3/7) if j==0 else .3/8/15
            if j==0:npr[k]+= .5 if b==0 else .5/7
    canonical=np.array(tables,dtype=np.int8);pr=np.array(pr);npr=np.array(npr)
    preds=[];resps=[];pri=[];npri=[]
    xs=np.array(w.contexts);weights=2**np.arange(4,-1,-1)
    for m in maps:
        inv=np.argsort(m);ix=xs[:,inv]@weights
        pred=canonical[:,ix];preds.append(pred)
        rr=np.empty((len(canonical),len(w.queries)),dtype=np.int8)
        for q,(kind,i) in enumerate(w.queries):
            rr[:,q]=m[i] if kind=='anchor' else (pred[:,i] if kind=='task' else canonical[:,i])
        resps.append(rr)
        pri.extend(pr*(.5 if m==maps[0] else .5/119))
        npri.extend(npr*(.5 if m==maps[0] else .5/10 if m in w.mappings else 0.))
    pred=np.concatenate(preds);resp=np.concatenate(resps)
    onehot=np.concatenate([(pred==k).T for k in range(3)]).astype(float)
    _,classes=np.unique(pred,axis=0,return_inverse=True)
    sub=np.all(xs[:,None,:]<=xs[None,:,:],axis=2)
    return dict(w=w,pred=pred,resp=resp,prior=np.array(pri),nprior=np.array(npri),onehot=onehot,classes=classes,sub=sub)

def marginal(b,p):return (b['onehot']@p).reshape(3,32)

def decide(b,p):
    mar=marginal(b,p);source=b['pred'][0]
    risk=1-mar+.5*(np.arange(3)[:,None]!=source)*mar[source,np.arange(32)]
    return risk.argmin(axis=0),float(risk.min(axis=0).mean())

def truth(b,case):
    w=b['w'];rng=np.random.default_rng(w.seed+90000+CASES.index(case))
    if case in CASES[:4]:
        i=w.truths[CASES.index(case)];mi,bi=w.states[i];m=w.mappings[mi];rs=w.programs[bi]
    else:
        cyc=rng.choice(5,3,replace=False);m=list(range(5));i,j,k=map(int,cyc);m[i],m[j],m[k]=j,k,i;m=tuple(m)
        cl=tuple(map(int,rng.choice(5,2,replace=False)))
        if case=='new_exception':
            rs=(d.Rule('exception',(f'p{cl[0]}',f'!p{cl[1]}'),'approve'),d.Rule('reject',tuple('!p'+str(i) for i in range(5)),'!approve'))
        else:
            cl=cl[:1] if case=='new_unary_cycle' else cl
            rs=w.programs[0]+(d.Rule('new',tuple(f'p{i}' for i in cl),'approve'),)
    y=np.array([d.evaluate(x,m,rs) for x in w.contexts])
    ans=np.array([m[i] if kind=='anchor' else d.evaluate(w.contexts[i],m if kind=='task' else w.mappings[0],rs) for kind,i in w.queries])
    return y,ans

def scores(b,p,pn,noise,method,obs,lk):
    joint=lk*p;prob=joint.sum(axis=2)
    entropy=-(prob*np.log2(np.maximum(prob,1e-300))).sum(axis=1)
    # Symmetric label noise: H(response | hypothesis) constant per alphabet.
    if noise:
        for q,(kind,_) in enumerate(b['w'].queries):
            k=5 if kind=='anchor' else 3
            entropy[q]-=-(1-noise)*np.log2(1-noise)-noise*np.log2(noise/(k-1))
    if method.endswith('entropy'):return entropy
    if method=='contrastive_expansion':
        nprob=(lk*pn).sum(axis=2)
        return .5*np.abs(prob-nprob).sum(axis=1)+.2*entropy
    if method=='predictive_risk':
        base=decide(b,p)[1]
        mar=(b['onehot']@joint.reshape(-1,len(p)).T).reshape(3,32,len(b['w'].queries),5)
        src=b['pred'][0];srcmass=mar[src,np.arange(32)]
        risk=prob[None,None,:,:]-mar+.5*(np.arange(3)[:,None]!=src)[:,:,None,None]*srcmass[None,:,:,:]
        return base-risk.min(axis=0).mean(axis=0).sum(axis=1)
    if method=='wide_ec2':
        if not noise:return np.array([d.ec_score(p,b['classes'],b['resp'][:,q]) for q in range(len(prob))])
        return np.array([d.ec_edges(p,b['classes'])-sum(prob[q,o]*d.ec_edges(joint[q,o]/prob[q,o],b['classes']) for o in range(5) if prob[q,o]>0) for q in range(len(prob))])
    current,bad=cert(obs,b['sub']);s=np.zeros(len(prob))
    for q,(kind,x) in enumerate(b['w'].queries):
        if kind!='task':s[q]=-np.inf;continue
        if bad:s[q]=entropy[q];continue
        for o in range(3):
            after,violation=cert(obs+[(x,o)],b['sub'])
            if not violation:s[q]+=prob[q,o]*np.count_nonzero((after>=0)&(current<0))
        if method=='certificate_challenge' and len(obs)%3==2 and current[x]>=0:
            s[q]+=32*(1-prob[q,current[x]])
    return s

def episode(b,case,noise,method):
    w=b['w'];y,ans=truth(b,case);p=(b['nprior'] if method=='closed_entropy' else b['prior']).copy();pn=b['nprior'].copy()
    cost=np.array([1 if k=='task' else 2 for k,_ in w.queries]);lk=np.zeros((len(cost),5,len(p)))
    for q,(kind,_) in enumerate(w.queries):
        k=5 if kind=='anchor' else 3
        for o in range(k):lk[q,o]=np.where(b['resp'][:,q]==o,1-noise,noise/(k-1))
    rng=np.random.default_rng(w.seed*100+CASES.index(case));observed=ans.copy()
    for q,(kind,_) in enumerate(w.queries):
        k=5 if kind=='anchor' else 3
        if rng.random()<noise:observed[q]=rng.choice([o for o in range(k) if o!=ans[q]])
    used=[];obs=[];spent=0;empty=False;trace=[]
    while True:
        allowed=[q for q in range(len(cost)) if q not in used and spent+cost[q]<=8 and (not method.startswith('certificate') or w.queries[q][0]=='task')]
        if not allowed:break
        s=scores(b,p,pn,noise,method,obs,lk)/cost
        q=max(allowed,key=lambda i:(s[i],-i));o=int(observed[q]);used.append(q);spent+=int(cost[q]);trace.append([q,o])
        if w.queries[q][0]=='task':obs.append((w.queries[q][1],o))
        p*=lk[q,o];pn*=lk[q,o]
        if p.sum()<1e-200:empty=True;break
        p/=p.sum()
        if pn.sum()>1e-200:pn/=pn.sum()
        else:pn=b['nprior'].copy()
    z=b['pred'][0].copy() if empty else decide(b,p)[0]
    certified,bad=cert(obs,b['sub']);covered=np.zeros(32,bool)
    if method.startswith('certificate') and not bad:
        covered=certified>=0;z[covered]=certified[covered]
    ix=w.test;err=z[ix]!=y[ix];damage=err&(b['pred'][0,ix]==y[ix]);cv=covered[ix]
    row=dict(seed=w.seed,case=case,noise=noise,method=method,accuracy=float((~err).mean()),weighted_loss=float(err.mean()+.5*damage.mean()),damage=float(damage.mean()),source_accuracy=float((b['pred'][0,ix]==y[ix]).mean()),empty_bank=int(empty),certificate_coverage=float(cv.mean()),certificate_errors=int(np.count_nonzero(err&cv)),certificate_covered=int(cv.sum()),order_violation=int(bad),wide_contains_truth=int(np.any(np.all(b['pred']==y,axis=1))),states=len(p),spent=spent)
    return row,trace

def run(cfg,stage,out,selection):
    out=Path(out);out.mkdir(parents=True,exist_ok=False)
    methods=METHODS if stage=='development' else METHODS[:3]+[json.loads(Path(selection).read_text())['selected']]
    seeds=cfg[stage+'_seeds'];rows=[];start=time.time()
    (out/'protocol.json').write_text(json.dumps(cfg,indent=2))
    with (out/'traces.jsonl').open('w') as f:
        for si,seed in enumerate(seeds):
            b=bank(seed)
            (out/f'world_{seed}.json').write_text(json.dumps(b['w'].spec))
            for case,noise,method in itertools.product(CASES,[0.,.1],methods):
                row,trace=episode(b,case,noise,method);rows.append(row)
                f.write(json.dumps({'metrics':row,'queries':trace})+'\n');f.flush()
            print(f'{stage} {si+1}/{len(seeds)} seed={seed} episodes={len(rows)}',flush=True)
    with (out/'episodes.csv').open('w') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    (out/'execution.json').write_text(json.dumps(dict(seconds=time.time()-start,episodes=len(rows),code_sha=sha(__file__),numpy=np.__version__,selection_sha=sha(selection) if selection else None),indent=2))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--config',required=True);ap.add_argument('--stage',choices=['development','confirmation'],required=True);ap.add_argument('--out',required=True);ap.add_argument('--selection');a=ap.parse_args()
    run(json.loads(Path(a.config).read_text()),a.stage,a.out,a.selection)
