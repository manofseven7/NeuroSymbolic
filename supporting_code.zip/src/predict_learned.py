"""CPU inference with the saved learned parser and executable program beam."""
import argparse,json
from pathlib import Path
import joblib
import evaluate_learned_parser as e
import learned_parser as l
import text_reasoner as t

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--context-file',required=True);ap.add_argument('--statement',required=True);a=ap.parse_args()
    root=Path('results/learned_parser_v1');sel=json.loads((root/'selection.json').read_text());model=joblib.load(root/(sel['selected']+'.joblib'))
    texts=[s.strip() for s in Path(a.context_file).read_text().split('.') if s.strip()]+[a.statement.strip().rstrip('.')]
    if any(not l.tokens(s) for s in texts):
        print(json.dumps({'answer':'abstain','reason':'Unsupported tokenless input'},indent=2));return
    options=[model.candidates(s) for s in texts];options[-1]=[v for v in options[-1] if v[0][0]=='fact' and '?x' not in v[0][2]]
    r=e.adapt(texts,options,[1.]*len(texts),'none',0,16,lambda q:(_ for _ in ()).throw(AssertionError('No annotations requested')))
    if not r['complete']:print(json.dumps({'answer':'abstain','reason':'No complete typed candidate program'},indent=2));return
    out=t.verbalize(r['records'],r['proof'],r['prediction']);out['program_relative_proof_valid']=t.verify(r['records'],r['query'],r['prediction'],r['proof']) if r['prediction'] in [0,1] else None
    out['scope']='Learned controlled-English parser; no guarantee for unrestricted text.'
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()
