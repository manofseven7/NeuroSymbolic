"""Document consistency audit; does not rerun or modify scientific experiments."""
import hashlib,json,re
from pathlib import Path
from pypdf import PdfReader
ROOT=Path(__file__).resolve().parents[1]
def main():
 tex=(ROOT/'manuscript/review_version/main.tex').read_text();log=(ROOT/'manuscript/review_version/main.log').read_text(errors='replace');reader=PdfReader(ROOT/'manuscript/review_version/main.pdf');text='\n'.join(p.extract_text() for p in reader.pages)
 assert 'undefined references' not in log.lower() and 'citation `' not in log.lower()
 assert 'Overfull' not in log
 b=json.loads((ROOT/'results/folio_interval_v2/summary.json').read_text());st=json.loads((ROOT/'results/folio_interval_stress/summary.json').read_text());t=json.loads((ROOT/'results/text_certificate_v1/summary.json').read_text());checks=[]
 mapping={'Incremental early stopping':'incremental_early_stop','Selector only':'selector_only','Selector with model reuse':'selector_model_reuse','Incremental model reuse':'incremental_model_reuse','Must/may bounds and fallback':'interval_gate'}
 for label,key in mapping.items():
  row=f"{label} & {b[key]['mean_solver_checks']:.3f} & {b[key]['mean_runtime_ms']:.3f} & 0"
  assert row in tex,row;checks.append({'table':'primary','method':key,'matches_raw_summary':True})
 mapping={'Incremental early stopping':'incremental_early_stop','Selector only':'selector_only','Selector model reuse':'selector_model_reuse','Incremental model reuse':'incremental_model_reuse','Branch model reuse':'branch_model_reuse','Must/may bounds':'interval_gate'}
 for label,key in mapping.items():
  a,c=st['curated_larger_family'][key],st['fresh_synthetic'][key]
  row=f"{label} & {a['mean_solver_checks']:.3f} & {a['mean_ms']:.3f} & {c['mean_solver_checks']:.3f} & {c['mean_ms']:.3f}"
  assert row in tex,row;checks.append({'table':'stress','method':key,'matches_raw_summary':True})
 for budget,n in [('0',290),('2',323)]:assert t['budgets'][budget]['accepted']==n
 assert r'48.33\%' in tex and r'53.83\%' in tex and '605' in tex
 assert '189 of 202' in tex and '276 finite' in tex and '87 passing tests' in tex
 assert tex.count('\\begin{table}')==11 and tex.count('\\begin{figure}')==8 and tex.count('\\begin{proposition}')==2
 assert len(reader.pages)>=10 and '??' not in text
 for page in reader.pages:
  assert page.extract_text().strip()
 out={'document':'manuscript/review_version/main.pdf','pages':len(reader.pages),'tables':11,'figures':8,'architecture_figures':1,'empirical_figures':7,'propositions':2,'reference_entries':tex.count('\\bibitem'),'approx_extracted_words':len(text.split()),'table_row_checks':checks,'undefined_references':False,'overfull_boxes':False,'pdf_sha256':hashlib.sha256((ROOT/'manuscript/review_version/main.pdf').read_bytes()).hexdigest(),'tex_sha256':hashlib.sha256((ROOT/'manuscript/review_version/main.tex').read_bytes()).hexdigest(),'scope':'Authoring/QC only; no new experiment, no new claim of novelty or submission readiness.'}
 (ROOT/'reports/MANUSCRIPT_DOCUMENT_AUDIT.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k!='table_row_checks'},indent=2))
if __name__=='__main__':main()
