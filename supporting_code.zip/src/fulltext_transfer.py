"""Raw ParaRules text baseline: no supplied facts,query meanings or rule count.

This deliberately simple hybrid is an engineering baseline,not a new general
semantic parser. Source attribute vocabulary and unlabeled-train name lexicon
are fixed before any full-text test outcomes. Binary closed-world semantics.
"""
import collections,csv,hashlib,json,re,time
from pathlib import Path
import joblib
import learned_parser as l
import text_reasoner as t
from prepare_transfer import literals,canonical_rule,normalized
from transfer_committee import lexical

def induce_names(raw_train,vocab):
    counts=collections.Counter(w.lower() for r in raw_train for w in re.findall(r'\b[A-Z][a-z]+\b',r['theory']))
    function={'if','people','when','someone','anyone','all','any','somebody'}
    return sorted(w for w,n in counts.items() if n>=.4*len(raw_train) and w not in vocab and w not in function)

def parse_raw(text,names,vocab):
    units=[s.strip() for s in re.split(r'[.!?]+\s*',text) if s.strip()];ws=[re.findall('[a-z]+',s.lower()) for s in units]
    indices=[i for i,w in enumerate(ws) if set(w)&set(names)]
    if not indices:return [],dict(complete=False,reason='No name from train-induced lexicon')
    cut=max(indices)+1
    while cut<len(units) and set(ws[cut])&{'he','his','him','she','her'}:cut+=1
    records=[];subject=None;factcount=0;rulecount=0
    for i,(s,w) in enumerate(zip(units[:cut],ws[:cut])):
        hits=[v for v in w if v in names]
        if hits:subject=hits[-1]
        if subject is None:continue
        for pred in sorted(set(w)&set(vocab)):
            records.append((f't{i}_{pred}',s,('fact',(),(pred,subject,'',True))));factcount+=1
    chunks=[]
    for s,w in zip(units[cut:],ws[cut:]):
        if len(set(w)&set(vocab))<2 and chunks:chunks[-1]+='. '+s
        else:chunks.append(s)
    for i,s in enumerate(chunks):
        ast=lexical(s,vocab)
        if ast is not None:records.append((f'r{i}',s,ast));rulecount+=1
    return records,dict(complete=True,fact_atoms=factcount,rule_units=rulecount,raw_sentence_units=len(units),fact_prefix_units=cut)

def main():
    cfg=json.loads(Path('configs/fulltext_transfer_v1.json').read_text());out=Path('results/fulltext_transfer_v1');out.mkdir(exist_ok=False);start=time.time();p=Path('third_party/RuleTaker_NatLang');train=[json.loads(s) for s in (p/'meta-train.jsonl').read_text().splitlines()];test=[json.loads(s) for s in (p/'meta-test.jsonl').read_text().splitlines()];vocab=set(json.loads(Path('results/transfer_v1/data_audit.json').read_text())['selected']['vocabulary']);names=induce_names(train,vocab);(out/'name_lexicon.json').write_text(json.dumps(names,indent=2))
    sel=json.loads(Path('results/learned_parser_v1/selection.json').read_text());model=joblib.load(Path('results/learned_parser_v1')/(sel['selected']+'.joblib'));rows=[];theories=[];examples=[];checks=dict(positive_literal_derivations=0,invalid_program_proofs=0,theory_reference_supported=0,absence_cases=0,query_abstentions=0)
    for i,r in enumerate(test):
        # Predictor sees raw text only. Gold formulas below are evaluator-only.
        records,info=parse_raw(r['theory'],names,vocab)
        ref={normalized(('fact',(),literals(v['representation'])[0])) for v in r['triples'].values()}|{normalized(canonical_rule(v)) for v in r['rules'].values()};got={normalized(a) for sid,s,a in records};theories.append(dict(id=r['id'],reference_program_exact=got==ref,**info))
        for qid,q in r['questions'].items():
            text=q['question'].strip().rstrip('.')
            try:
                qa=model.predict(text)
                if qa[0]!='fact' or '?x' in qa[2]:raise t.ParseError('Non-ground query')
                query=qa[2]
            except (t.ParseError,ValueError):
                rows.append(dict(theory_id=r['id'],question_id=qid,prediction=2,gold=int(q['answer']),correct=0,abstention=1,query_reference_exact=False,reference_program_exact=got==ref,positive_derivation=False,program_proof_valid=None,theory_reference_supported=None));checks['query_abstentions']+=1;continue
            positive=query[:3]+(True,);label,pf,known=t.run(records,positive);present=positive in known;answer=bool(present if query[3] else not present);valid=aligned=None
            if present:
                valid=t.verify(records,positive,0,pf);mapping={sid:a for sid,s,a in records};aligned=all(normalized(mapping[node['id']]) in ref for node in pf);checks['positive_literal_derivations']+=1;checks['invalid_program_proofs']+=not valid;checks['theory_reference_supported']+=aligned
            else:checks['absence_cases']+=1
            rows.append(dict(theory_id=r['id'],question_id=qid,prediction=int(answer),gold=int(q['answer']),correct=int(answer==q['answer']),abstention=0,query_reference_exact=tuple(query)==tuple(literals(q['representation'])[0]),reference_program_exact=got==ref,positive_derivation=present,program_proof_valid=valid,theory_reference_supported=aligned))
            if len(examples)<6 and present:
                explanation=t.verbalize(records,pf,0);explanation.pop('answer',None);explanation['answer_to_question']=answer;explanation['relation']='supports_question' if query[3] else 'refutes_negative_question';explanation['interpretations_verified_by_human']=False
                examples.append(dict(theory_id=r['id'],question=q['question'],predicted=answer,gold=q['answer'],explanation=explanation,reference_support_audit=aligned))
        if (i+1)%100==0:print('raw text theories',i+1,flush=True)
    with (out/'questions.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    (out/'theories.json').write_text(json.dumps(theories,indent=2));(out/'explanation_examples.json').write_text(json.dumps(examples,indent=2));(out/'proof_checks.json').write_text(json.dumps(checks,indent=2))
    result=dict(theories=len(test),questions=len(rows),accuracy=sum(r['correct'] for r in rows)/len(rows),reference_program_agreement=sum(r['reference_program_exact'] for r in theories)/len(theories),query_semantic_agreement=sum(r['query_reference_exact'] for r in rows)/len(rows),seconds=time.time()-start,code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope=cfg['scope'],proof_checks=checks)
    (out/'summary.json').write_text(json.dumps(result,indent=2));print(result)

if __name__=='__main__':main()
