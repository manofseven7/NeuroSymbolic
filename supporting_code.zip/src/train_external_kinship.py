import csv,json,hashlib,joblib,time,platform
from pathlib import Path
from collections import Counter
from external_kinship import Grounder,supervision,admit_rules,execute,selected_facts,parse_query,story_fingerprint
ROOT=Path(__file__).resolve().parents[1]
def read(s):return list(csv.DictReader((ROOT/'third_party/CLUTRR_external'/s).open(encoding='utf-8-sig')))
def main():
 cfg=json.loads((ROOT/'configs/external_kinship_v1.json').read_text());raw_train=read('train.csv');raw_val=read('validation.csv');vids={r['id'] for r in raw_val};vfp={story_fingerprint(r['story']) for r in raw_val};rows=[r for r in raw_train if r['id'] not in vids and story_fingerprint(r['story']) not in vfp];seen=set();val=[]
 for r in sorted(raw_val,key=lambda r:hashlib.sha256(r['id'].encode()).hexdigest()):
  fp=story_fingerprint(r['story'])
  if fp not in seen:val.append(r);seen.add(fp)
 gate=val[:128];audit=val[128:256];out=ROOT/'results/external_kinship_v1';out.mkdir(exist_ok=True)
 (out/'split_audit.json').write_text(json.dumps({'raw_train':len(raw_train),'raw_validation':len(raw_val),'eligible_train':len(rows),'unique_validation_templates':len(val),'train_validation_id_overlap_raw':len({r['id'] for r in raw_train}&vids),'train_validation_id_overlap_used':0,'train_validation_template_overlap_used':0},indent=2))
 assert not {r['id'] for r in rows}&{r['id'] for r in val}
 manifest={'config':cfg,'runtime_start_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'cpu':platform.processor(),'seeds':{}}
 for seed in cfg['seeds']:
  start=time.monotonic();selected=sorted(rows,key=lambda r:hashlib.sha256(f'{seed}:{r["id"]}'.encode()).hexdigest())[:256];model=Grounder(seed).fit(selected);counter=Counter(rule for r in selected for rule in supervision(r)[1]);candidates=sorted(counter.items(),key=lambda x:(-x[1],x[0]))[:64]
  prep=[model.prepare(r['story'],parse_query(r['query'])) for r in gate];labels=[r['target_text'] for r in gate];rules,log=admit_rules(prep,labels,candidates)
  ap=[model.prepare(r['story'],parse_query(r['query'])) for r in audit];stats={}
  for name,rr in [('ungated',[k for k,v in candidates]),('gated',rules),('no_composition',[])]:stats[name]={'correct':sum(execute(selected_facts(p),p['query'],rr)['preferred']==r['target_text'] for p,r in zip(ap,audit)),'n':len(audit)}
  stats['direct']={'correct':sum(p['direct']==r['target_text'] for p,r in zip(ap,audit)),'n':len(audit)}
  joblib.dump(model,out/f'model_{seed}.joblib');record={'seed':seed,'training_ids':[r['id'] for r in selected],'gate_ids':[r['id'] for r in gate],'audit_ids':[r['id'] for r in audit],'candidate_rules':[list(k) for k,v in candidates],'admitted_rules':rules,'admission_log':log,'audit':stats,'runtime_seconds':time.monotonic()-start};(out/f'train_{seed}.json').write_text(json.dumps(record,indent=2));manifest['seeds'][str(seed)]={'candidate_rules':len(candidates),'admitted_rules':len(rules),'audit':stats,'seconds':record['runtime_seconds']};(out/'training_manifest.json').write_text(json.dumps(manifest,indent=2));print(seed,manifest['seeds'][str(seed)],flush=True)
 manifest['code_sha256']={f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in ['src/external_kinship.py','src/train_external_kinship.py','configs/external_kinship_v1.json']};manifest['runtime_end_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());(out/'training_manifest.json').write_text(json.dumps(manifest,indent=2))
if __name__=='__main__':main()
