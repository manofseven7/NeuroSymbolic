"""Confirmation of the program-constrained variant on fresh worlds."""
import csv,json,itertools,time
from pathlib import Path
import numpy as np
import search_recovered as s
import probe_program_actions as p

def main():
    cfg=json.loads(Path('configs/program_action_confirmation.json').read_text())
    out=Path('results/program_action_confirmation');out.mkdir(exist_ok=False);rows=[];audits=[];start=time.time()
    (out/'protocol.json').write_text(json.dumps(cfg,indent=2))
    with (out/'traces.jsonl').open('w') as f:
        for ii,seed in enumerate(cfg['confirmation_seeds']):
            b=p.prepare(s.bank(seed))
            for case,noise,method in itertools.product(s.CASES,[0.,.1],['wide_entropy','wide_ec2','predictive_risk','point_predictive_risk']):
                program=method!='point_predictive_risk';policy=method if program else 'predictive_risk'
                s.decide=p.program_decide if program else p.ORIGINAL_DECIDE
                s.scores=p.program_scores if program else p.ORIGINAL_SCORES
                row,trace=s.episode(b,case,noise,policy);row['method']=method;rows.append(row)
                f.write(json.dumps({'metrics':row,'queries':trace})+'\n');f.flush()
                if program:
                    post=b['prior'].copy()
                    for q,o in trace:
                        k=5 if b['w'].queries[q][0]=='anchor' else 3
                        post*=np.where(b['resp'][:,q]==o,1-noise,noise/(k-1))
                        if post.sum()<1e-200:break
                        post/=post.sum()
                    z=b['pred'][0] if post.sum()<1e-200 else p.program_decide(b,post)[0]
                    audits.append(dict(seed=seed,case=case,noise=noise,policy=policy,**p.replay(b,z)))
            print(f'program confirmation {ii+1}/{len(cfg["confirmation_seeds"])} rows={len(rows)}',flush=True)
    with (out/'episodes.csv').open('w') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    (out/'proof_replay.json').write_text(json.dumps(audits,indent=2))
    (out/'execution.json').write_text(json.dumps(dict(seconds=time.time()-start,episodes=len(rows),code_sha=s.sha(__file__),program_module_sha=s.sha(p.__file__),search_module_sha=s.sha(s.__file__),numpy=np.__version__),indent=2))

if __name__=='__main__':main()
