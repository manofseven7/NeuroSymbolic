import collections,csv,json
from pathlib import Path
import numpy as np

def main():
    p=Path('results/text_pilot_v1');rows=list(csv.DictReader((p/'episodes.csv').open()));summary=[]
    for case,noise,budget,policy in sorted(set((r['case'],r['noise'],r['budget'],r['policy']) for r in rows)):
        rr=[r for r in rows if (r['case'],r['noise'],r['budget'],r['policy'])==(case,noise,budget,policy)]
        summary.append(dict(case=case,noise=float(noise),budget=int(budget),policy=policy,accuracy=sum(int(r['correct']) for r in rr)/len(rr),records=len(rr),mean_spent=sum(int(r['spent']) for r in rr)/len(rr)))
    (p/'summary.json').write_text(json.dumps(summary,indent=2))
    focus=[r for r in rows if r['case']!='clean' and r['budget']=='2'];comparisons=[];rng=np.random.default_rng(20261028)
    for comparator in ['static','entropy','ec2']:
        a={(r['id'],r['case'],r['noise']):r for r in focus if r['policy']=='risk'}
        b={(r['id'],r['case'],r['noise']):r for r in focus if r['policy']==comparator};clusters=collections.defaultdict(lambda:[0,0])
        for k,r in a.items():clusters[r['group']][0]+=int(r['correct'])-int(b[k]['correct']);clusters[r['group']][1]+=1
        vals=np.array(list(clusters.values()));ix=rng.integers(0,len(vals),size=(1000,len(vals)));num=vals[ix,0].sum(axis=1);den=vals[ix,1].sum(axis=1);ci=np.quantile(num/den,[.025,.975])
        comparisons.append(dict(comparator=comparator,gain=float(vals[:,0].sum()/vals[:,1].sum()),cluster_95_ci=list(map(float,ci)),contexts=len(vals),note='Exploratory intervals, no multiple-comparison superiority claim; static uses no annotations whereas active policies use equal semantic-annotation budgets.'))
    (p/'comparisons.json').write_text(json.dumps(comparisons,indent=2))
    base=json.loads((p/'clean_baselines.json').read_text());proof=json.loads((p/'clean_proof_audit.json').read_text());stress=json.loads((p/'proof_checks.json').read_text());folio=json.loads((p/'folio_portability.json').read_text())
    q=lambda case,policy,noise:next(r['accuracy'] for r in summary if r['case']==case and r['policy']==policy and r['budget']==2 and r['noise']==noise)
    lines=['# گزارش آزمون متن و شاهد — NS-TEXT-005','',
    'موضوع اصلی مقاله و هسته تشخیص مشترک نگاشت معنا/قواعد حفظ شده است. مطابق ترجیح کاربر، بهبود محدود برای ادامه پژوهش کافی است؛ آستانه قبلی ۲ واحد درصد دیگر شرط ادامه نیست و نتیجه آزمون‌های پیشین بازنویسی نمی‌شود.','',
    '## آزمایش اجراشده','',
    'داده ProofWriter از نسخه عمومی آماده‌شده توسط نویسندگان Logic-LM دریافت و به commit ثابت متصل شد. ۶۰۰ رکورد dev فقط برای توسعه دستور زبان و آموزش دو خط مبنای محلی استفاده شد؛ ۶۰۰ رکورد test برای ارزیابی نهایی بود. به‌ترتیب ۳۴۵ و ۴۵۷ زمینه یکتا وجود دارد و هیچ زمینه یا شناسه مشترکی پیدا نشد. این مجموعه، زیرمجموعه نظریه‌های depth-5 است؛ همه پرسش‌های آن الزاماً پنج مرحله استنتاج ندارند.','',
    'ProofWriter انگلیسی کنترل‌شده دارد؛ آن را نباید متن آزاد انسانی یا حوزه واقعی جدید نامید. مسیر اجراشده عبارت است از مبدل مهندسی‌شده متن به حقایق و قواعد Horn با نفی صریح، انتخاب یک برنامه قابل اجرا، استنتاج و استخراج شاهد، و تولید توضیح قالبی فقط از گام‌های همان شاهد. مبدل فعلی عصبی نیست. مدل عصبی زیر فقط خط مبنای مستقیم طبقه‌بندی پاسخ است.','',
    '## نتیجه روی متن اصلی آزمون','',
    '| روش | دقت | macro-F1 |','|---|---:|---:|']
    names={'tfidf_logistic':'TF-IDF + رگرسیون لجستیک','tfidf_mlp':'TF-IDF + شبکه عصبی MLP با ۶۴ واحد','controlled_english_parser':'مبدل انگلیسی کنترل‌شده + اجرای قواعد'}
    for m,r in base.items():lines.append(f'| {names[m]} | {100*r["accuracy"]:.2f}٪ | {r["macro_f1"]:.4f} |')
    lines+=['','هر ۶۰۰ متن و پرسش آزمون قابل تبدیل بود و هیچ نمونه‌ای از محاسبه دقت حذف نشد. مدل‌های آماری/عصبی فقط روی ۶۰۰ dev آموزش دیده‌اند و مدل زبانی ازپیش‌آموزش‌دیده یا بازتولید روش‌های قوی منتشرشده نیستند. شبکه MLP به سقف ۲۰۰ تکرار رسید و هشدار عدم همگرایی صادر کرد؛ این پارامتر پس از مشاهده آزمون تغییر نکرد. اختلاف بالا با این دو خط مبنای کوچک، اثبات برتری نسبت به مدل‌های زبانی قوی یا نوآوری الگوریتمی نیست.','',
    f'روی متن اصلی، {proof["proofs"]} پاسخ مثبت/منفی دارای شاهد بود؛ تمام آن‌ها با بررسی مستقل گام‌ها نسبت به قواعد و حقایق پارس‌شده اعتبار داشتند. ۲۰۰ پاسخ unknown از نبود هر دو استنتاج حاصل شد. عمق شاهد محاسبه‌شده از ۰ تا ۶ بود؛ این عمق شاهد انتخاب‌شده است و با شاهد طلایی تطبیق داده نشده است.','',
    '## انتقال سازوکار اصلاح به متن','',
    'برای اتصال روش قبلی، هشت تفسیر نامزد از هر متن ساخته شد: ترکیب حفظ/نادیده‌گرفتن نفی حقایق، حفظ/کوتاه‌کردن شرط عطفی قواعد و حفظ/نادیده‌گرفتن نفی نتیجه قواعد. این‌ها خطاهای **تزریق‌شده** هستند، نه خطاهای اندازه‌گیری‌شده یک رمزگذار عصبی. نامزد صحیح در خانواده وجود دارد.','',
    'شاهد جدید در این آزمون، برچسب معنایی یک جمله است؛ مرجع آن مبدل ثابت بود، نه برچسب انسانی. سیاست‌ها پاسخ پرسش هدف را دریافت نمی‌کنند. آنتروپی، EC2 و کاهش ریسک با بودجه معنایی یکسان مقایسه شدند؛ روش ایستا چنین شاهد اضافی نمی‌گیرد. بنابراین سود نسبت به ایستا، اثر اصلاح همراه با نظارت اضافی است و نباید تمام آن را مزیت الگوریتم انتخاب شاهد دانست.','',
    'در مجموع ۳۸٬۴۰۰ اپیزود ثبت شد؛ این شمار شامل تکرار خروجی روش ایستا در شرایط مختلف بودجه/نویز است و تعداد نمونه مستقل یا آموزش مدل نیست. دو بودجه ۱ و ۲، دو سطح نویز صفر و ۱۰٪، چهار وضعیت و چهار سیاست اجرا شدند.','',
    '| وضعیت، بودجه ۲ | ایستا | آنتروپی | کنترل EC2 | کاهش ریسک |','|---|---:|---:|---:|---:|']
    for case,label in [('fact_negation_fault','خطای نفی حقایق'),('rule_fault','خطای قواعد'),('joint_fault','خطای مشترک')]:
        for noise in [0.,.1]:lines.append('| '+label+f'؛ نویز {int(noise*100)}٪ | '+' | '.join(f'{100*q(case,m,noise):.2f}٪' for m in ['static','entropy','ec2','risk'])+' |')
    lines+=['','در متن بدون خطای تزریقی، هر چهار سیاست در هر دو سطح نویز و بودجه ۲ دقت ۱۰۰٪ داشتند. در نویز، EC2 از جانشین یال پسین استفاده می‌کند؛ ضمانت نسخه اصلی نویزی برای آن ادعا نمی‌شود.','']
    for c in comparisons:
        lo,hi=c['cluster_95_ci'];lines.append(f'- کاهش ریسک در برابر {c["comparator"]}، تجمیع سه خطا و هر دو سطح نویز در بودجه ۲: {100*c["gain"]:+.3f} واحد درصد؛ بازه اطمینان اکتشافی [{100*lo:+.3f}، {100*hi:+.3f}].')
    lines+=['','بازنمونه‌گیری ۱٬۰۰۰ بار در سطح زمینه یکتا، با حفظ پرسش‌ها و اپیزودهای وابسته انجام شد. این بازه‌ها اکتشافی‌اند و ادعای برتری چندمقایسه‌ای تأییدی نیستند. برابری تجمیعی با EC2 پنهان نمی‌شود: آزمون، کارکرد اصلاح فعال را نشان داد؛ مزیت الگوریتمی روش ریسک نسبت به کنترل قوی تثبیت نشد.','',
    f'در سیاست ریسک با بودجه ۲، {stress["outputs_checked"]} خروجی بازاجرا و {stress["proofs_checked"]} شاهد مثبت/منفی بررسی شد؛ {stress["invalid"]} شاهد نامعتبر نسبت به **برنامه انتخاب‌شده** ثبت شد. این با وفاداری به معنای درست متن یکسان نیست: برنامه غلط نیز ممکن است شاهد درونی معتبر بدهد. توضیح‌ها قالبی‌اند و ارزیابی انسانی نشده‌اند.','',
    '## کنترل انتقال به متن آزادتر','',
    f'بدون تغییر مبدل پس از آزمون اصلی، روی ۲۰۴ نمونه validation از FOLIO legacy یک کنترل اکتشافی پوشش انجام شد. تنها {folio["fully_parseable"]} نمونه کاملاً قابل پارس بود. از fallback unknown برای ساختن یک عدد دقت ظاهراً قابل قبول استفاده نشد. از فرمول‌های طلایی FOLIO هم استفاده نشد. این نسخه قدیمی داده است، نه نسخه اصلاح‌شده gated.','',
    '**نتیجه:** پل متن کنترل‌شده تا اجرای قواعد و شاهد عملیاتی شد و اصلاح فعال تحت خطاهای کنترل‌شده سود داشت. برای هدف اصلی مقاله، هنوز باید مبدل معنایی یادگرفته‌شده و انتقال به متن و حوزه آزادتر ساخته و ارزیابی شود. دقت ۱۰۰٪ این دستور زبان محدود، نتیجه عمومی فهم زبان نیست. نوآوری، برتری بر مدل‌های زبانی قوی و آمادگی Q1 همچنان ادعا نمی‌شود.','',
    '## شواهد و منابع','',
    '- [ProofWriter، منبع اصلی](https://aclanthology.org/2021.findings-acl.317/): Tafjord, Dalvi, Clark, Findings ACL 2021، DOI 10.18653/v1/2021.findings-acl.317.','- [Logic-LM، مخزن نویسندگان و منشأ زیرمجموعه](https://github.com/teacherpeterpan/Logic-LLM): Pan et al., Findings EMNLP 2023. در این کار مدل Logic-LM و خروجی‌های آماده LLM آن اجرا یا استفاده نشده‌اند.','- commit، هش داده‌ها، کد، پروتکل ثابت، پیش‌بینی تمام نمونه‌ها، رد پرس‌وجو، نتایج همه شرایط و نمونه توضیح‌ها در بسته هستند.','- ۲۸ آزمون پیاده‌سازی پاس شدند؛ از جمله نفی صریح، متغیرها، موجودیت چندکلمه‌ای، رد شاهد دستکاری‌شده و محاسبه مستقل ریسک.','']
    Path('reports/TEXT_PILOT_FA.md').write_text('\n'.join(lines));print(json.dumps({'comparisons':comparisons,'clean':base},indent=2))

if __name__=='__main__':main()
