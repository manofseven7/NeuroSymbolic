"""Evaluation-only reference-facts oracle, never a raw-text method result."""
import csv,json
from pathlib import Path
from external_kinship import supervision,execute,parse_query
ROOT=Path(__file__).resolve().parents[1]
def main():
 p=ROOT/'results/external_kinship_v1';by={r['id']:r for r in csv.DictReader((ROOT/'third_party/CLUTRR_external/test.csv').open(encoding='utf-8-sig'))};rec=json.loads((p/'frozen_42.json').read_text());ids=json.loads((p/'test_split_audit.json').read_text())['test_ids'];correct=0
 for id in ids:
  r=by[id];facts,_=supervision(r);f={pair:(rel,1.,i) for i,(pair,rel) in enumerate(facts.items())};got=execute(f,parse_query(r['query']),rec['bundle_rules']);correct+=got['preferred']==r['target_text']
 out={'seed':42,'questions':len(ids),'correct':correct,'accuracy':correct/len(ids),'scope':'Evaluation-only supplied-reference-facts oracle diagnostic; not raw-language performance and not an eligible baseline or a new method. Frozen rules unchanged.'};(ROOT/'reports/external_transfer_v1/oracle_grounding_diagnostic.json').write_text(json.dumps(out,indent=2));print(out)
if __name__=='__main__':main()
