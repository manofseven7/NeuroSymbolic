"""Independent trace invariants and selected same-environment replay checks."""
import argparse,json
from pathlib import Path
import search_recovered as s

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);a=ap.parse_args();out=Path(a.out)
    records=[json.loads(l) for l in (out/'traces.jsonl').open()];worlds={};checked=0;replayed=0
    for t in records:
        r=t['metrics'];seed=r['seed']
        if seed not in worlds:worlds[seed]=s.d.make_world(seed,{'damage_weight':.5})
        w=worlds[seed];used=[];cost=0
        for q,o in t['queries']:
            assert q not in used;used.append(q);kind,x=w.queries[q]
            cost+=1 if kind=='task' else 2
            assert cost<=8
            assert kind!='task' or x in w.adapt and x not in w.test
            assert 0<=o<(5 if kind=='anchor' else 3)
        assert cost==r['spent'];checked+=1
    # The original primary run is replayed at two worlds, both noise rates.
    if out.name=='search3r_confirmation':
        for seed in [4000,4063]:
            b=s.bank(seed)
            for noise in [0.,.1]:
                old=next(t for t in records if t['metrics']['seed']==seed and t['metrics']['method']=='predictive_risk' and t['metrics']['case']=='new_pair_cycle' and t['metrics']['noise']==noise)
                row,trace=s.episode(b,'new_pair_cycle',noise,'predictive_risk')
                assert row==old['metrics'] and trace==old['queries'];replayed+=1
    elif out.name=='program_action_confirmation':
        import probe_program_actions as prog
        s.decide=prog.program_decide;s.scores=prog.program_scores
        for seed in [8000,8063]:
            b=prog.prepare(s.bank(seed))
            for noise in [0.,.1]:
                old=next(t for t in records if t['metrics']['seed']==seed and t['metrics']['method']=='predictive_risk' and t['metrics']['case']=='new_pair_cycle' and t['metrics']['noise']==noise)
                row,trace=s.episode(b,'new_pair_cycle',noise,'predictive_risk')
                assert row==old['metrics'] and trace==old['queries'];replayed+=1
    result=dict(episodes_checked=checked,worlds=len(worlds),budget_no_repeats_heldout_and_alphabet_checks='PASS',selected_episodes_exact_replay=replayed,scope='same-environment checks; not independent scientific replication')
    (out/'trace_verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))

if __name__=='__main__':main()
