"""Paired question bootstrap: seeds averaged within question, not independent n."""
import csv,json
from collections import defaultdict
import numpy as np
from local_kinship_repair import OUT

def main():
 rows=list(csv.DictReader((OUT/'confirmation_predictions.csv').open()))
 for r in rows:
  for f in ['hops','seed','correct']:r[f]=int(r[f])
 stats={}
 for group,lo,hi in [('all',2,10),('short',2,3),('long',4,10)]:
  rr=[r for r in rows if lo<=r['hops']<=hi];by=defaultdict(lambda:defaultdict(list))
  for r in rr:by[r['id']][r['method']].append(r['correct'])
  stats[group]={}
  for control in ['previous','direct']:
   diff=np.array([np.mean(x['repaired'])-np.mean(x[control]) for x in by.values()]);rng=np.random.default_rng(22022)
   bs=np.concatenate([diff[rng.integers(0,len(diff),(100,len(diff)))].mean(axis=1) for _ in range(100)])
   stats[group][control]={'questions':len(diff),'accuracy_delta':float(diff.mean()),'paired_story_bootstrap_95_interval':np.quantile(bs,[.025,.975]).tolist(),'bootstrap_samples':10000,'bootstrap_seed':22022}
 byhop={str(h):{m:{'n':len(xs),'accuracy':sum(xs)/len(xs)} for m in ['previous','direct','repaired'] if (xs:=[r['correct'] for r in rows if r['hops']==h and r['method']==m])} for h in range(2,11)}
 perseed={str(s):{m:{'n':len(xs),'accuracy':sum(xs)/len(xs)} for m in ['previous','direct','repaired'] if (xs:=[r['correct'] for r in rows if r['hops']>=4 and r['seed']==s and r['method']==m])} for s in [42,43,44]}
 result={'paired_story_bootstrap':stats,'by_hop':byhop,'long_per_seed':perseed,'note':'CI conditions on these3trainingseeds; not a population estimate over all possible fits. Questions cluster seeds.'}
 (OUT/'statistics.json').write_text(json.dumps(result,indent=2))
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 fig,ax=plt.subplots(figsize=(8,4.4))
 for m,label,marker in [('previous','Previous grounding','o'),('direct','Direct classifier','s'),('repaired','Local grounding repair','^')]:
  ax.plot(range(2,11),[100*byhop[str(h)][m]['accuracy'] for h in range(2,11)],marker=marker,label=label)
 ax.set(xlabel='Reference reasoning length (hops)',ylabel='Accuracy (%)',xticks=list(range(2,11)),ylim=(0,100),title='Frozen-model confirmation: 1,026 CLUTRR stories, 3 seeds')
 ax.axvline(3.5,color='gray',linestyle=':',linewidth=1);ax.grid(alpha=.2);ax.legend();fig.tight_layout();fig.savefig(OUT/'confirmation_by_hop.png',dpi=200);plt.close(fig)
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
