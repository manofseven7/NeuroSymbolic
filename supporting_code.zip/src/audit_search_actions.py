"""Structural audit of terminal decisions; does not change selected policy.

Prespecified audit subset: first eight confirmation worlds, every selected
policy episode. Checks if a decision actually has one bank program witness.
"""
import json
from pathlib import Path
import numpy as np
import search_recovered as s

def main():
    p=Path('results/search3r_confirmation')
    chosen=json.loads(Path('results/search3r_development/selection.json').read_text())['selected']
    cfg=json.loads(Path('configs/search_recovered.json').read_text())
    subset=cfg['confirmation_seeds'][:8]
    rows=[];b=None;last=None
    for line in (p/'traces.jsonl').open():
        trace=json.loads(line);r=trace['metrics']
        if r['method']!=chosen or r['seed'] not in subset:continue
        if r['seed']!=last:b=s.bank(r['seed']);last=r['seed']
        post=b['prior'].copy();noise=r['noise'];empty=False
        for q,o in trace['queries']:
            k=5 if b['w'].queries[q][0]=='anchor' else 3
            post*=np.where(b['resp'][:,q]==o,1-noise,noise/(k-1))
            if post.sum()<1e-200:empty=True;break
            post/=post.sum()
        z=b['pred'][0] if empty else s.decide(b,post)[0]
        witnessed=bool(np.any(np.all(b['pred']==z,axis=1)))
        # Compute the cheapest expected loss among retained behavior tables.
        actions=np.unique(b['pred'],axis=0);mar=s.marginal(b,post) if not empty else None
        gap=None
        if not empty:
            source=b['pred'][0];cost=1-mar[actions,np.arange(32)] + .5*(actions!=source)*mar[source,np.arange(32)]
            gap=float(cost.mean(axis=1).min()-s.decide(b,post)[1])
            assert gap>=-1e-12
        rows.append(dict(seed=r['seed'],case=r['case'],noise=noise,bank_witness=witnessed,constrained_expected_loss_gap=gap))
    out=dict(status='structural audit only; no repaired policy performance claim',worlds=subset,episodes=len(rows),without_single_bank_witness=sum(not r['bank_witness'] for r in rows),rows=rows)
    (p/'terminal_program_audit.json').write_text(json.dumps(out,indent=2))
    print({k:v for k,v in out.items() if k!='rows'})

if __name__=='__main__':main()
