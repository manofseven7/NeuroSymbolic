"""Few-rule-label ParaRules transfer, with supplied facts/query meanings.

Frozen original model is preserved. Shared task-specific typed decoder assumes
one positive unary implication per supplied rule unit and a source vocabulary.
These are explicit interface assumptions, not general language understanding.
"""
import copy,csv,hashlib,json,time
from pathlib import Path
import joblib,numpy as np
import learned_parser as l
import text_reasoner as t
from prepare_transfer import normalized

def asttuple(a):return (a[0],tuple(tuple(v) for v in a[1]),tuple(a[2]))

def choices(model,text,vocab):
    w,p=model.distributions(text);labels=list(model.labels)
    attrs=sorted(set(w)&set(vocab))
    if not 2<=len(attrs)<=4:return []
    hs=labels.index('H.PRED');bs=[labels.index(x) for x in ['B0.PRED','B1.PRED'] if x in labels]
    hp={a:float(p[[i for i,v in enumerate(w) if v==a],hs].max()) for a in attrs}
    bp={a:float(p[[i for i,v in enumerate(w) if v==a]][:,bs].sum(axis=1).max()) for a in attrs}
    scores=np.array([np.log(max(hp[a],1e-12))+sum(np.log(max(bp[b],1e-12)) for b in attrs if b!=a) for a in attrs]);prob=np.exp(scores-scores.max());prob/=prob.sum()
    return sorted([(('rule',tuple((b,'?x','',True) for b in attrs if b!=a),(a,'?x','',True)),float(pr)) for a,pr in zip(attrs,prob)],key=lambda x:-x[1])

def target_tags(text,ast,vocab):
    w=l.tokens(text);head=ast[2][0];body={v[0] for v in ast[1]};y=['O']*len(w)
    for i,word in enumerate(w):
        if word==head:y[i]='H.PRED'
        elif word in body:y[i]='B0.PRED'
    return w,y

def train(cfg,root):
    data=json.loads((root/'target_labels.json').read_text());vocab=json.loads((root/'data_audit.json').read_text())['selected']['vocabulary']
    select=json.loads(Path('results/learned_parser_v1/selection.json').read_text());source=joblib.load(Path('results/learned_parser_v1')/(select['selected']+'.joblib'))
    assert hashlib.sha256((Path('results/learned_parser_v1')/(select['selected']+'.joblib')).read_bytes()).hexdigest()==select['model_sha256']
    model=copy.deepcopy(source);model.model.early_stopping=False;model.model.best_loss_=np.inf;model.model._no_improvement_count=0
    if hasattr(model.model,'_optimizer'):del model.model._optimizer
    split=json.loads(Path('results/learned_parser_v1/split.json').read_text());rng=np.random.default_rng(cfg['training_seed']);replay=[split['train'][i] for i in rng.choice(len(split['train']),size=cfg['source_replay_sentences'],replace=False)]
    xx=[];yy=[]
    for s in replay:
        w,y=l.teacher(s);xx.extend(l.features(w));yy.extend(y)
    for item in data['train']*cfg['target_repetitions']:
        w,y=target_tags(item['text'],asttuple(item['ast']),vocab);xx.extend(l.features(w));yy.extend(y)
    lookup={v:i for i,v in enumerate(model.roles)};Y=np.array([lookup[v] for v in yy]);X=model.vectorizer.transform(xx)
    results=[];best=None;bestacc=-1.;start=time.time()
    def assess(m):
        correct=0
        for item in data['validation']:
            cc=choices(m,item['text'],vocab);correct+=bool(cc and normalized(cc[0][0])==normalized(item['ast']))
        return correct/len(data['validation'])
    results.append(dict(epoch=0,validation_rule_exact=assess(source)))
    for ep in range(1,max(cfg['epochs'])+1):
        order=rng.permutation(len(Y));model.model.partial_fit(X[order],Y[order])
        if ep in cfg['epochs']:
            acc=assess(model);results.append(dict(epoch=ep,validation_rule_exact=acc));print('target adaptation',ep,acc,flush=True)
            if acc>bestacc:best=copy.deepcopy(model);bestacc=acc;bestep=ep
    joblib.dump(best,root/'adapted.joblib',compress=3)
    sel=dict(selected_epoch=bestep,validation=results,source_model_sha256=select['model_sha256'],adapted_model_sha256=hashlib.sha256((root/'adapted.joblib').read_bytes()).hexdigest(),frozen_before_transfer_test=True,seconds=time.time()-start,train_rule_labels=len(data['train']),validation_rule_labels=len(data['validation']),supervision='Upstream canonical logic aligned to human rule units,not previous grammar-generated target labels',scope='Gold facts, gold query meanings and supplied rule boundaries;not end-to-end free-text evaluation')
    (root/'selection.json').write_text(json.dumps(sel,indent=2));return source,best

def infer(facts,units,asts,query):
    rr=[(f'f{i}',str(a),asttuple(a)) for i,a in enumerate(facts)]
    rr += [(f'r{i}',text,a) for i,(text,a) in enumerate(zip(units,asts)) if a is not None]
    q=tuple(query);positive=q[:3]+(True,);label,pf,known=t.run(rr,positive)
    present=positive in known;answer=present if q[3] else not present
    return bool(answer),pf,rr,positive,present

def run(cfg,root):
    if (root/'selection.json').exists():raise RuntimeError('Refuse to overwrite frozen selection; fresh output required')
    source,adapted=train(cfg,root);datasets=json.loads((root/'prepared.json').read_text());vocab=json.loads((root/'data_audit.json').read_text())['selected']['vocabulary'];test=datasets['test'];rows=[];traces=[];proofchecks=dict(total=0,invalid=0,reference_aligned=0,absence_cases=0);examples=[];start=time.time()
    for ti,r in enumerate(test):
        units=r['units'];gold=[asttuple(a) for a in r['rule_gold']];rrsources={}
        for name,model in [('source',source),('adapted',adapted)]:
            options=[choices(model,s,vocab) for s in units];asts=[c[0][0] if c else None for c in options];uncertainty=[-sum(pr*np.log(max(pr,1e-12)) for a,pr in c)/np.log(len(c)) if len(c)>1 else 1. for c in options]
            conditions=[('none',0,0,[])]
            if name=='adapted':
                for budget in cfg['budgets']:
                    if budget==0:continue
                    conditions.append(('uncertainty',budget,0,sorted(range(len(units)),key=lambda j:(-uncertainty[j],j))[:budget]))
                    for seed in cfg['random_seeds']:
                        indices=list(map(int,np.random.default_rng(seed+ti*100).permutation(len(units))[:budget]));conditions.append(('random',budget,seed,indices))
            for policy,budget,seed,indices in conditions:
                chosen=list(asts);available=[];unavailable=[]
                for j in indices:
                    if r['annotation_available'][j]:chosen[j]=gold[j];available.append(j)
                    else:unavailable.append(j)
                full=all(a is not None and normalized(a)==normalized(b) for a,b in zip(chosen,gold))
                traces.append(dict(theory_id=r['id'],model=name,policy=policy,budget=budget,seed=seed,queried_rule_units=indices,admitted_units=available,unavailable_annotation_units=unavailable,full_rule_reference_exact=full,missing_parses=sum(a is None for a in chosen),chosen_rules=chosen))
                for q in r['questions']:
                    answer,pf,rr,positive,present=infer(r['facts'],units,chosen,q['query']);valid=None;aligned=None
                    if name=='adapted' and policy=='uncertainty' and budget==max(cfg['budgets']):
                        if present:
                            valid=t.verify(rr,positive,0,pf);proofchecks['total']+=1;proofchecks['invalid']+=not valid
                            aligned=all(not node['id'].startswith('r') or (chosen[int(node['id'][1:])] is not None and normalized(chosen[int(node['id'][1:])])==normalized(gold[int(node['id'][1:])])) for node in pf);proofchecks['reference_aligned']+=aligned
                        else:proofchecks['absence_cases']+=1
                    row=dict(theory_id=r['id'],question_id=q['id'],model=name,policy=policy,budget=budget,seed=seed,prediction=int(answer),gold=int(q['answer']),correct=int(answer==q['answer']),full_rule_reference_exact=int(full),supplied_reference_facts=True,supplied_query_meaning=True,missing_parses=sum(a is None for a in chosen),semantic_labels_spent=len(indices),annotations_unavailable=len(unavailable),derived_positive_literal=int(present),proof_relative_valid=valid,proof_reference_aligned=aligned)
                    rows.append(row)
                    if len(examples)<5 and valid and name=='adapted' and budget==max(cfg['budgets']):examples.append(dict(theory=r['id'],question=q['text'],prediction=answer,gold=q['answer'],query_positive=bool(q['query'][3]),explanation=t.verbalize(rr,pf,0)))
        if (ti+1)%50==0:print('transfer test theories',ti+1,flush=True)
    with (root/'episodes.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    with (root/'traces.jsonl').open('w') as f:
        for r in traces:f.write(json.dumps(r)+'\n')
    (root/'proof_checks.json').write_text(json.dumps(proofchecks,indent=2));(root/'explanation_examples.json').write_text(json.dumps(examples,indent=2));(root/'execution.json').write_text(json.dumps(dict(question_policy_rows=len(rows),theory_policy_traces=len(traces),seconds=time.time()-start,code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_weights_unchanged=True),indent=2));print(proofchecks)

if __name__=='__main__':run(json.loads(Path('configs/transfer_v1.json').read_text()),Path('results/transfer_v1'))
