"""Prepare ParaRules rule-transfer isolation with explicit alignment auditing.

Inputs for this subexperiment are rule paraphrase units, gold facts, and gold
query interpretations. It is NOT an end-to-end free-text benchmark. Rule unit
boundaries are a supplied interface; extracted using upstream rule count.
"""
import collections,hashlib,json,re
from pathlib import Path
import text_reasoner as t

def literals(rep):
    chunks=re.findall(r'\(\s*"([^"]+)"\s+"([^"]+)"\s+"([^"]+)"\s+"([+~\-])"\s*\)',rep)
    out=[]
    for sub,rel,obj,sign in chunks:
        if sign=='~':raise ValueError('NAF not supported in this positive ParaRules experiment')
        out.append((obj.lower(),'?x' if sub=='someone' else sub.lower(),'',sign=='+') if rel=='is' else (rel.lower(),sub.lower(),obj.lower(),sign=='+'))
    if not out:raise ValueError(rep)
    return out

def canonical_rule(item):
    atoms=literals(item['representation']);return ('rule',tuple(sorted(atoms[:-1])),atoms[-1])

def normalized(ast):return (ast[0],tuple(sorted(tuple(a) for a in ast[1])),tuple(ast[2]))

def main():
    source=Path('third_party/RuleTaker_NatLang');out=Path('results/transfer_v1');out.mkdir(exist_ok=False)
    # Vocabulary comes from source-training annotations, not target test gold.
    src=json.loads(Path('third_party/LogicLM_ProofWriter/dev.json').read_text())
    vocab=sorted({a[0] for r in src for _,_,(_,body,head) in t.parse(r['context']) for a in (*body,head) if not a[2]})
    datasets={};audit={};pool={}
    for split in ['train','dev','test']:
        rows=[json.loads(x) for x in (source/f'meta-{split}.jsonl').read_text().splitlines()];prepared=[];ok=0;rules_total=rules_aligned=0
        for r in rows:
            sentences=[s.strip() for s in re.split(r'[.!?]+\s*',r['theory']) if s.strip()]
            gold=[canonical_rule(v) for v in r['rules'].values()];n=len(gold)
            # Fixed interface extraction. Its reliance on supplied rule count
            # is disclosed; this is not claimed as learned segmentation.
            units=sentences[-n:] if len(sentences)>=n else ['']*n
            aligned=[]
            for text,ast in zip(units,gold):
                got={w for w in re.findall('[a-z]+',text.lower()) if w in vocab};wanted={a[0] for a in (*ast[1],ast[2])}
                supported=(got==wanted and len(wanted)==len(ast[1])+1 and all(a[1]=='?x' and not a[2] and a[3] for a in (*ast[1],ast[2])))
                aligned.append(bool(supported));rules_total+=1;rules_aligned+=supported
                if split in ['train','dev'] and supported:pool.setdefault(split,{})[text]=ast
            ok+=all(aligned)
            facts=[('fact',(),literals(v['representation'])[0]) for v in r['triples'].values()]
            qs=[dict(id=qid,text=q['question'],query=literals(q['representation'])[0],answer=bool(q['answer']),strategy=q['strategy']) for qid,q in r['questions'].items()]
            prepared.append(dict(id=r['id'],units=units,rule_gold=gold,annotation_available=aligned,facts=facts,questions=qs,upstream_theory_sha256=hashlib.sha256(r['theory'].encode()).hexdigest()))
        datasets[split]=prepared;audit[split]=dict(theories=len(rows),rule_units=rules_total,aligned_units=rules_aligned,fully_aligned_theories=ok,questions=sum(len(r['questions']) for r in prepared))
    # Remove ambiguous training strings and split overlaps; no performance used.
    overlap=set(pool['train'])&set(pool['dev'])
    train=[dict(text=s,ast=a) for s,a in pool['train'].items() if s not in overlap]
    val=[dict(text=s,ast=a) for s,a in pool['dev'].items() if s not in overlap]
    rank=lambda item:hashlib.sha256(item['text'].encode()).hexdigest()
    train.sort(key=rank);val.sort(key=rank)
    train=train[:64];val=val[:32]
    # Test text overlap is an audit only; never choose training based on outcomes.
    testtexts={s for r in datasets['test'] for s in r['units']}
    audit['selected']=dict(train_labels=len(train),validation_labels=len(val),train_test_exact_rule_text_overlap=len({r['text'] for r in train}&testtexts),validation_test_exact_rule_text_overlap=len({r['text'] for r in val}&testtexts),split_rule_text_overlap_removed=len(overlap),vocabulary=vocab)
    (out/'prepared.json').write_text(json.dumps(datasets));(out/'target_labels.json').write_text(json.dumps(dict(train=train,validation=val),indent=2));(out/'data_audit.json').write_text(json.dumps(audit,indent=2))
    print(json.dumps(audit,indent=2))

if __name__=='__main__':main()
