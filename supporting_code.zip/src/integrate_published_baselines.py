"""Integrate completed NS024 measurements into the review manuscript."""
import json,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'results/published_baselines_v1'
PAPER=ROOT/'manuscript/review_version'

def main():
    summary=json.loads((OUT/'comparison_summary.json').read_text())
    assert summary['complete'], 'Never turn an incomplete run into a final article result'
    metrics=summary['metrics'];paired=summary['paired']
    names={'Ours_NS023':'Frozen NS023 adapter','cot':'CoT / Qwen-7B',
        'faithful':'Faithful CoT / author table','faithful_training_only':'Faithful CoT / training table',
        'htt':'HtT / Qwen-7B','EpiGNN2025_shared_grounder':'EpiGNN / query labels',
        'EpiGNN2025_shared_grounder_program':'EpiGNN / program labels'}
    methods=list(names)
    get=lambda m,s:next(x for x in metrics if x['method']==m and x['subset']==s)
    lines=[]
    for m in methods:
        a,b,c=[get(m,s) for s in ['all','short_2_3','long_4_10']]
        lines.append(f"{names[m]} & {a['accuracy_percent']:.2f} & {b['accuracy_percent']:.2f} & {c['accuracy_percent']:.2f} & {a['macro_f1_percent']:.2f}\\\\")
    section=r'''
\subsection{Executed published-method adaptations: NS024}\label{sec:publishedbaselines}
Aggregate scores from other papers do not establish a matched comparison. We therefore execute CoT \cite{wei2022}, Faithful CoT \cite{lyu2023}, HtT \cite{zhu2024} and EpiGNN \cite{khalid2025} on the identical 1,026-story regression test, including its 903 four-to-ten-hop questions. All three training-subset seeds are retained. The 256-story training pools and 128-story admission sets are those used by the frozen NS023 models; no question is dropped after a failed prediction.

The three language-model methods share Qwen2.5-7B-Instruct revision \texttt{a09a35458c702b33eeacc393d103063234e8bc28}, bfloat16 inference, greedy decoding, five fixed demonstrations from each training pool and a 768-new-token cap. Faithful CoT restores natural-language subquestions and symbolic assignments and calls the authors' CLUTRR solver. Its full author composition table supplies additional symbolic prior knowledge; a separate training-table result controls that difference without another generation call. HtT induces its library from the same training programs, uses the authors' RuleLibrary and tagged knowledge renderer, and retains rules at coverage at least two and confidence at least 0.7. These are controlled local-model adaptations, not reproductions of closed-model scores or the original papers' full training budgets.

EpiGNN reuses the pinned authors' model with 64 hidden units, eight facets, nine shared propagation rounds, 100 epochs and Adam at 0.01. Its checkpoint is selected only on the common admission set. Since its native interface consumes graphs, the frozen NS023 text grounder supplies its test edges. We execute both end-query supervision and an additional program-atom supervision variant using the intermediate facts and training-only inverse/gender labels already available to NS023. End-query supervision wins on admission accuracy in all three seeds; both test variants remain visible. Disconnected test graphs count as incorrect abstentions. The comparison matches story access and, for the graph model, grounding, but does not equalize pretraining information, annotation utilization or computation.

An implementation audit identified incomplete explanation demonstrations in an initial run. Its outputs are preserved as a code-only exploratory adaptation and excluded from the primary table. The corrected run restores Faithful CoT subquestions and HtT extraction/path demonstrations and fixes lexical boundaries in the common answer parser before test-accuracy analysis. Batch size changes from 32 to 128 for throughput; the data, model and token cap remain fixed. All 3,078 NS023 predictions replay unchanged, and all 99 software tests pass, including new input-leakage, inference-target masking, demonstration-format and answer-boundary checks.

\begin{table}[ht]
\centering\small
\caption{NS024 executed adaptations on identical, previously seen CLUTRR inputs. Accuracy columns average three training subsets; Macro-F1 pools their predictions over the fixed training-label space. Short: 123 two/three-hop stories; long: 903 four-to-ten-hop stories. No published-paper score appears in this table.}\label{tab:publishedbaselines}
\begin{tabular}{lrrrr}\toprule
Method & All acc. & Short acc. & Long acc. & Macro-F1\\\midrule
'''+ '\n'.join(lines)+r'''
\bottomrule\end{tabular}
\end{table}

\begin{figure}[ht]
\centering\includegraphics[width=\textwidth]{figures/published_baselines.pdf}
\caption{Measured NS024 comparison. Left: long-depth accuracy. Right: accuracy by reference hop length, averaged across the same three training subsets. These are seen regression results and do not replace independent five-to-ten-hop confirmation.}\label{fig:publishedbaselines}
\end{figure}
'''
    ours=get('Ours_NS023','long_4_10')['accuracy_percent']
    best=max((m for m in methods if m!='Ours_NS023'),key=lambda m:get(m,'long_4_10')['accuracy_percent'])
    score=get(best,'long_4_10')['accuracy_percent']
    interval=next(x for x in paired if x['baseline']==best and x['subset']=='long_4_10')
    section+=(f"\nThe strongest long-depth adapted baseline is {names[best]} at {score:.2f}\\%, versus {ours:.2f}\\% for NS023. "
              f"The paired NS023-minus-baseline difference is {interval['ours_minus_baseline_pp']:+.2f} points, with exploratory 95\\% story-bootstrap interval [{interval['ci95_low']:.2f},{interval['ci95_high']:.2f}]. "
              "Each resampled story keeps its three seed differences together. These intervals condition on the chosen training pools and previously seen test. The experiment establishes a ranking within this limited-data adaptation protocol, rather than a general state-of-the-art claim.\n\\FloatBarrier\n")
    tex=(PAPER/'main.tex').read_text()
    related=r'''
\subsection{Rule induction and systematic relational reasoning}
Faithful CoT couples natural-language subquestions with symbolic reasoning steps whose execution determines the answer \cite{lyu2023}. This makes its solver interface a directly relevant answer-generation control. Executing one generated representation, however, does not by itself establish agreement across a separately specified interpretation family. Our preferred-answer and family-certificate outputs therefore address different questions; the comparison in Section~\ref{sec:publishedbaselines} concerns preferred-answer accuracy.

HtT learns a library by inducing rules from training examples and retaining rules according to their frequency and answer-level success \cite{zhu2024}. Rule induction followed by rule-based deduction is consequently a precedent, not a novelty claim of this article. Statistical rule acceptance also does not establish that all plausible text interpretations were represented. EpiGNN addresses systematic relational reasoning using epistemic graph representations \cite{khalid2025}. Its graph interface separates relational inference from the linguistic grounding required by our target task. We preserve that distinction by reporting a shared-grounder adaptation rather than substituting its original graph-input scores. These comparisons test practical behavior under limited training-story access; they do not turn the certification contract into a new general rule-learning architecture.

'''
    if '\\subsection{Rule induction and systematic relational reasoning}' not in tex:
        tex=tex.replace('\\subsection{Ambiguity, interaction and diagnosis}',related+'\\subsection{Ambiguity, interaction and diagnosis}',1)
    abstract_sentence=(f" On the same seen test, the strongest executed CoT, Faithful CoT, HtT or EpiGNN adaptation reaches {score:.2f}\\% long-depth accuracy under the 256-story protocol, versus {ours:.2f}\\% for the frozen adapter.")
    if 'the strongest executed CoT' not in tex:
        tex=tex.replace('Inverse-example training uses additional training-only gender annotations.',abstract_sentence+' Inverse-example training uses additional training-only gender annotations.',1)
    start='\\subsection{Executed published-method adaptations: NS024}'
    if start in tex:
        a=tex.index(start);b=tex.index('\\section{Discussion and limitations}',a);tex=tex[:a]+section+'\n'+tex[b:]
    else:tex=tex.replace('\\section{Discussion and limitations}',section+'\n\\section{Discussion and limitations}',1)
    tex=tex.replace('revision 14','revision 15').replace('\\begin{thebibliography}{14}','\\begin{thebibliography}{18}')
    refs=r'''
\bibitem{wei2022} J. Wei et al. Chain-of-Thought Prompting Elicits Reasoning in Large Language Models. \emph{NeurIPS}, 35:24824--24837, 2022. \url{https://papers.neurips.cc/paper_files/paper/2022/hash/9d5609613524ecf4f15af0f7b31abca4-Abstract-Conference.html}.
\bibitem{lyu2023} Q. Lyu et al. Faithful Chain-of-Thought Reasoning. \emph{IJCNLP-AACL}, 2023. \url{https://aclanthology.org/2023.ijcnlp-main.20/}.
\bibitem{zhu2024} Z. Zhu, Y. Xue, X. Chen, D. Zhou, J. Tang, D. Schuurmans, and H. Dai. Large Language Models can Learn Rules. \emph{arXiv:2310.07064v3}, 2024. \url{https://arxiv.org/abs/2310.07064}.
\bibitem{khalid2025} I. Khalid and S. Schockaert. Systematic Relational Reasoning With Epistemic Graph Neural Networks. \emph{ICLR}, 2025. \url{https://openreview.net/forum?id=qNp86ByQlN}.
'''
    if '\\bibitem{lyu2023}' not in tex:tex=tex.replace('\\end{thebibliography}',refs+'\\end{thebibliography}')
    (PAPER/'main.tex').write_text(tex)
    shutil.copy2(OUT/'published_baselines.pdf',PAPER/'figures/published_baselines.pdf')
    print('Integrated completed NS024 comparison; revision 15')

if __name__=='__main__':main()
