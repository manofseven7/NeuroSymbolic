"""Exact simulated clarification over bounded OR/XOR families.

Not observed human interaction or a new active-learning algorithm: exact finite
budget decision-tree optimization compared with semantic-uncertainty and random.
All consistent interpretation assignments are equally likely in this diagnostic.
"""
from collections import Counter
from functools import lru_cache
from pathlib import Path
import json,math
ROOT=Path(__file__).resolve().parents[1]
VALID={'True','False','Uncertain'}
def policy_values(variants,budget,policy):
    states=[x for x in variants if x['label']!='Inconsistent']
    if not states:return 0.0
    k=len(states[0]['bits'])
    def split(ids,j):return [tuple(i for i in ids if states[i]['bits'][j]==b) for b in (0,1)]
    @lru_cache(None)
    def v(ids,left):
        labels={states[i]['label'] for i in ids}
        if len(labels)==1 and labels<=VALID:return 1.0
        if left==0:return 0.0
        options=[]
        for j in range(k):
            parts=split(ids,j)
            if not all(parts):continue
            val=sum(len(p)/len(ids)*v(p,left-1) for p in parts)
            p=len(parts[0])/len(ids);h=-p*math.log2(p)-(1-p)*math.log2(1-p)
            label_counts=Counter(states[i]['label'] for i in ids)
            def entropy(indices):
                counts=Counter(states[i]['label'] for i in indices)
                return -sum((n/len(indices))*math.log2(n/len(indices)) for n in counts.values())
            ig=entropy(ids)-sum(len(p)/len(ids)*entropy(p) for p in parts)
            cut=sum(1 for ai,i in enumerate(ids) for jj in ids[ai+1:] if states[i]['label']!=states[jj]['label'] and states[i]['bits'][j]!=states[jj]['bits'][j])
            options.append((j,val,h,ig,cut))
        if not options:return 0.0
        if policy=='optimal_certificate':return max(o[1] for o in options)
        if policy=='random':return sum(o[1] for o in options)/len(options)
        if policy=='semantic_uncertainty':return max(options,key=lambda o:(o[2],-o[0]))[1]
        if policy=='label_entropy':return max(options,key=lambda o:(o[3],-o[0]))[1]
        if policy=='ec2':return max(options,key=lambda o:(o[4],-o[0]))[1]
        if policy=='first':return options[0][1]
        raise ValueError(policy)
    return v(tuple(range(len(states))),budget)
def main():
    rs=json.loads((ROOT/'results/folio_certified_v1/records.json').read_text());rows=[]
    for r in rs:
        for budget in (0,1,2,3,4):
            for policy in ['optimal_certificate','random','semantic_uncertainty','label_entropy','ec2','first']:
                rows.append({'id':r['id'],'story_id':r['story_id'],'has_sites':bool(r.get('sites')),'budget':budget,'policy':policy,'expected_certified':policy_values(r['variants'],budget,policy)})
    result={}
    for subset in ['all','with_sites']:
        rr=[r for r in rows if subset=='all' or r['has_sites']];result[subset]={}
        for policy in ['optimal_certificate','random','semantic_uncertainty','label_entropy','ec2','first']:
            result[subset][policy]={str(b):sum(x['expected_certified'] for x in rr if x['budget']==b and x['policy']==policy)/max(1,sum(x['budget']==b and x['policy']==policy for x in rr)) for b in (0,1,2,3,4)}
    result['warning']='Uniform distribution over solver-consistent generated OR/XOR variants. Exact optimum by exhaustive DP, not learned neural policy, no human clarity or NLI accuracy claim. Sites selected before outcomes by syntax, but analysis designed after family outcomes.'
    (ROOT/'results/folio_certified_v1/clarification_rows.json').write_text(json.dumps(rows));(ROOT/'results/folio_certified_v1/clarification_summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if __name__=='__main__':main()
