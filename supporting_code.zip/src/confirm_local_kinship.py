"""Frozen confirmation on another same-corpus config, not domain independence."""
import csv,json,urllib.request
from pathlib import Path
import joblib
import external_kinship as k
from local_kinship_repair import ROOT,OUT,read,digest,evaluate,summarize,write_rows
URL='https://raw.githubusercontent.com/kliang5/CLUTRR_huggingface_dataset/e5b496941e91abb7c319d2618a3ce96752bc4ab7/gen_train234_test2to10/test.csv'
def main():
 frozen=json.loads((OUT/'FROZEN_SELECTION.json').read_text())
 for seed,fr in frozen.items():assert digest(OUT/f'{fr["selected"]}_{seed}.joblib')==fr['model_sha256']
 prior=[r for s in ['train.csv','validation.csv','test.csv'] for r in read(s)];oldfp={k.story_fingerprint(r['story']) for r in prior};oldids={r['id'] for r in prior}
 p=ROOT/'third_party/CLUTRR_external/confirmation_gen234_test.csv'
 if not p.exists():
  with urllib.request.urlopen(URL,timeout=60) as response:p.write_bytes(response.read())
 raw=list(csv.DictReader(p.open(encoding='utf-8-sig')));seen=set();rows=[];excluded={'prior_id':0,'prior_template':0,'within_template':0}
 for r in raw:
  fp=k.story_fingerprint(r['story'])
  if r['id'] in oldids:excluded['prior_id']+=1;continue
  if fp in oldfp:excluded['prior_template']+=1;continue
  if fp in seen:excluded['within_template']+=1;continue
  seen.add(fp);rows.append(r)
 audit={'url':URL,'data_sha256':digest(p),'raw_n':len(raw),'retained_n':len(rows),'exclusions':excluded,'filter':'IDs and name-normalized full stories against all old raw train/val/test; within new dedup','limitations':'same CLUTRR corpus and overlapping phrase templates; not independent real-world domain','model_hash_verified':True}
 (OUT/'confirmation_split_audit.json').write_text(json.dumps(audit,indent=2));print(audit,flush=True)
 results=[]
 for seed in [42,43,44]:
  fr=frozen[str(seed)];rules=fr['rules'];repaired=joblib.load(OUT/f'{fr["selected"]}_{seed}.joblib');previous=joblib.load(ROOT/f'results/external_kinship_v1/model_{seed}.joblib')
  results+=evaluate(repaired,rows,rules,seed,'repaired');results+=evaluate(previous,rows,rules,seed,'previous')
  for r in rows:
   pred=previous.prepare(r['story'],k.parse_query(r['query']))['direct']
   results.append({'id':r['id'],'seed':seed,'method':'direct','hops':int(r['task_name'].split('.')[-1]),'correct':int(pred==r['target_text']),'prediction':pred,'gold':r['target_text'],'answered':1,'ref_edges':0,'recovered':0,'invalid_proof':0,'limited':0})
  write_rows(OUT/'confirmation_predictions.csv',results);print('fresh seed',seed,'questions',len(rows),flush=True)
 # Direct classifier has no extracted edges, so report recall as null.
 core=summarize([r for r in results if r['method']!='direct'])
 core['direct']={g:{'decisions':len(rr),'accuracy':sum(r['correct'] for r in rr)/len(rr)} for g,lo,hi in [('all',2,10),('short',2,3),('long',4,10)] if (rr:=[r for r in results if r['method']=='direct' and lo<=r['hops']<=hi])}
 (OUT/'confirmation_summary.json').write_text(json.dumps(core,indent=2));print(json.dumps(core,indent=2),flush=True)
if __name__=='__main__':main()
