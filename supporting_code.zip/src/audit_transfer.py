"""Matched source controls and heldout-context checks; weights remain frozen."""
import csv,hashlib,json
from pathlib import Path
import joblib,numpy as np
import transfer_rules as x
from prepare_transfer import normalized

def main():
    root=Path('results/transfer_v1');out=root/'audit';out.mkdir(exist_ok=False);cfg=json.loads(Path('configs/transfer_audit_v1.json').read_text());maincfg=json.loads(Path('configs/transfer_v1.json').read_text());data=json.loads((root/'prepared.json').read_text());vocab=json.loads((root/'data_audit.json').read_text())['selected']['vocabulary'];sel=json.loads((root/'selection.json').read_text());oldsel=json.loads(Path('results/learned_parser_v1/selection.json').read_text());models={'source':joblib.load(Path('results/learned_parser_v1')/(oldsel['selected']+'.joblib')),'adapted':joblib.load(root/'adapted.joblib')};rows=[];proofstats=[];examples=[]
    conditions=[('test_source_ablation',data['test'],['source']),('heldout_dev',[r for r in data['dev'] if r['id'] in cfg['confirmation_ids']],['source','adapted'])]
    for cohort,theories,names in conditions:
        for ti,r in enumerate(theories):
            gold=[x.asttuple(a) for a in r['rule_gold']]
            for name in names:
                options=[x.choices(models[name],s,vocab) for s in r['units']];asts=[c[0][0] if c else None for c in options];unc=[-sum(pr*np.log(max(pr,1e-12)) for a,pr in c)/np.log(len(c)) if len(c)>1 else 1. for c in options]
                cond=[('none',0,0,[])]
                for budget in [1,2]:
                    cond.append(('uncertainty',budget,0,sorted(range(len(asts)),key=lambda j:(-unc[j],j))[:budget]))
                    for seed in cfg['random_seeds']:cond.append(('random',budget,seed,list(map(int,np.random.default_rng(seed+ti*100).permutation(len(asts))[:budget]))))
                for policy,budget,seed,indices in cond:
                    chosen=list(asts);admitted=[]
                    for j in indices:
                        if r['annotation_available'][j]:chosen[j]=gold[j];admitted.append(j)
                    full=all(a is not None and normalized(a)==normalized(b) for a,b in zip(chosen,gold))
                    for q in r['questions']:
                        answer,pf,rr,positive,present=x.infer(r['facts'],r['units'],chosen,q['query'])
                        rows.append(dict(cohort=cohort,theory_id=r['id'],question_id=q['id'],model=name,policy=policy,budget=budget,seed=seed,correct=int(answer==q['answer']),prediction=int(answer),gold=int(q['answer']),full_rule_reference_exact=int(full),spent=len(indices)))
        print('audit cohort',cohort,len(theories),flush=True)
    # Audit primary adapted uncertainty budget2, retaining an honest distinction
    # between computational proof validity and verified source interpretation.
    traces=[json.loads(line) for line in (root/'traces.jsonl').read_text().splitlines()]
    for r in data['test']:
        trace=next(v for v in traces if v['theory_id']==r['id'] and v['model']=='adapted' and v['policy']=='uncertainty' and v['budget']==2);chosen=[None if a is None else x.asttuple(a) for a in trace['chosen_rules']];gold=[x.asttuple(a) for a in r['rule_gold']];admitted=set(trace['admitted_units'])
        for q in r['questions']:
            answer,pf,rr,positive,present=x.infer(r['facts'],r['units'],chosen,q['query'])
            if not present:continue
            used={int(node['id'][1:]) for node in pf if node['id'].startswith('r')};certified=used<=admitted;aligned=all(chosen[j] is not None and normalized(chosen[j])==normalized(gold[j]) for j in used)
            proofstats.append(dict(theory_id=r['id'],question_id=q['id'],certified=certified,source_aligned=aligned,used_rules=len(used),proof_nodes=len(pf)))
            if len(examples)<8 or (not aligned and not any(e['source_alignment_audit']==False for e in examples)):
                rendered=x.t.verbalize(rr,pf,0);rendered['positive_literal_supported']=True;rendered['answer_to_original_question']=bool(answer);rendered['relation_to_question']='supports_positive_question' if q['query'][3] else 'refutes_negative_question';rendered.pop('answer',None)
                for node in rendered['steps']:
                    node['interpretation_status']='supplied_structured_fact' if node['source_id'].startswith('f') else 'verified_by_queried_reference' if int(node['source_id'][1:]) in admitted else 'unverified_neural_interpretation'
                examples.append(dict(theory_id=r['id'],question=q['text'],gold_answer=q['answer'],explanation=rendered,all_rule_interpretations_queried=certified,source_alignment_audit=aligned,audit_note='source alignment uses researcher-only upstream gold,not available to an unqueried inference step'))
    with (out/'episodes.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    (out/'proof_status.json').write_text(json.dumps(proofstats,indent=2));(out/'explanation_examples_readable.json').write_text(json.dumps(examples,indent=2))
    stats=dict(derived_literal_proofs=len(proofstats),certified_proofs=sum(r['certified'] for r in proofstats),certified_source_disagreements=sum(r['certified'] and not r['source_aligned'] for r in proofstats),uncertified_source_disagreements=sum(not r['certified'] and not r['source_aligned'] for r in proofstats),note='Certification conditional on supplied correct facts and trusted queried reference ASTs. Absence claims are not certified by an empty proof.')
    (out/'proof_status_summary.json').write_text(json.dumps(stats,indent=2));print(stats)

if __name__=='__main__':main()
