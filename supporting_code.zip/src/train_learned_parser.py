import hashlib,json,time,warnings
from pathlib import Path
import joblib,numpy as np
from sklearn.metrics import accuracy_score
import learned_parser as l
import text_reasoner as t

def main():
    cfg=json.loads(Path('configs/learned_parser_v1.json').read_text());out=Path('results/learned_parser_v1');out.mkdir(exist_ok=False)
    dev=json.loads(Path('third_party/LogicLM_ProofWriter/dev.json').read_text());train,val=l.split_sentences(dev)
    (out/'split.json').write_text(json.dumps(dict(train=train,validation=val),indent=2))
    results=[];models={}
    for kind,hidden in [('logistic',0)]+[('mlp',h) for h in cfg['hidden_sizes']]:
        name=kind+str(hidden);start=time.time();model=l.Parser(kind,hidden,cfg['seed'])
        with warnings.catch_warnings(record=True) as ww:
            warnings.simplefilter('always');model.fit(train)
        correct=valid=nt=ct=0;records=[]
        for s in val:
            w,g=l.teacher(s);_,pp=model.distributions(s);tags=model.labels[pp.argmax(axis=1)];nt+=len(g);ct+=sum(a==b for a,b in zip(tags,g));confidence=float(pp.max(axis=1).min())
            try:a=l.decode(w,tags);valid+=1;ok=a==t.sentence(s)
            except t.ParseError:ok=False
            correct+=ok;records.append(dict(sentence=s,correct=bool(ok),confidence=confidence))
        # Confidence calibration uses sentence-disjoint validation only.
        threshold=1.;coverage=0
        for v in sorted(set(r['confidence'] for r in records)):
            rr=[r for r in records if r['confidence']>=v]
            if sum(r['correct'] for r in rr)/len(rr)>=cfg['calibration_precision'] and len(rr)>coverage:threshold=v;coverage=len(rr)
        row=dict(name=name,kind=kind,hidden=hidden,validation_exact=correct/len(val),validation_valid=valid/len(val),token_accuracy=ct/nt,calibrated_threshold=threshold,calibration_coverage=coverage/len(val),seconds=time.time()-start,iterations=int(np.max(model.model.n_iter_)),warnings=[str(w.message) for w in ww])
        results.append(row);models[name]=model;print(row,flush=True)
        joblib.dump(model,out/(name+'.joblib'),compress=3)
    mlps=[r for r in results if r['kind']=='mlp'];best=max(mlps,key=lambda r:(r['validation_exact'],r['token_accuracy'],-r['hidden']))
    selection=dict(selected=best['name'],frozen_before_neural_test=True,rule='MLP validation sentence exact AST,then token accuracy,then smaller hidden size;logistic separate baseline',model_sha256=hashlib.sha256((out/(best['name']+'.joblib')).read_bytes()).hexdigest(),parser_code_sha256=hashlib.sha256(Path('src/learned_parser.py').read_bytes()).hexdigest(),calibration_threshold=best['calibrated_threshold'],results=results,train_sentences=len(train),validation_sentences=len(val),reference_supervision='Development-only grammar teacher; no human annotated semantic parses',test_reuse_note='Same public benchmark test as previous rule-based pilot; no earlier neural parser results used. Not a new external confirmation corpus.')
    (out/'selection.json').write_text(json.dumps(selection,indent=2));print('FROZEN',best['name'])

if __name__=='__main__':main()
