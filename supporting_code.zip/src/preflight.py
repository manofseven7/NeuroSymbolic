"""Finite joint grounding/rule diagnostic reference experiment.

No neural model, no novel algorithm claim. Stdlib-only exact reference engine.
Use: python3 src/preflight.py --config configs/preflight_v1.json --out results/t0
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import itertools
import json
import math
import platform
import random
import resource
import sys
import time
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Rule:
    name: str
    body: tuple[str, ...]
    head: str


def make_rules(bits: tuple[int, int, int]) -> tuple[Rule, ...]:
    a = 2 if bits[0] else 0
    body = (f'p{a}', 'p1')
    if bits[1]:
        body += (f'p{0 if a == 2 else 2}',)
    rs = [Rule('r_gate', body, 'ready'), Rule('r_out', ('ready',), 'approve'),
          Rule('r_reject', (f'!p{a}', '!p1', '!p3'), '!approve')]
    if bits[2]:
        rs.append(Rule('r_alt', ('p3',), 'approve'))
    return tuple(rs)


def closure(facts: set[str], rules: tuple[Rule, ...], disabled=frozenset()) -> set[str]:
    known = set(facts)
    while True:
        new = {r.head for r in rules if r.name not in disabled and set(r.body) <= known}
        if new <= known:
            return known
        known |= new


def label(known: set[str]) -> str:
    pos, neg = 'approve' in known, '!approve' in known
    if pos and neg:
        return 'INCONSISTENT'
    return 'entailment' if pos else ('contradiction' if neg else 'unknown')


def canonical_facts(raw, mapping) -> set[str]:
    return {('' if val else '!') + f'p{mapping[i]}' for i, val in enumerate(raw)}


def execute(raw, mapping, bits) -> str:
    return label(closure(canonical_facts(raw, mapping), make_rules(bits)))


def proof_supports(facts: set[str], rules: tuple[Rule, ...]) -> dict[str, set[frozenset[str]]]:
    """Inclusion-minimal fact+rule supports. Not all derivation trees.

    Supports suffice for exact deletion evaluation in this positive Horn fragment.
    Explicit negative atoms are ordinary atoms; there is no negation-as-failure.
    """
    prov = {f: {frozenset({'fact:' + f})} for f in facts}
    while True:
        changed = False
        for r in rules:
            if not all(b in prov for b in r.body):
                continue
            candidates = set(prov.get(r.head, set()))
            for combination in itertools.product(*(prov[b] for b in r.body)):
                candidates.add(frozenset().union(*combination, {'rule:' + r.name}))
            minimal = {s for s in candidates if not any(t < s for t in candidates)}
            if minimal != prov.get(r.head, set()):
                prov[r.head] = minimal
                changed = True
        if not changed:
            return prov


PERMS = list(itertools.permutations(range(4)))
BITS = list(itertools.product((0, 1), repeat=3))
HYPOTHESES = list(itertools.product(PERMS, BITS))
CONTEXTS = list(itertools.product((0, 1), repeat=4))
SOURCE = HYPOTHESES.index(((0, 1, 2, 3), (0, 0, 0)))


def fault_class(hid):
    m, b = HYPOTHESES[hid]
    g, r = m != (0, 1, 2, 3), b != (0, 0, 0)
    return 'both' if g and r else ('grounding' if g else ('rules' if r else 'none'))


def edit_cost(hid):
    m, b = HYPOTHESES[hid]
    return sum(v != i for i, v in enumerate(m)) + sum(b)


def queries(config):
    c = config['query_costs']
    return ([('task', x, c['task_label']) for x in CONTEXTS]
            + [('anchor', i, c['grounding_anchor']) for i in range(4)]
            + [('canonical', x, c['canonical_rule_label']) for x in CONTEXTS])


def answer(hid, q):
    m, b = HYPOTHESES[hid]
    kind, x, _ = q
    if kind == 'anchor':
        return str(m[x])
    return execute(x, m if kind == 'task' else (0, 1, 2, 3), b)


def entropy(n):
    return math.log2(n) if n else 0.0


def class_gini(ids):
    counts = {}
    for i in ids:
        k = fault_class(i)
        counts[k] = counts.get(k, 0) + 1
    return 1 - sum((v / len(ids)) ** 2 for v in counts.values())


def choose(ids, eligible, policy, table, qs, rng):
    if policy == 'mixed_random':
        return rng.choice(eligible)
    scores = []
    for j in eligible:
        groups = {}
        for i in ids:
            groups.setdefault(table[i][j], []).append(i)
        if policy == 'mixed_fault_gini':
            gain = class_gini(ids) - sum(len(g) / len(ids) * class_gini(g) for g in groups.values())
        else:
            gain = entropy(len(ids)) - sum(len(g) / len(ids) * entropy(len(g)) for g in groups.values())
        scores.append((gain / qs[j][2], j))
    best = max(s for s, _ in scores)
    return rng.choice([j for s, j in scores if abs(s - best) < 1e-12])


def sanity():
    tests = []
    def check(name, cond):
        if not cond:
            raise AssertionError(name)
        tests.append(name)
    # Independent forward-engine agreement on a single rule and a two-hop chain.
    rs = (Rule('a', ('p0',), 'mid'), Rule('b', ('mid',), 'approve'))
    check('two_hop_closure', 'approve' in closure({'p0'}, rs))
    check('explicit_unknown', label(closure(set(), rs)) == 'unknown')
    check('explicit_contradiction', label({'!approve'}) == 'contradiction')
    check('inconsistency_separate', label({'approve', '!approve'}) == 'INCONSISTENT')
    redundant = (Rule('a', ('p0',), 'approve'), Rule('b', ('p1',), 'approve'))
    check('redundant_rule_deletion_preserves_label',
          label(closure({'p0', 'p1'}, redundant, frozenset({'a'}))) == 'entailment')
    check('all_supports_removed_yields_unknown',
          label(closure({'p0', 'p1'}, redundant, frozenset({'a', 'b'}))) == 'unknown')
    # Exhaustively check support deletion against rerunning the forward reasoner.
    replay = 0
    contradictions = 0
    multi = 0
    for bits in BITS:
        rs = make_rules(bits)
        names = [r.name for r in rs]
        for x in CONTEXTS:
            facts = canonical_facts(x, (0, 1, 2, 3))
            prov = proof_supports(facts, rs)
            contradictions += label(closure(facts, rs)) == 'INCONSISTENT'
            multi += len(prov.get('approve', set())) > 1
            for deleted_bits in itertools.product((False, True), repeat=len(names)):
                deleted = {n for n, d in zip(names, deleted_bits) if d}
                known = closure(facts, rs, frozenset(deleted))
                for atom in ('approve', '!approve'):
                    predicted = any(not ({'rule:' + n for n in deleted} & support)
                                    for support in prov.get(atom, set()))
                    if predicted != (atom in known):
                        raise AssertionError('proof replay mismatch')
                    replay += 1
    check('all_reference_programs_consistent', contradictions == 0)
    check('multi_proof_cases_present', multi > 0)
    check('exhaustive_rule_deletion_replay', replay > 0)
    return {'passed': tests, 'replay_checks': replay, 'multi_proof_contexts': multi}


def run(config_path, out):
    started = time.perf_counter()
    out.mkdir(parents=True, exist_ok=True)
    config_bytes = config_path.read_bytes()
    cfg = json.loads(config_bytes)
    qs = queries(cfg)
    table = [[answer(i, q) for q in qs] for i in range(len(HYPOTHESES))]
    sanity_results = sanity()
    task_vectors = [tuple(row[:len(CONTEXTS)]) for row in table]
    equivalence = {}
    for i, vector in enumerate(task_vectors):
        equivalence.setdefault(vector, []).append(i)
    mixed_vectors = {tuple(row) for row in table}
    ambiguous_groups = [g for g in equivalence.values() if len({fault_class(i) for i in g}) > 1]
    witness = next((g for g in ambiguous_groups if SOURCE in g), ambiguous_groups[0])
    witness_ids = next((i, j) for i in witness for j in witness if fault_class(i) != fault_class(j))
    records = []
    trace_path = out / 'query_traces.jsonl'
    with trace_path.open('w') as tf:
        for seed in cfg['seeds']:
            for truth in range(len(HYPOTHESES)):
                for policy in cfg['policies']:
                    for budget in cfg['budgets']:
                        rng = random.Random(seed * 100000 + truth * 100 + budget)
                        ids = list(range(len(HYPOTHESES)))
                        used = set()
                        spent = 0
                        trace = []
                        while len(ids) > 1:
                            eligible = [j for j, q in enumerate(qs) if j not in used
                                        and spent + q[2] <= budget
                                        and (policy != 'labels_entropy' or q[0] == 'task')]
                            # Do not pay for a query that all candidates answer identically.
                            eligible = [j for j in eligible if len({table[i][j] for i in ids}) > 1]
                            if not eligible:
                                break
                            j = choose(ids, eligible, policy, table, qs, rng)
                            observed = table[truth][j]
                            before = len(ids)
                            ids = [i for i in ids if table[i][j] == observed]
                            assert truth in ids and ids
                            used.add(j)
                            spent += qs[j][2]
                            trace.append({'query': j, 'kind': qs[j][0], 'outcome': observed,
                                          'cost': qs[j][2], 'before': before, 'after': len(ids)})
                        selected = min(ids, key=lambda i: (edit_cost(i), i))
                        outcomes = [table[truth][j] for j in range(16)]
                        task_acc = sum(table[selected][j] == outcomes[j] for j in range(16)) / 16
                        covered = [j for j in range(16) if len({table[i][j] for i in ids}) == 1]
                        wrong = sum(table[ids[0]][j] != outcomes[j] for j in covered)
                        source_outcomes = table[SOURCE][:16]
                        was_correct = [j for j in range(16) if source_outcomes[j] == outcomes[j]]
                        damaged = sum(table[selected][j] != outcomes[j] for j in was_correct)
                        m, b = HYPOTHESES[selected]
                        tm, tb = HYPOTHESES[truth]
                        unneeded = int(tm == (0,1,2,3) and m != tm) + int(tb == (0,0,0) and b != tb)
                        rec = {'seed': seed, 'truth': truth, 'fault': fault_class(truth), 'policy': policy,
                               'budget': budget, 'spent': spent, 'queries': len(trace), 'candidates': len(ids),
                               'parameter_exact': int(selected == truth),
                               'fault_exact': int(fault_class(selected) == fault_class(truth)),
                               'task_accuracy': task_acc, 'coverage': len(covered)/16,
                               'selective_errors': wrong, 'unnecessary_block_edits': unneeded,
                               'damaged_source_correct': damaged, 'source_correct_count': len(was_correct)}
                        records.append(rec)
                        tf.write(json.dumps({'experiment_id': cfg['experiment_id'], **rec,
                                             'selected': selected, 'survivors': ids, 'trace': trace})+'\n')
    with (out/'episodes.csv').open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(records[0]))
        w.writeheader(); w.writerows(records)
    groups = []
    metrics = ['spent','queries','candidates','parameter_exact','fault_exact','task_accuracy',
               'coverage','selective_errors','unnecessary_block_edits','damaged_source_correct']
    for policy in cfg['policies']:
        for budget in cfg['budgets']:
            rr = [r for r in records if r['policy'] == policy and r['budget'] == budget]
            groups.append({'policy':policy,'budget':budget,'episodes':len(rr),
                           **{m:sum(r[m] for r in rr)/len(rr) for m in metrics}})
    with (out/'summary.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(groups[0]));w.writeheader();w.writerows(groups)
    witness_json = []
    for i in witness_ids:
        m,b=HYPOTHESES[i]
        witness_json.append({'id':i,'mapping':m,'rule_bits':b,'fault_class':fault_class(i),
                             'all_task_labels':table[i][:16],
                             'rules':[{'name':r.name,'body':r.body,'head':r.head} for r in make_rules(b)]})
    identical_tasks=table[witness_ids[0]][:16] == table[witness_ids[1]][:16]
    assert identical_tasks
    summary = {'experiment_id':cfg['experiment_id'], 'hypotheses':len(HYPOTHESES),
               'task_contexts':16,'query_pool_size':len(qs),'episodes':len(records),
               'task_behavior_classes':len(equivalence),'mixed_evidence_classes':len(mixed_vectors),
               'fault_ambiguous_task_classes':len(ambiguous_groups),
               'hypotheses_in_fault_ambiguous_classes':sum(map(len,ambiguous_groups)),
               'max_task_equivalence_class_size':max(map(len,equivalence.values())),
               'witness':witness_json,'witness_identical_all_task_labels':identical_tasks,
               'sanity':sanity_results,'all_selective_errors':sum(r['selective_errors'] for r in records),
               'runtime_seconds':time.perf_counter()-started,
               'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
               'python':sys.version,'platform':platform.platform(),
               'config_sha256':hashlib.sha256(config_bytes).hexdigest(),
               'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (out/'summary.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps({k:v for k,v in summary.items() if k not in ('witness','python','platform')},indent=2))


if __name__ == '__main__':
    p=argparse.ArgumentParser();p.add_argument('--config',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True);a=p.parse_args();run(a.config,a.out)
