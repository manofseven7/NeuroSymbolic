"""Post-hoc failure localization on frozen NS-020 models; no fit or tuning.
All coverage metrics refer to query-oriented reference proof leaves, not an
exhaustive annotation of natural-language meaning. Oracle results are privileged.
"""
import csv,json,hashlib,joblib,time
from pathlib import Path
from collections import Counter
import numpy as np
import external_kinship as k
ROOT=Path(__file__).resolve().parents[1]
def connected(facts,query):
 known={query[0]}
 for _ in range(len(facts)+1):
  nxt=known|{b for (a,b) in facts if a in known}
  if nxt==known:break
  known=nxt
 return query[1] in known

def main():
 R=ROOT/'results/external_kinship_v1';D=ROOT/'reports/external_failure_diagnosis_v1';D.mkdir(exist_ok=True);fr=json.loads((R/'FROZEN_BEFORE_TEST.json').read_text())
 for file,h in fr['sha256'].items():assert hashlib.sha256((ROOT/file).read_bytes()).hexdigest()==h,file
 source={r['id']:r for r in csv.DictReader((ROOT/'third_party/CLUTRR_external/test.csv').open(encoding='utf-8-sig'))};ids=json.loads((R/'test_split_audit.json').read_text())['test_ids'];output=[];examples=[];start=time.monotonic()
 for seed in [42,43,44]:
  model=joblib.load(R/f'model_{seed}.joblib');rules=json.loads((R/f'frozen_{seed}.json').read_text())['bundle_rules'];stored={(r['id'],r['method']):r for r in map(json.loads,(R/f'predictions_{seed}.jsonl').read_text().splitlines())}
  for id in ids:
   row=source[id];q=k.parse_query(row['query']);ref,_=k.supervision(row);p=model.prepare(row['story'],q);facts=k.selected_facts(p);base=k.execute(facts,q,rules);assert base['preferred']==stored[id,'bundle_0']['prediction'];wrong=[pair for pair,rel in ref.items() if pair not in facts or facts[pair][0]!=rel]
   vary=sorted([i for i,opts in enumerate(p['options']) if opts[0][0]!=opts[1][0]],key=lambda i:(p['options'][i][0][1]-p['options'][i][1][1],i))[:4];pair_i={pair:i for i,pair in enumerate(p['pairs'])};support_possible=all(pair in pair_i and rel in [x[0] for x in (p['options'][pair_i[pair]] if pair_i[pair] in vary else p['options'][pair_i[pair]][:1])] for pair,rel in ref.items())
   corrected=dict(facts);requests=stored[id,'bundle_unc2'].get('semantic_requests',[]);asked_missing=asked_extra=0
   for req in requests:
    pair=tuple(req['pair']);rel=req['semantic_label'];assert rel==ref.get(pair,k.NONE)
    asked_missing+=pair in wrong;asked_extra+=pair not in ref and pair in facts
    if rel==k.NONE:corrected.pop(pair,None)
    else:corrected[pair]=(rel,1.,req['pair_index'])
   corr=k.execute(corrected,q,rules);assert corr['preferred']==stored[id,'bundle_unc2']['prediction']
   oraclefacts={pair:(rel,1.,i) for i,(pair,rel) in enumerate(ref.items())};oracle=k.execute(oraclefacts,q,rules)
   gold=row['target_text'];good=base['preferred']==gold
   kind='correct' if good else 'no_extracted_query_path' if not connected(facts,q) else 'path_but_no_composed_answer' if not base['relations'] else 'gold_derived_but_ranked_wrong' if gold in base['relations'] else 'only_wrong_relations_derived'
   rr={'id':id,'seed':seed,'hops':int(row['task_name'].split('.')[-1]),'entities':len(k.names(row['story'])),'ordered_pairs':len(p['pairs']),'ref_edges':len(ref),'recovered_ref_edges':len(ref)-len(wrong),'missing_ref_edges':len(wrong),'all_ref_edges_present':not wrong,'reference_support_possible_in_initial_family':support_possible,'more_than_two_ref_errors':len(wrong)>2,'corrections':len(requests),'requests_on_missing_reference_edge':asked_missing,'requests_on_extra_nonreference_edge':asked_extra,'ref_errors_after_corrections':sum(pair not in corrected or corrected[pair][0]!=rel for pair,rel in ref.items()),'base_correct':good,'corrected_correct':corr['preferred']==gold,'oracle_correct':oracle['preferred']==gold,'gold_derivable_base':gold in base['relations'],'gold_derivable_oracle':gold in oracle['relations'],'base_limited':base['limited'],'oracle_limited':oracle['limited'],'failure_kind':kind};output.append(rr)
   if len(examples)<8 and rr['hops']>=7 and not good and oracle['preferred']==gold:examples.append({'id':id,'seed':seed,'story':row['story'],'query':q,'gold':gold,'reference_edges':[[*pair,rel] for pair,rel in ref.items()],'missing_edges':[[*pair,ref[pair]] for pair in wrong],'selected_prediction':base['preferred'],'oracle_prediction':oracle['preferred'],'diagnostic':rr})
  print('diagnosis seed',seed,'seconds',round(time.monotonic()-start,2),flush=True)
 with (D/'per_question.csv').open('w') as f:w=csv.DictWriter(f,list(output[0]));w.writeheader();w.writerows(output)
 def summarize(rows):
  n=len(rows);ref=sum(x['ref_edges'] for x in rows)
  return {'seed_question_decisions':n,'unique_questions':len({x['id'] for x in rows}),'mean_entities':float(np.mean([x['entities'] for x in rows])),'mean_ordered_pairs':float(np.mean([x['ordered_pairs'] for x in rows])),'reference_edge_recall':sum(x['recovered_ref_edges'] for x in rows)/ref,'reference_edges_total':ref,'mean_reference_errors':float(np.mean([x['missing_ref_edges'] for x in rows])),'complete_reference_support_fraction':sum(x['all_ref_edges_present'] for x in rows)/n,'support_possible_in_family_fraction':sum(x['reference_support_possible_in_initial_family'] for x in rows)/n,'more_than_two_reference_errors_fraction':sum(x['more_than_two_ref_errors'] for x in rows)/n,'mean_ref_errors_after_two_correction_policy':float(np.mean([x['ref_errors_after_corrections'] for x in rows])),'base_accuracy':sum(x['base_correct'] for x in rows)/n,'corrected_accuracy':sum(x['corrected_correct'] for x in rows)/n,'oracle_accuracy':sum(x['oracle_correct'] for x in rows)/n,'oracle_gold_derivable_fraction':sum(x['gold_derivable_oracle'] for x in rows)/n,'path_limit_cases':sum(x['base_limited'] for x in rows),'oracle_path_limit_cases':sum(x['oracle_limited'] for x in rows),'failure_counts':dict(Counter(x['failure_kind'] for x in rows)),'corrections':sum(x['corrections'] for x in rows),'requested_missing_ref_edges':sum(x['requests_on_missing_reference_edge'] for x in rows),'requested_extra_nonref_edges':sum(x['requests_on_extra_nonreference_edge'] for x in rows)}
 summary={'analysis_id':'NS-EXTERNAL-FAILURE-AUDIT-021','parent_experiment':'NS-EXTERNAL-KINSHIP-020','kind':'posthoc frozen-output reconstruction and privileged-input diagnostic; no training/tuning','all':summarize(output),'short_2_3':summarize([x for x in output if x['hops']<=3]),'long_4_10':summarize([x for x in output if x['hops']>=4]),'by_hop':{str(h):summarize([x for x in output if x['hops']==h]) for h in range(2,11)},'all_base_and_corrected_predictions_match_archive':True,'frozen_hashes_pass':True,'runtime_seconds':time.monotonic()-start,'caveats':['Reference leaf supervision is query-oriented and incomplete; missing its path does not rule out another valid semantic proof.','Oracle changes both missing and extra facts; its gain cannot be attributed exclusively to recall or interpreted as deployable accuracy.','No new model or test-informed revision. Associations by reasoning length are not independent randomized causal tests.'],'input_sha256':{str(f.relative_to(ROOT)):hashlib.sha256(f.read_bytes()).hexdigest() for f in [ROOT/'third_party/CLUTRR_external/test.csv',R/'FROZEN_BEFORE_TEST.json',*[R/f'predictions_{seed}.jsonl' for seed in [42,43,44]]]}}
 (D/'summary.json').write_text(json.dumps(summary,indent=2));(D/'examples.json').write_text(json.dumps(examples,indent=2));print(json.dumps({key:summary[key] for key in ['all','short_2_3','long_4_10']},indent=2))
if __name__=='__main__':main()
