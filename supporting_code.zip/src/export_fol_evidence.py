"""Produce checkable finite models and replay unsat premise support sets."""
import itertools,json
from pathlib import Path
from collections import Counter
import z3
from fol_certifier import Compiler,parse,conjuncts
from finite_fol_model import verify_model
ROOT=Path(__file__).resolve().parents[1]

def export_model(c,m):
    for v in c.constants.values():m.eval(v,model_completion=True)
    universe=m.get_universe(c.domain)
    if universe is None:
        v=m.eval(z3.Const('export_dummy',c.domain),model_completion=True);universe=[v]
    universe=list(universe);index={str(v):i for i,v in enumerate(universe)}
    constants={name:index[str(m.eval(v,model_completion=True))] for name,v in c.constants.items()}
    relations={}
    for name,(arity,f) in c.pred.items():
        true=[]
        for values in itertools.product(range(len(universe)),repeat=arity):
            r=m.eval(f(*[universe[v] for v in values]),model_completion=True)
            if not(z3.is_true(r) or z3.is_false(r)):raise ValueError('Non-Boolean model evaluation')
            if z3.is_true(r):true.append(list(values))
        relations[name]={'arity':arity,'true_tuples':true}
    return {'domain_size':len(universe),'constants':constants,'relations':relations}

def main():
    data=[json.loads(x) for x in (ROOT/'third_party/FOLIO_curated/dataset_rawpairs.jsonl').read_text().splitlines()];byid={x['id']:x for x in data}
    results=json.loads((ROOT/'results/folio_certified_v1/records.json').read_text());out=[];checks=Counter();disagreements=[]
    for r in results:
        row=byid[r['id']];story=byid[r['story_id']];ka=parse(story['FOL_sentence_new']);qa=parse(row['FOL_sentence_new']);c=Compiler();kk=c.compile(ka);q=c.compile(qa)
        for name,value in [('countermodel',False),('witness',True)]:
            check=r['curated'].get('checks',{}).get(name)
            if not check:continue
            if check['status']=='sat':
                s=z3.Solver();s.set(timeout=1500);s.add(kk,q if value else z3.Not(q));status=s.check()
                if status!=z3.sat:raise RuntimeError('Replay mismatch '+r['id'])
                model=export_model(c,s.model());valid=verify_model(ka,qa,model,value)
                if not valid:raise RuntimeError('Independent finite model check failed '+r['id'])
                artifact={'id':r['id'],'kind':name,'question_value':value,'theory_ast':ka,'question_ast':qa,'model':model,'independently_checked':valid};out.append(artifact);checks['finite_models']+=1
                if r['curated']['label']!=r['reference_label']:disagreements.append(artifact)
            elif check['status']=='unsat':
                parts=conjuncts(ka);support=[int(x.split('_')[1]) for x in check['support']];s=z3.Solver();s.set(timeout=1500)
                s.add(*[c.compile(parts[i]) for i in support]);s.add(q if value else z3.Not(q));assert s.check()==z3.unsat;checks['solver_relative_support_replays']+=1
        if r['curated']['label']=='Inconsistent':
            parts=conjuncts(ka);support=[int(x.split('_')[1]) for x in r['curated']['inconsistent_core']];s=z3.Solver();s.set(timeout=1500);s.add(*[c.compile(parts[i]) for i in support]);assert s.check()==z3.unsat;checks['inconsistent_core_replays']+=1
    p=ROOT/'results/folio_certified_v1';(p/'finite_models.json').write_text(json.dumps(out,ensure_ascii=False));(p/'reference_disagreement_models.json').write_text(json.dumps(disagreements,ensure_ascii=False,indent=2))
    summary={**checks,'invalid_models':0,'reference_disagreement_question_ids':sorted({x['id'] for x in disagreements}),'note':'Models checked by pure Python relational interpreter, unsat support replays still trust Z3; no claim of semantic correctness of input formulas.'};(p/'evidence_audit.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
