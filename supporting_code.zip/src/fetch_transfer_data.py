"""Verify bundled public release files,or fetch exact official release if absent."""
import hashlib,json,tempfile,urllib.request,zipfile
from pathlib import Path

def main():
    p=Path('third_party/RuleTaker_NatLang');meta=json.loads((p/'provenance.json').read_text());missing=[n for n,h in meta['files'].items() if not(p/n).exists() or hashlib.sha256((p/n).read_bytes()).hexdigest()!=h]
    if not missing:print('Bundled official release files verified.');return
    with tempfile.TemporaryFile() as tmp:
        with urllib.request.urlopen(meta['url'],timeout=120) as r:
            while True:
                data=r.read(2**20)
                if not data:break
                tmp.write(data)
        tmp.seek(0);h=hashlib.sha256()
        while data:=tmp.read(2**20):h.update(data)
        assert h.hexdigest()==meta['archive_sha256'];tmp.seek(0)
        with zipfile.ZipFile(tmp) as z:
            for name in missing:
                data=z.read('rule-reasoning-dataset-V2020.2.5.0/original/NatLang/'+name);assert hashlib.sha256(data).hexdigest()==meta['files'][name];(p/name).write_bytes(data)
    print('Exact official release files recovered and verified.')

if __name__=='__main__':main()
