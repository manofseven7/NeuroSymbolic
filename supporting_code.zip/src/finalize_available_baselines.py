"""Package the documented incomplete protocol, preserving the prior manuscript."""
import csv,json,hashlib,shutil,zipfile
from pathlib import Path
import pdfplumber
from analyze_available_baselines import ROOT,OUT,DEST

def main():
    a=json.loads((DEST/'summary.json').read_text());paper=ROOT/'manuscript/review_version'
    tex=(paper/'main.tex').read_text();log=(paper/'main.log').read_text(errors='replace')
    assert 'Overfull' not in log and 'undefined' not in log.lower()
    assert tex.count('\\begin{table}')==15 and tex.count('\\begin{figure}')==10
    assert tex.count('\\bibitem{')==18 and 'revision 15' in tex
    with pdfplumber.open(paper/'main.pdf') as doc:
        assert len(doc.pages)==30
        (ROOT/'reports/manuscript_revision15_text.txt').write_text('\n\n'.join(p.extract_text() or '' for p in doc.pages))
    status={'status':'DOCUMENTED_AVAILABLE_SCOPES; FULL_LLM_COMPARISON_PENDING',
      'paper':'revision15;30pages;15tables;10figures;18references',
      'llm_saved':a['saved_llm_records'],'llm_pending':a['pending_llm_records'],
      'saved_counts':a['saved_counts'],'epignn':'both variants complete3seeds,3078predictions each',
      'ours':'3078predictions replay unchanged',
      'execution':'No continuing LLM worker verified; browser origin approval denied due usage limit',
      'checks':'5newanalysis tests pass;previous99implementation tests historical,not rerun here',
      'no_new_prediction_tuning':True}
    (OUT/'STATUS.json').write_text(json.dumps(status,indent=2))
    note='''Current NS024 checkpoint,31October2026: manuscript revision15 has30pages,15tables,10figures,18references. Same903long stories:3seed NS02331.38%,EpiGNN query12.92%,program12.07%. Complete scheduled LLMseed42: same-seed NS02331.01%,CoT23.81%,Faithful(author)22.04%,Faithful(training)12.29%,HtT20.04%. Saved3334of9234planned LLMresponses;5900pending. No completed3seed LLMranking. Seed43 has256CoT records,excluded from complete-test tables. Browser origin approval denied due usage limit; no continuing worker verified. No methods/prompts adjusted after seed42analysis. 5newanalysis tests pass;previous99implementation tests historical. No SOTA,fresh5to10hop transfer orQ1readiness claim. Prior manuscript14 preserved in history/manuscript_v14_before_NS024. Final3seed analyzer completeness gate remains intact.'''
    (ROOT/'README_CURRENT.md').write_text('# Current review manuscript: revision15\n\n'+note+'\n\nPaper: `manuscript/review_version/main.pdf`. Matching source: `manuscript/review_version/Article_Review_Source.zip`. Persian report: `reports/Published_Baseline_Comparison_FA.md`. Raw-scope metrics,intervals,resource counts,figure and hashes: `results/published_baselines_v1/available_scopes`.\n\nReproduce: `python3 src/analyze_available_baselines.py`; `python3 src/document_available_baselines.py`; `bash manuscript/review_version/build.sh`; `python3 -m unittest discover -s tests -p test_available_baselines.py`. Final all-seed analyzer remains `src/analyze_published_baselines.py` and fails until all planned keys exist. The GPU runner resumes by saved(seed,method,id).\n\nEarlier unused four-hop confirmation48.39%vs45.07%,CI for3.32ppdifference[0.66,5.97],is retained. It contains no fresh5to10hop questions. Original negative and mixed findings and unimplemented differentiable/counterfactual mechanisms remain explicit.\n')
    f=ROOT/'Scientific_Memory.md';s=f.read_text();pos=s.find('### NS024 published baseline execution');s=s[:pos] if pos>=0 else s
    f.write_text(s+'\n### NS024 documented available scopes,31October2026\n'+note+'\n')
    f=ROOT/'Research_State.md';f.write_text('# Current state update:31October2026\n\n'+note+'\n\nPublication gate remains REVISE.\n\n## Historical state below\n\n'+f.read_text())
    f=ROOT/'Experiment_Registry.csv'
    with f.open() as h:rows=list(csv.DictReader(h));fields=list(rows[0])
    for r in rows:
        if r['experiment_id']=='NS-PUBLISHED-BASELINES-024':
            r['status']='AVAILABLE_SCOPES_DOCUMENTED_FULL_LLM_PENDING'
            r['end_time_note']='31October2026 analysis and manuscriptrevision15;no newGPUrunverified'
            r['notes']='Epi3seedscomplete;LLMseed42complete;3334saved5900pending;5analysistestspass;browserusageblocked;scopesnotpooled'
    with f.open('w') as h:w=csv.DictWriter(h,fieldnames=fields);w.writeheader();w.writerows(rows)
    (paper/'README.md').write_text('Revision15:30pages,15tables,10figures,18references. Adds complete3seed EpiGNN and explicitly preliminary LLMseed42 results in separate tables and Figure10,with paired story intervals and generation costs.5900LLMresponses pending;no final3seed LLMranking. Earlier negative/mixed findings retained. Build with bash build.sh. Figure assets in figures/. Full project contains raw predictions. Revision14 preserved in project history.\n')
    source=paper/'Article_Review_Source.zip';temp=source.with_suffix('.zip.partial')
    with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED) as z:
        for n in ['main.tex','build.sh','README.md']:z.write(paper/n,n)
        for f in sorted((paper/'figures').iterdir()):
            if f.is_file():z.write(f,'figures/'+f.name)
    temp.replace(source)
    dest=Path('/workspace/scratch/6dfb071ca846/deliverables');dest.mkdir(exist_ok=True)
    shutil.copy2(paper/'main.pdf',dest/'NeuroSymbolic_Manuscript_v15.pdf')
    (ROOT/'reports/manuscript_revision15_QA.md').write_text('Revision15 QA:30pages,15tables,10figures,18refs,230wordabstract. No Overfull/undefined/warning messages after final LaTeX build. Separate3seed/single-seed tables and same-seed control.10000story resamples;full3seed completeness guard unchanged.5newanalysis tests pass;previous99test result historical. Front matter,related work,results pages23-25 and references rendered and inspected. Prior manuscript14 retained. No newGPUinference claimed.\n')
    print(json.dumps(status,indent=2))

if __name__=='__main__':main()
