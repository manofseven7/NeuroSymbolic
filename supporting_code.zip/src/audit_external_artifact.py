"""Check frozen provenance, counts, budget, proofs and manuscript numeric rows."""
from pathlib import Path
import json,hashlib
from collections import Counter
from external_kinship import verify_proof
ROOT=Path(__file__).resolve().parents[1]
def main():
 r=ROOT/'results/external_kinship_v1';d=ROOT/'reports/external_transfer_v1';f=json.loads((r/'FROZEN_BEFORE_TEST.json').read_text())
 for file,h in f['sha256'].items():assert hashlib.sha256((ROOT/file).read_bytes()).hexdigest()==h,file
 prov=json.loads((ROOT/'third_party/CLUTRR_external/provenance.json').read_text())
 for row in prov['files']:assert hashlib.sha256((ROOT/'third_party/CLUTRR_external'/(row['split']+'.csv')).read_bytes()).hexdigest()==row['sha256']
 s=json.loads((r/'summary.json').read_text());data=[json.loads(l) for seed in [42,43,44] for l in (r/f'predictions_{seed}.jsonl').read_text().splitlines()];counts=Counter(x['method'] for x in data)
 for m,rr in s['methods'].items():
  sel=[x for x in data if x['method']==m];assert len(sel)==3375==rr['n'];assert sum(x['prediction']==x['gold'] for x in sel)==rr['correct'];assert sum(x['annotations'] for x in sel)==rr['annotations'];assert all(0<=x['annotations']<=2 for x in sel)
  for x in sel:
   if 'semantic_requests' in x:assert x['annotations']==len(x['semantic_requests'])
 proofcount=0
 for seed in [42,43,44]:
  for line in (r/f'proofs_{seed}.jsonl').read_text().splitlines():
   row=json.loads(line);facts={(x[0],x[1]):tuple(x[2:]) for x in row['facts']};assert verify_proof(row['proof'],facts,row['rules']);proofcount+=1
 assert proofcount==516
 tex=(ROOT/'manuscript/review_version/main.tex').read_text();mapping={'Direct logistic':'direct_logistic','Nearest prototype':'nearest_prototype','No composition':'no_composition','Strict greedy gate':'greedy_gate_0','Ungated / coherent bundle':'bundle_0','Bundle + uncertainty, budget 2':'bundle_unc2','Bundle + random, budget 2':'bundle_rand2','Ungated + always two corrections':'ungated_always2'}
 for name,key in mapping.items():
  z=s['methods'][key];row=f"{name} & {100*z['accuracy']:.2f} & {100*z['macro_f1']:.2f} & {z['annotations']:,}";assert row in tex,row
 assert 'Ran 87 tests' in (d/'all_tests.log').read_text() and (d/'all_tests.log').read_text().rstrip().endswith('OK')
 result={'freeze_hashes_pass':True,'dataset_hashes_pass':True,'same_1125_questions_all_methods':True,'three_seeds':True,'predictions':len(data),'methods':len(counts),'annotation_budgets_pass':True,'proofs_replayed':proofcount,'external_table_matches':True,'all_tests':87,'core_not_tuned_after_test':True,'posthoc_short_depth_marked':True,'primary_external_outcome':'FAIL_BROAD_GENERALIZATION','publication_gate':'REVISE'};(d/'Artifact_Audit.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
if __name__=='__main__':main()
