"""Predeclared world-level summaries; no candidate tuning."""
import argparse
import csv
from collections import defaultdict
import json
from pathlib import Path
import numpy as np


METRICS=['accuracy','macro_f1','source_accuracy','damage_fraction_all','damage_conditional',
         'weighted_loss','fault_exact','state_exact','coverage','empty_candidate_set','spent']


def main(config,out):
    cfg=json.loads(config.read_text());rows=list(csv.DictReader((out/'episodes.csv').open()))
    groups=defaultdict(list)
    for r in rows:groups[(r['block'],r['scenario'],int(r['anchor_cost']),int(r['budget']),r['policy'])].append(r)
    summaries=[]
    for key,rr in sorted(groups.items()):
        byworld=defaultdict(list)
        for r in rr:byworld[int(r['world'])].append(r)
        summary=dict(zip(['block','scenario','anchor_cost','budget','policy'],key))
        summary['worlds']=len(byworld);summary['episodes']=len(rr)
        for m in METRICS:
            values=[np.mean([float(r[m]) for r in wr]) for wr in byworld.values()]
            summary[m]=float(np.mean(values))
            summary[m+'_world_sd']=float(np.std(values,ddof=1)) if len(values)>1 else 0.
        covered=sum(int(r['selective_covered']) for r in rr);errors=sum(int(r['selective_errors']) for r in rr)
        summary['selective_errors_total']=errors;summary['selective_covered_total']=covered
        summary['selective_risk']=errors/covered if covered else None
        summaries.append(summary)
    with (out/'summary.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(summaries[0]));w.writeheader();w.writerows(summaries)
    primary=[r for r in rows if r['block']=='primary' and r['scenario']=='clean' and r['budget']=='4']
    bypolicy=defaultdict(lambda:defaultdict(list))
    for r in primary:bypolicy[r['policy']][int(r['world'])].append(r)
    rng=np.random.default_rng(cfg['bootstrap_seed']);worlds=cfg['world_seeds']
    index=rng.integers(0,len(worlds),size=(cfg['bootstrap_replicates'],len(worlds)))
    comparisons=[];alpha=.05/len(cfg['primary_comparators'])
    def vals(policy,m):return np.array([np.mean([float(r[m]) for r in bypolicy[policy][s]]) for s in worlds])
    for comparator in cfg['primary_comparators']:
        delta=vals('guarded_risk_voi','accuracy')-vals(comparator,'accuracy')
        boot=delta[index].mean(axis=1)
        lo,hi=np.quantile(boot,[alpha/2,1-alpha/2])
        harm=float(np.mean(vals('guarded_risk_voi','damage_fraction_all')-vals(comparator,'damage_fraction_all')))
        comparisons.append({'candidate':'guarded_risk_voi','comparator':comparator,'endpoint':'clean_budget4_accuracy',
                            'paired_worlds':len(worlds),'mean_difference':float(delta.mean()),
                            'bonferroni_interval_level':1-alpha,'lower':float(lo),'upper':float(hi),
                            'damage_difference':harm,
                            'passes_predeclared_gate':bool(delta.mean()>=.02 and lo>0 and harm<=.01)})
    gate={'experiment_id':cfg['experiment_id'],'primary_comparisons':comparisons,
          'superiority_gate_passed':all(c['passes_predeclared_gate'] for c in comparisons),
          'inference_scope':'Paired uncertainty over independently seeded generated task worlds from one bounded template family; not real domains or neural training runs',
          'no_tuning_after_results':True}
    (out/'primary_gate.json').write_text(json.dumps(gate,indent=2))
    report=[]
    for scenario in cfg['scenarios']:
        for s in summaries:
            if s['block']=='primary' and s['scenario']==scenario and s['budget']==4:
                report.append({k:s[k] for k in ['scenario','policy','accuracy','source_accuracy',
                                               'damage_fraction_all','coverage','selective_risk','empty_candidate_set']})
    print(json.dumps({'budget4':report,'gate':gate},indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--config',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True);a=p.parse_args();main(a.config,a.out)
