"""Post-result diagnostics, separated from preregistered performance tests.

No hyperparameter is changed and no performance benchmark is rerun by this file.
"""
from collections import Counter
import json
from pathlib import Path
import numpy as np
import deep_test as d


def main():
    root=Path(__file__).resolve().parents[1]
    cfg=json.loads((root/'configs/deep_test_v1.json').read_text());out=root/'results/deep_v1'
    w=d.make_world(1000,cfg);found=None
    for mass in [.951,.96,.97,.98,.99]:
        for h in range(1,len(w.states)):
            p=np.zeros(len(w.states));p[0]=1-mass;p[h]=mass
            score=d.all_scores(w,p,d.likelihoods(w,.1),'guarded_risk_voi',cfg,.1)
            q=int(score.argmin())
            if score[q]<-1e-6:
                base=d.terminal(w,p,cfg,True)[1]
                found={'world':1000,'posterior_support':{'source_mass':1-mass,'changed_state':h,'changed_mass':mass},
                       'query_index':q,'query':w.queries[q],'base_expected_loss':base,
                       'expected_loss_after_query':float(base-score[q]),
                       'guarded_expected_risk_reduction':float(score[q]),
                       'ordinary_expected_risk_reduction':float(d.all_scores(w,p,d.likelihoods(w,.1),'risk_voi',cfg,.1)[q]),
                       'interpretation':'Exploratory post-result counterexample; no tuning. Evidence-dependent feasible action sets can make extra evidence increase terminal expected loss.'}
                break
        if found:break
    assert found is not None
    (out/'guard_threshold_counterexample.json').write_text(json.dumps(found,indent=2))
    errors=Counter();first=None
    for seed in cfg['world_seeds']:
        w=d.make_world(seed,cfg);used=set()
        for i in w.adapt:
            prov=d.proof_supports(d.facts(w.contexts[i],tuple(range(5))),w.programs[0])
            for head in ('approve','!approve'):
                for s in prov.get(head,set()):used|={t[5:] for t in s if t.startswith('rule:')}
        for h,(mi,bi) in enumerate(w.states):
            reduced=tuple(r for r in w.programs[bi] if r.name in used)
            for j,x in enumerate(w.contexts):
                y=int(w.predictions[h,j]);z=d.evaluate(x,w.mappings[mi],reduced)
                if y!=z:
                    errors[f'{y}->{z}']+=1
                    if first is None:
                        first={'world':seed,'state':h,'context':list(x),'full_label':y,'sliced_label':z,
                               'source_used_names':sorted(used),'discarded_rules':[r.name for r in w.programs[bi] if r.name not in used]}
    result={'error_label_counts':dict(errors),'total_errors':sum(errors.values()),'first_witness':first,
            'label_codes':d.LABELS,'scope':'Naive source-executed-proof pruning only; not a critique of sound program slicing.'}
    assert result['total_errors']==json.loads((out/'execution.json').read_text())['unsafe_slice_errors']
    (out/'slicing_failure_diagnosis.json').write_text(json.dumps(result,indent=2))
    print(json.dumps({'threshold_counterexample':found,'slicing':result},indent=2))


if __name__=='__main__':main()
