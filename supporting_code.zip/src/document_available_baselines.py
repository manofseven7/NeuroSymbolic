"""Publish measured, separated NS024 scopes without claiming full LLM completion."""
import ast,csv,json,shutil
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from analyze_available_baselines import ROOT,OUT,DEST

PAPER=ROOT/'manuscript/review_version'
NAMES={'Ours_NS023':'Frozen NS023 adapter','cot':'CoT / Qwen-7B',
       'faithful':'Faithful CoT / author rules','faithful_training_only':'Faithful CoT / training rules',
       'htt':'HtT / Qwen-7B','EpiGNN_query':'EpiGNN / query labels','EpiGNN_program':'EpiGNN / program labels'}

def main():
    data=json.loads((DEST/'summary.json').read_text())
    assert data['saved_llm_records']==3334, 'Reanalyze the execution scope if additional results arrive'
    metrics=data['metrics'];pairs=data['paired']
    get=lambda scope,m,subset:next(r for r in metrics if r['scope']==scope and r['method']==m and r['subset']==subset)
    groups={'graph_3seeds':['Ours_NS023','EpiGNN_query','EpiGNN_program'],
            'llm_seed42':['Ours_NS023','cot','faithful','faithful_training_only','htt']}
    plotnames={'Ours_NS023':'NS023','EpiGNN_query':'EpiGNN (query)',
        'EpiGNN_program':'EpiGNN (program)','cot':'CoT','faithful':'Faithful CoT (author)',
        'faithful_training_only':'Faithful CoT (train)','htt':'HtT'}
    fig,axes=plt.subplots(1,2,figsize=(10.4,4.8))
    for ax,(scope,methods) in zip(axes,groups.items()):
        values=[get(scope,m,'long_4_10')['accuracy_percent'] for m in methods]
        ax.barh(np.arange(len(methods)),values,color=['#126982' if m=='Ours_NS023' else '#969fa6' for m in methods])
        ax.set_yticks(np.arange(len(methods)),[plotnames[m] for m in methods],fontsize=13)
        ax.invert_yaxis();ax.set_xlim(0,40);ax.set_xlabel('Long-depth accuracy (%)',fontsize=12)
        ax.tick_params(axis='x',labelsize=11)
        ax.set_title('Graph pipeline: three seeds' if scope=='graph_3seeds' else 'LLM pipelines: seed42 only',fontsize=14)
        for i,v in enumerate(values):ax.text(v+.5,i,f'{v:.2f}',va='center',fontsize=14)
        ax.spines[['top','right']].set_visible(False);ax.grid(axis='x',alpha=.15);ax.set_axisbelow(True)
    fig.suptitle('NS024: long-depth accuracy on 903 seen stories',fontsize=14)
    fig.tight_layout()
    for ext in ['png','pdf']:fig.savefig(DEST/f'available_baselines.{ext}',dpi=180,bbox_inches='tight')
    def mdtable(scope):
        text='| روش | دقت کل | دقت کوتاه | دقت بلند | Macro-F1 کل |\n|---|---:|---:|---:|---:|\n'
        for m in groups[scope]:
            a,b,c=[get(scope,m,s) for s in ['all','short_2_3','long_4_10']]
            text+=f"| {NAMES[m]} | {a['accuracy_percent']:.2f} | {b['accuracy_percent']:.2f} | {c['accuracy_percent']:.2f} | {a['macro_f1_percent']:.2f} |\n"
        return text
    report='''# گزارش مقایسهٔ اجرایی روش‌های منتشرشده، NS024

تاریخ گزارش: ۳۱ اکتبر ۲۰۲۶. این گزارش از فایل پیش‌بینی محاسبه شده است؛ نمره‌های منتشرشدهٔ مقاله‌ها جایگزین اجرا نشده‌اند. دو دامنهٔ اجرای کامل جداگانه داریم: مقایسهٔ سه‌بذری گرافی و مقایسهٔ تک‌بذری مدل‌های زبانی. اجرای کامل سه‌بذری مدل‌های زبانی هنوز ناتمام است.

همهٔ مقایسه‌ها روی ۱٬۰۲۶ سؤال یکسان CLUTRR، شامل ۱۲۳ سؤال کوتاه دو/سه‌مرحله‌ای و ۹۰۳ سؤال بلند چهار تا ده‌مرحله‌ای انجام شده‌اند. داستان‌های آموزشی هر بذر همان ۲۵۶ داستان و مجموعهٔ انتخاب همان ۱۲۸ سؤال NS023 است. این آزمون قبلاً در توسعهٔ روش ما دیده شده است؛ نتایج به معنای تعمیم مستقل به زنجیره‌های بلند نیستند.

## مقایسهٔ گرافی کامل؛ میانگین سه بذر

EpiGNN با کد مدل نویسندگان، ۱۰۰ دوره، ۹ دور انتشار، ۶۴ واحد پنهان و ۸ facet اجرا شد. گراف آزمون از استخراج‌کنندهٔ متن منجمد و مشترک می‌آید. دو نسخهٔ نظارت پاسخ نهایی و نظارت اتم‌های برهان اجرا شدند. نسخهٔ پاسخ نهایی در هر سه بذر روی مجموعهٔ انتخاب بهتر بود؛ هر دو نتیجهٔ آزمون حفظ شده‌اند. این اجرا، انطباق متن‌به‌گراف با بودجهٔ محدود است؛ نتیجهٔ اصلی مقاله روی گراف مرجع محسوب نمی‌شود.

'''+mdtable('graph_3seeds')+'''
## مقایسهٔ زبانی مقدماتی؛ فقط بذر ۴۲

روش ما در این جدول نیز فقط با بذر ۴۲ محاسبه شده است؛ میانگین سه‌بذری آن وارد جدول تک‌بذری نشده است. بذر ۴۲ اولین بذر در ترتیب ثابت اجرای ۴۲، ۴۳، ۴۴ بود و به دلیل نمرهٔ بهتر انتخاب نشده است.

هر سه روش زبانی از Qwen2.5-7B-Instruct با نسخهٔ a09a35458c702b33eeacc393d103063234e8bc28، پنج مثال ثابت از همان مخزن آموزشی، bfloat16، تولید حریصانه و سقف ۷۶۸ توکن استفاده کردند. Faithful CoT از حل‌کننده و جدول قواعد نویسندگان استفاده می‌کند؛ نسخهٔ جدول قواعد آموزشی نیز با همان پاسخ تولیدشده جدا محاسبه شده است. HtT قواعد را از همان داستان‌های آموزشی القا می‌کند و از RuleLibrary و قالب دانش نویسندگان با پوشش حداقل ۲ و اطمینان حداقل ۰٫۷ استفاده می‌کند. این‌ها انطباق‌های کنترل‌شده با مدل مشترک‌اند و بازتولید دقیق مدل بسته یا بودجهٔ اصلی مقاله‌ها نیستند.

'''+mdtable('llm_seed42')+'''
## اختلاف جفت‌شده روی سؤال‌های بلند

بازه‌ها از ۱۰٬۰۰۰ بازنمونه‌گیری داستان‌ها محاسبه شده‌اند. در مقایسهٔ سه‌بذری، اختلاف سه بذر هر داستان با هم نگه داشته شده است. بازه‌های تک‌بذری مشروط به بذر ۴۲ هستند و تغییرپذیری بین بذرها را برآورد نمی‌کنند. همهٔ بازه‌ها اکتشافی و مربوط به آزمون دیده‌شده هستند.

| دامنهٔ اجرا | بیس‌لاین | برتری روش ما (واحد درصد) | بازهٔ ۹۵٪ |
|---|---|---:|---:|
'''
    for r in pairs:
        if r['subset']=='long_4_10':report+=f"| {'سه بذر' if r['scope']=='graph_3seeds' else 'فقط بذر ۴۲'} | {NAMES[r['method']]} | {r['ours_minus_baseline_pp']:+.2f} | [{r['ci95_low']:.2f}, {r['ci95_high']:.2f}] |\n"
    report+='\n## هزینهٔ تولید و خروجی‌ها\n\nزمان‌ها فقط مجموع زمان دسته‌های تولید روی GPU مشترک RTX PRO6000 هستند؛ زمان بارگذاری مدل و القای قواعد را شامل نمی‌شوند و معیار مقایسهٔ سخت‌افزاری CPU/GPU نیستند. زمان تکرارشده در هر رکورد فقط یک بار برای هر دسته محاسبه شده است.\n\n| روش | میانگین توکن ورودی | میانگین توکن خروجی | ثانیهٔ تولید | قطع در سقف توکن (%) |\n|---|---:|---:|---:|---:|\n'
    for r in data['resources']:report+=f"| {NAMES[r['method']]} | {r['mean_input_tokens']:.1f} | {r['mean_output_tokens']:.1f} | {r['generation_seconds']:.1f} | {r['truncated_percent']:.2f} |\n"
    report+='''
## ممیزی، محدودیت‌ها و کار باقی‌مانده

۳٬۳۳۴ پاسخ اصلاح‌شده ذخیره شده‌اند: هر سه روش برای بذر ۴۲ و ۲۵۶ پاسخ CoT برای بذر ۴۳. از ۹٬۲۳۴ پاسخ برنامه‌ریزی‌شده، ۵٬۹۰۰ پاسخ هنوز موجود نیست. نمرهٔ ۲۵۶ سؤال ابتدایی بذر ۴۳ با آزمون کامل مخلوط نشده است. دسترسی مرورگر به Molab به علت سقف مصرف ابزار مسدود شده؛ اجرای تازهٔ ادامهٔ آزمایش تأیید نشده است.

اجرای اولیهٔ Faithful CoT زیرسؤال‌های متنی کامل نداشت و نمونه‌های متنی HtT مراحل استخراج مسیر را کامل نشان نمی‌دادند. ممیزی قالب، پیش از تحلیل تجمیعی دقت آزمون، این موارد را اصلاح کرد. نسخهٔ اولیه در llm_initial_codeonly حفظ و از این جداول کنار گذاشته شد. مرز نام برچسب‌ها نیز اصلاح شد تا great-grandfather به‌اشتباه grandfather شمرده نشود. پس از مشاهدهٔ نتایج تک‌بذری، روش، مثال‌ها یا سقف تولید تغییر نکرده‌اند.

همهٔ ۳٬۰۷۸ پیش‌بینی منجمد روش ما با خروجی قبلی یکسان بودند. ۹۹ آزمون پیاده‌سازی در محیط تأییدشدهٔ قبلی پاس شدند. در این مرحله، پنج آزمون جدید کنترل دامنهٔ تحلیل پاس شدند؛ نتایج دو مجموعهٔ آزمون به‌عنوان یک اجرای تازهٔ کامل گزارش نشده‌اند. پاسخ مرجع وارد ورودی پیش‌بینی نمی‌شود؛ خروجی نامعتبر و گراف قطع‌شده خطا شمرده می‌شوند. Macro-F1 با فضای ثابت ۱۸ برچسب آموزشی محاسبه شده است.

نتیجهٔ قابل گزارش: روش ما در این مقایسهٔ سه‌بذری گرافی و در اجرای تک‌بذری روش‌های زبانی بهتر بوده است. برتری سه‌بذری نسبت به روش‌های زبانی، SOTA عمومی، تعمیم تازهٔ پنج تا ده‌مرحله‌ای و آمادگی قطعی Q1 هنوز اثبات نشده‌اند. این مقایسه همچنین سنجش علّی وفاداری توضیح، ارزیابی انسانی یا پوشش گواهی خانوادهٔ تفسیرها نیست.

کد تحلیل: src/analyze_available_baselines.py. داده و هش فایل‌های خام: results/published_baselines_v1/available_scopes/summary.json. تحلیل نهایی سه‌بذری همچنان با src/analyze_published_baselines.py کنترل می‌شود و تا کامل‌شدن همهٔ پاسخ‌ها خطا می‌دهد.
'''
    (ROOT/'reports/Published_Baseline_Comparison_FA.md').write_text(report)
    def texrows(scope):
        lines=[]
        for m in groups[scope]:
            a,b,c=[get(scope,m,s) for s in ['all','short_2_3','long_4_10']]
            lines.append(f"{NAMES[m]} & {a['accuracy_percent']:.2f} & {b['accuracy_percent']:.2f} & {c['accuracy_percent']:.2f} & {a['macro_f1_percent']:.2f}\\\\")
        return '\n'.join(lines)
    section=r'''
\subsection{Executed published-method adaptations: NS024}\label{sec:publishedbaselines}
We execute CoT \cite{wei2022}, Faithful CoT \cite{lyu2023}, HtT \cite{zhu2024} and EpiGNN \cite{khalid2025} adaptations on the same 1,026-story CLUTRR regression test. Two execution scopes are kept separate: all three scheduled seeds for EpiGNN, and the first scheduled seed, 42, for the completed language-model comparison. All methods receive the same test text/query information, either directly or through the shared grounder. Each seed uses the same 256 training stories and 128 admission stories as NS023. No failed question is removed.

EpiGNN uses the pinned authors' unmodified model logic with 64 hidden units, eight facets, nine shared propagation rounds, 100 epochs and Adam at 0.01. The frozen NS023 text grounder supplies its test graph; a disconnected graph counts as an incorrect abstention. We run both end-query supervision and program-atom supervision with intermediate and inverse/gender training labels already available to NS023. End-query supervision wins on admission accuracy in all three seeds; both test variants remain reported. This is a limited-training text-to-graph adaptation, not a reproduction of the paper's original clean-graph score.

\begin{table}[ht]\centering\small
\caption{Complete three-seed graph adaptation: mean accuracy and pooled Macro-F1 on identical seen inputs. Short: 123 two/three-hop stories; long: 903 four-to-ten-hop stories. Percentages.}\label{tab:publishedgraph}
\begin{tabular}{lrrrr}\toprule
Method & All acc. & Short acc. & Long acc. & Macro-F1\\\midrule
'''+texrows('graph_3seeds')+r'''
\bottomrule\end{tabular}\end{table}

The language-model methods share Qwen2.5-7B-Instruct revision \texttt{a09a35458c702b33eeac\allowbreak c393d103063234e8bc28}, bfloat16 inference, greedy decoding, five fixed demonstrations from the training pool and a 768-new-token cap. Faithful CoT generates natural-language subquestions and symbolic assignments and calls the authors' CLUTRR solver. Its full author rule table supplies additional symbolic prior knowledge; a separate training-table counterpart reuses the identical generated responses. HtT induces its library from the same training programs using the authors' RuleLibrary and tagged knowledge renderer, at coverage at least two and confidence at least 0.7. These are common-backend adaptations, not exact closed-model score reproductions; pretraining information, annotation utilization and computation are not equalized.

\begin{table}[ht]\centering\small
\caption{Preliminary language-model adaptation: seed42 only, including the same seed42 NS023 control. Seed42 was first in the fixed execution order, not selected by its score. Both remaining LLM seeds are incomplete. The table must not be read as a three-seed ranking. Percentages.}\label{tab:publishedllm}
\begin{tabular}{lrrrr}\toprule
Method & All acc. & Short acc. & Long acc. & Macro-F1\\\midrule
'''+texrows('llm_seed42')+r'''
\bottomrule\end{tabular}\end{table}

Tables~\ref{tab:publishedgraph} and~\ref{tab:publishedllm} summarize the separate execution scopes; Figure~\ref{fig:publishedbaselines} displays their long-depth results. On the long-depth questions, NS023 exceeds the admission-selected EpiGNN adaptation by 18.46 points, with exploratory paired 95\% interval [15.61,21.30]. In the single-seed comparison, it exceeds CoT by 7.20 points [3.32,10.96], Faithful CoT with author rules by 8.97 [5.20,12.62], and HtT by 10.96 [7.09,14.84]. We resample 10,000 story clusters, averaging the three seed differences within a story for the graph comparison. Single-seed intervals condition on seed42 and do not estimate variation across training subsets. All comparisons use a previously seen regression test, so neither these intervals nor the positive ranking establish independent long-depth generalization.

\begin{figure}[ht]\centering
\includegraphics[width=\textwidth]{figures/available_baselines.pdf}
\caption{Executed NS024 long-depth results, with execution scopes separated. Left: three-seed graph adaptation. Right: first scheduled LLM seed only. Every panel uses the identical 903 long-depth stories within its own comparison; the panels are not pooled.}\label{fig:publishedbaselines}
\end{figure}

CoT, Faithful CoT and HtT require 272.6, 602.9 and 574.2 seconds of generation for the completed seed, respectively, excluding model loading and rule induction. Their mean output lengths are 70.9, 192.4 and 133.9 tokens. CoT and Faithful CoT have no token-cap truncations; HtT has four (0.39\%). Batch times are counted once per batch. Shared GPU timings do not constitute a matched hardware latency comparison against the CPU adapter.

An implementation audit corrected missing natural-language subquestions in an initial Faithful CoT adaptation, missing extraction/path steps in HtT demonstrations, and answer-label lexical boundaries before aggregate test-accuracy analysis. Initial outputs remain archived separately and are excluded here. The corrected run keeps the model, stories and token cap fixed, using batch128 for throughput. All 3,078 NS023 outputs replay unchanged. The previous implementation audit passed 99 tests; five additional analysis-scope tests now reject duplicates, missing questions, changed answers and seed substitution. These are not presented as one newly rerun combined suite.

Only 3,334 of 9,234 planned LLM test responses are saved: all three methods for seed42 and 256 CoT responses for seed43. Those 256 partial responses are excluded from the complete-test tables. The remaining 5,900 responses are pending after execution access was interrupted. No prompt or model changes follow the seed42 accuracy analysis. The evidence supports a complete three-seed graph comparison and a preliminary single-seed LLM comparison; it does not establish a completed multi-seed LLM ranking, causal explanation faithfulness or human explanation quality.
\FloatBarrier
'''
    original=(PAPER/'main.tex').read_text()
    history=ROOT/'history/manuscript_v14_before_NS024';history.mkdir(parents=True,exist_ok=True)
    for name in ['main.tex','main.pdf','Article_Review_Source.zip']:
        if (PAPER/name).exists() and not (history/name).exists():shutil.copy2(PAPER/name,history/name)
    tex=original
    if '\\subsection{Executed published-method adaptations: NS024}' in tex:
        a=tex.index('\\subsection{Executed published-method adaptations: NS024}');b=tex.index('\\section{Discussion and limitations}',a);tex=tex[:a]+section+'\n'+tex[b:]
    else:tex=tex.replace('\\section{Discussion and limitations}',section+'\n\\section{Discussion and limitations}',1)
    tree=ast.parse((ROOT/'src/integrate_published_baselines.py').read_text())
    strings={}
    for n in ast.walk(tree):
        if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in ['related','refs']:
            strings[n.targets[0].id]=ast.literal_eval(n.value)
    if '\\subsection{Rule induction and systematic relational reasoning}' not in tex:
        tex=tex.replace('\\subsection{Ambiguity, interaction and diagnosis}',strings['related']+'\\subsection{Ambiguity, interaction and diagnosis}',1)
    if '\\bibitem{wei2022}' not in tex:tex=tex.replace('\\end{thebibliography}',strings['refs']+'\\end{thebibliography}')
    abstract_sentence=' A shared-grounder EpiGNN adaptation reaches 12.92\\% versus 31.38\\% across three seeds; a preliminary Qwen-7B CoT adaptation reaches 23.81\\% versus 31.01\\% at one fixed seed. Remaining language-model seeds are pending.'
    if 'a preliminary Qwen-7B CoT adaptation' not in tex:
        tex=tex.replace('Inverse-example training uses additional training-only gender annotations.',abstract_sentence+' Inverse-example training uses additional training-only gender annotations.',1)
    tex=tex.replace('revision 14','revision 15').replace('30 October 2026','31 October 2026').replace('\\begin{thebibliography}{14}','\\begin{thebibliography}{18}')
    (PAPER/'main.tex').write_text(tex)
    shutil.copy2(DEST/'available_baselines.pdf',PAPER/'figures/available_baselines.pdf')
    print('Revision15 written with explicitly incomplete LLM protocol; no final three-seed gate relaxed')

if __name__=='__main__':main()
