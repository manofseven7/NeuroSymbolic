"""Audit-only analysis: no model or query policy changes after seeing T0 results."""
import csv
import hashlib
import itertools
import json
from collections import Counter, defaultdict
from pathlib import Path
import preflight as p


def main():
    root = Path(__file__).resolve().parents[1]
    out = root/'results/t0'
    rows = list(csv.DictReader((out/'episodes.csv').open()))
    grouped = defaultdict(list)
    for row in rows:
        grouped[(row['policy'], row['budget'], row['fault'])].append(row)
    metrics = ['parameter_exact','fault_exact','task_accuracy','coverage','unnecessary_block_edits']
    stratified=[]
    for (policy,budget,fault), rr in sorted(grouped.items()):
        stratified.append({'policy':policy,'budget':int(budget),'fault':fault,'episodes':len(rr),
                           **{m:sum(float(r[m]) for r in rr)/len(rr) for m in metrics}})
    with (out/'per_fault.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(stratified[0]));w.writeheader();w.writerows(stratified)
    balanced=[]
    for policy,budget in sorted({(r['policy'],r['budget']) for r in stratified}):
        rr=[r for r in stratified if r['policy']==policy and r['budget']==budget]
        balanced.append({'policy':policy,'budget':budget,
                         **{m:sum(r[m] for r in rr)/len(rr) for m in metrics}})
    with (out/'macro_fault_summary.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(balanced[0]));w.writeheader();w.writerows(balanced)
    eq=defaultdict(list)
    for i,h in enumerate(p.HYPOTHESES):
        eq[tuple(p.execute(x,*h) for x in p.CONTEXTS)].append(i)
    witness=None
    for group in eq.values():
        pair=next(((i,j) for i,j in itertools.combinations(group,2)
                   if {p.fault_class(i),p.fault_class(j)}=={'grounding','rules'}),None)
        if pair:
            witness=[{'id':i,'mapping':p.HYPOTHESES[i][0],
                      'rule_bits':p.HYPOTHESES[i][1],'fault':p.fault_class(i),
                      'task_labels':[p.execute(x,*p.HYPOTHESES[i]) for x in p.CONTEXTS]}
                     for i in pair]
            break
    assert witness and witness[0]['task_labels']==witness[1]['task_labels']
    fault_upper=sum(max(Counter(p.fault_class(i) for i in g).values()) for g in eq.values())/len(p.HYPOTHESES)
    result={'hypothesis_fault_counts':dict(Counter(p.fault_class(i) for i in range(len(p.HYPOTHESES)))),
            'uniform_prior_full_task_table_exact_parameter_upper_bound':len(eq)/len(p.HYPOTHESES),
            'uniform_prior_full_task_table_fault_accuracy_upper_bound':fault_upper,
            'cross_component_witness':witness,
            'interpretation':'Finite exact enumeration, not a universal bound or a held-out NLU test. Fault categories depend on externally named concepts.'}
    (out/'identifiability_audit.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
