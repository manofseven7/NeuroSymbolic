"""Frozen exploratory FOL audit. Gold semantic input, not raw-text accuracy."""
import csv,hashlib,itertools,json,platform,time
from collections import Counter
from pathlib import Path
import z3
from fol_certifier import parse,solve,FOLParseError,ambiguity_paths,replace_ops,certify
ROOT=Path(__file__).resolve().parents[1]
def dump(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2))
def evaluate(k,q,timeout,evidence=False):
 try:return solve(parse(k) if isinstance(k,str) else k,parse(q) if isinstance(q,str) else q,timeout,evidence)
 except (FOLParseError,z3.Z3Exception,RecursionError) as e:return {'label':'ParseError','error':str(e)}
def main():
 cfg=json.loads((ROOT/'configs/folio_certified_v1.json').read_text());out=ROOT/'results/folio_certified_v1';out.mkdir(exist_ok=True)
 data=[json.loads(x) for x in (ROOT/'third_party/FOLIO_curated/dataset_rawpairs.jsonl').read_text().splitlines()]
 stories={x['id'].split('_')[1]:x for x in data if x['id'].startswith('story_')};rows=[x for x in data if x['id'].startswith('concl_')];records=[];start=time.monotonic()
 for i,row in enumerate(rows):
  story=stories[row['id'].split('_')[1]];k=story['FOL_sentence_new'];q=row['FOL_sentence_new']
  rec={'id':row['id'],'story_id':story['id'],'reference_label':row['label'],'upstream_solver_label':row.get('label_z3'),'ambiguity_annotated':bool(story.get('ambiguity') or row.get('ambiguity'))}
  rec['curated']=evaluate(k,q,cfg['timeout_ms'],True)
  # Old story formulas are separated by newlines; conjunction is an explicit file-format conversion, not content repair.
  oldk=' ∧ '.join('('+x.strip()+')' for x in story['FOL_sentence_old'].splitlines() if x.strip())
  rec['original']=evaluate(oldk,row['FOL_sentence_old'],cfg['timeout_ms'])
  try:
   ka,qa=parse(k),parse(q);sites=[('k',p) for p in ambiguity_paths(ka)]+[('q',p) for p in ambiguity_paths(qa)];sites=sites[:cfg['max_ambiguity_sites']]
   rec['sites']=[{'part':a,'path':p} for a,p in sites];variants=[]
   for bits in itertools.product((0,1),repeat=len(sites)):
    ch={'k':{},'q':{}}
    for (part,path),b in zip(sites,bits):
     a=ka if part=='k' else qa
     for j in path:a=a[j]
     ch[part][path]=('∨' if a[0]=='⊕' else '⊕') if b else a[0]
    rr=evaluate(replace_ops(ka,ch['k']),replace_ops(qa,ch['q']),cfg['timeout_ms']) if any(bits) else {x:y for x,y in rec['curated'].items() if x!='checks'}
    variants.append({'bits':bits,**rr})
   rec['variants']=variants;rec['robust']=certify(variants)
  except (FOLParseError,z3.Z3Exception) as e:rec.update(variants=[],robust={'certified':False,'label':'Abstain'},family_error=str(e))
  records.append(rec)
  if (i+1)%10==0:print(f'{i+1}/{len(rows)} elapsed={time.monotonic()-start:.1f}s curated={dict(Counter(r["curated"]["label"] for r in records))}',flush=True)
  if (i+1)%10==0:dump(out/'records_checkpoint.json',records)
 dump(out/'records.json',records)
 good={'True','False','Uncertain'};cert=[r for r in records if r['robust']['certified']];base=[r for r in records if r['curated']['label'] in good];old=[r for r in records if r['original']['label'] in good]
 summary={'experiment':cfg['experiment_id'],'questions':len(rows),'stories':len(stories),'curated_statuses':dict(Counter(r['curated']['label'] for r in records)),'original_statuses':dict(Counter(r['original']['label'] for r in records)),'curated_label_matches':sum(r['curated']['label']==r['reference_label'] for r in records),'original_label_matches':sum(r['original']['label']==r['reference_label'] for r in records),'curated_answered':len(base),'original_answered':len(old),'certified':len(cert),'certified_label_matches':sum(r['robust']['label']==r['reference_label'] for r in cert),'questions_with_operator_variants':sum(len(r['variants'])>1 for r in records),'variants_total':sum(len(r['variants']) for r in records),'certified_reference_disagreements':[r['id'] for r in cert if r['robust']['label']!=r['reference_label']],'curated_reference_disagreements':[r['id'] for r in base if r['curated']['label']!=r['reference_label']],'runtime_seconds':time.monotonic()-start,'z3_version':z3.get_version_string(),'python':platform.python_version(),'code_sha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ['src/fol_certifier.py','src/evaluate_fol_certifier.py','configs/folio_certified_v1.json']},'claim_scope':'provided FOL reasoning and OR/XOR sensitivity; no neural semantic parser, no held-out end-to-end NLU claim'}
 dump(out/'summary.json',summary);print(json.dumps(summary,indent=2),flush=True)
 with (out/'questions.csv').open('w') as f:
  w=csv.writer(f);w.writerow(['id','reference','curated','original','certified','robust_label','variants'])
  for r in records:w.writerow([r['id'],r['reference_label'],r['curated']['label'],r['original']['label'],r['robust']['certified'],r['robust']['label'],len(r['variants'])])
if __name__=='__main__':main()
