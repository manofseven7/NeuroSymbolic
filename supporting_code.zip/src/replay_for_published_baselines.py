import json,time,csv
from pathlib import Path
import joblib
from local_kinship_repair import ROOT,read,write_rows,digest
from run_consistent_kinship import eval_rows

def main():
 out=ROOT/'results/published_baselines_v1';inputs=json.loads((out/'payload/test_inputs.json').read_text());source={r['id']:r for r in read('confirmation_gen234_test.csv')};rows=[source[r['id']] for r in inputs];frozen=json.loads((ROOT/'results/consistent_kinship_v1/FROZEN_SELECTION.json').read_text());results=[];start=time.monotonic()
 stored={(r['id'],r['seed']):r['prediction'] for r in csv.DictReader((ROOT/'results/consistent_kinship_v1/seen_second_predictions.csv').open())}
 for seed in [42,43,44]:
  fr=frozen[str(seed)];path=ROOT/f'results/consistent_kinship_v1/model_{seed}.joblib';assert digest(path)==fr['model_sha256'];model=joblib.load(path);rr=eval_rows(model,rows,fr['rules'],fr['reciprocal'],seed,'Ours_NS023');assert all(stored[r['id'],str(seed)]==r['prediction'] for r in rr);results+=rr;print('replayed',seed,len(rr),time.monotonic()-start,flush=True)
 write_rows(out/'ours_replayed.csv',results);(out/'ours_replay_audit.json').write_text(json.dumps({'all3078predictions_match':True,'n_questions':len(rows),'seeds':[42,43,44],'runtime_seconds':time.monotonic()-start},indent=2))
if __name__=='__main__':main()
