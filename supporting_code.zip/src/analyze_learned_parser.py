import collections,csv,json
from pathlib import Path
import numpy as np

def mean(v):return sum(v)/len(v)

def main():
    root=Path('results/learned_parser_v1');p=root/'evaluation';sel=json.loads((root/'selection.json').read_text());base=json.loads((p/'baselines.json').read_text());rows=list(csv.DictReader((p/'episodes.csv').open()));struct=json.loads((p/'program_alignment.json').read_text());sent=json.loads((p/'sentence_audit.json').read_text());folio=json.loads((p/'folio_portability.json').read_text());matched=json.loads((p/'matched_linear_decoder.json').read_text())['records'];ex=json.loads((p/'execution.json').read_text())
    summary=[]
    for policy,budget in sorted(set((r['policy'],int(r['budget'])) for r in rows),key=lambda x:(x[1],x[0])):
        rr=[r for r in rows if r['policy']==policy and int(r['budget'])==budget];ss=[r for r in struct if r['policy']==policy and r['budget']==budget]
        summary.append(dict(policy=policy,budget=budget,answer_accuracy=mean([int(r['correct']) for r in rr]),abstentions=sum(int(r['abstain']) for r in rr),complete_program_reference_agreement=mean([r['complete_program_reference_exact'] for r in ss]),novel_annotations=sum(int(r['novel_annotations']) for r in rr)))
    comparisons=[];rng=np.random.default_rng(20261029);bykey={(r['id'],r['policy'],r['budget']):r for r in struct}
    for policy,comp in [('risk','none'),('uncertainty','none'),('risk','uncertainty')]:
        grouped=collections.defaultdict(lambda:[0,0])
        for a in [r for r in struct if r['policy']==policy and r['budget']==2]:
            b=bykey[(a['id'],comp,0 if comp=='none' else 2)];grouped[a['group']][0]+=int(a['complete_program_reference_exact'])-int(b['complete_program_reference_exact']);grouped[a['group']][1]+=1
        v=np.array(list(grouped.values()));ix=rng.integers(0,len(v),size=(1000,len(v)));delta=v[ix,0].sum(axis=1)/v[ix,1].sum(axis=1);ci=np.quantile(delta,[.025,.975]);comparisons.append(dict(policy=policy,comparator=comp,metric='complete-program reference agreement',gain=float(v[:,0].sum()/v[:,1].sum()),cluster_95_ci=list(map(float,ci)),status='Exploratory descriptive audit;no multiplicity-adjusted generic-superiority claim'))
    sentencesummary={}
    for name,subset in [('all',sent),('seen_training',[r for r in sent if r['seen_training']]),('unseen_training',[r for r in sent if not r['seen_training']])]:
        sentencesummary[name]=dict(sentences=len(subset),**{k:mean([r[k] for r in subset]) for k in ['raw_exact','linear_exact','raw_valid','candidate_contains_reference']})
    clean=dict(neural_raw=mean([r['neural_raw']==r['gold'] for r in base]),neural_raw_abstentions=sum(r['neural_raw']==4 for r in base),linear_raw=mean([r['logistic_raw']==r['gold'] for r in base]),linear_constrained=mean([r['prediction']==r['gold'] for r in matched]))
    results=dict(clean=clean,sentence_agreement=sentencesummary,policies=summary,program_comparisons=comparisons)
    (p/'summary.json').write_text(json.dumps(results,indent=2))
    lines=['# مبدل معنایی یادگرفته‌شده — NS-LEARNED-006','',
    'هدف اصلی مقاله حفظ شد. این مرحله یک مبدل عصبی واقعی برای انگلیسی کنترل‌شده به خط اجرای قواعد و شاهد اضافه می‌کند. شرط حداقل ۲ واحد درصد، مطابق تصمیم کاربر، شرط ادامه نیست. نتایج قدیمی و شکست معیارهای آن‌ها تغییر نکرده‌اند.','',
    '## چه چیزی یاد گرفته شد؟','',
    'شبکه MLP نقش واژه‌ها را پیش‌بینی می‌کند: موضوع، گزاره، مفعول، متغیر و نفی در حقیقت، شرط‌های قاعده و نتیجه آن. رمزگشا فقط از این نقش‌های پیش‌بینی‌شده، کپی واژه‌ها و قیدهای نوعی برای ساخت برنامه استفاده می‌کند. حل ارجاع ساده و حذف تکرار موضوع، بخشی از رمزگشای مقید است. در استنتاج عادی، مبدل قبلی برای پارس فراخوانی نمی‌شود؛ یک آزمون مستقل این جدایی را کنترل می‌کند.','',
    'برچسب‌های آموزش از مبدل ثابت قبلی روی داده توسعه گرفته شده‌اند؛ بنابراین این **یادگیری با نظارت یک معلم قاعده‌محور** است، نه یادگیری بدون نظارت و نه برچسب معنایی انسانی مستقل. ویژگی‌های واژگانی، پنجره متنی و جایگاه نشانه‌ها مهندسی شده‌اند. مدل، LLM ازپیش‌آموزش‌دیده یا مبدل عمومی منطق مرتبه اول نیست.','',
    f'آموزش: {sel["train_sentences"]} جمله یکتا؛ اعتبارسنجی: {sel["validation_sentences"]} جمله یکتا با جداسازی مبتنی بر هش جمله. دو شبکه ۶۴ و ۱۲۸ واحدی و یک برچسب‌زن خطی آموزش دیدند. شبکه {sel["selected"]} فقط با دقت ساختار کامل اعتبارسنجی انتخاب شد؛ تنظیمات پس از آزمون تغییر نکردند. آزمون همان ۶۰۰ رکورد عمومی ProofWriter مراحل قبلی است و یک مجموعه تأیید بیرونی تازه نیست. هم‌پوشانی جمله‌های کوتاه با آموزش جداگانه گزارش شده است.','',
    '| مدل | توافق دقیق ساختار در اعتبارسنجی |','|---|---:|']
    for r in sel['results']:lines.append(f'| {r["name"]} | {100*r["validation_exact"]:.2f}٪ |')
    lines+=['','## پاسخ‌گویی روی ۶۰۰ پرسش آزمون','',
    '| مسیر | دقت پاسخ |','|---|---:|',f'| شبکه عصبی خام و اجرای قواعد | {100*clean["neural_raw"]:.2f}٪ |',f'| برچسب‌زن خطی خام و اجرای قواعد | {100*clean["linear_raw"]:.2f}٪ |',f'| شبکه عصبی + رمزگشایی مقید، بدون شاهد اضافی | {100*next(r["answer_accuracy"] for r in summary if r["budget"]==0):.2f}٪ |',f'| برچسب‌زن خطی + همان رمزگشای مقید | {100*clean["linear_constrained"]:.2f}٪ |','',
    f'کاهش دقت مسیر عصبی خام ناشی از {clean["neural_raw_abstentions"]} خودداری به علت ساختار نامعتبر بود؛ این موارد در دقت، خطا حساب شدند. خودداری از پاسخ با unknown منطقی یکی نشده است. کنترل خطی با رمزگشای مشابه، بعد از نتیجه اولیه به عنوان ممیزی منصفانه اضافه شد؛ وزن‌ها، پارامترها و مدل منتخب تغییر نکردند. نتیجه نشان‌دهنده سود رمزگشایی مقید است؛ مزیت شبکه غیرخطی نسبت به کنترل خطی اثبات نشده است.','',
    'دقت ۱۰۰٪ روی انگلیسی کنترل‌شده به معنی حل متن آزاد نیست. مبدل مهندسی‌شده قبلی هم در همین مجموعه ۱۰۰٪ داشت. فایده این مرحله، جایگزینی پیش‌بینی نقش‌های دست‌نویس با مدل آموزش‌دیده و بررسی خطاهای واقعی آن است، نه عبور از سقف عملکرد این مجموعه.','',
    '## آیا کل دانشِ استنباط‌شده هم درست است؟','',
    'با وجود پاسخ درست به همه پرسش‌ها، برنامه کامل در همه نمونه‌ها با تفسیر مرجع یکسان نبود. در این جدول، درست‌بودن تمام حقایق، قواعد و تفسیر پرسش با معلم قاعده‌محور سنجیده می‌شود؛ این برچسب انسانی مستقل نیست.','',
    '| سیاست | تعداد برچسب معنایی جمله | دقت پاسخ | توافق ساختار کامل برنامه |','|---|---:|---:|---:|']
    for r in summary:lines.append(f'| {r["policy"]} | {r["budget"]} | {100*r["answer_accuracy"]:.2f}٪ | {100*r["complete_program_reference_agreement"]:.2f}٪ |')
    lines+=['','## اصلاح خطاهای واقعیِ شبکه','',
    'اینجا خطای مصنوعی تزریق نشده است. چند تفسیر از احتمال نقش‌های شبکه ساخته می‌شود؛ هر جمله حداکثر سه تفسیر و هر نظریه حداکثر ۱۶ برنامه نامزد دارد. وزن‌ها از نمره مسیرهای شبکه نرمال می‌شوند و احتمال معنایی کالیبره‌شده فرض نمی‌شوند. همه سیاست‌ها همان نامزدها، وزن‌ها، رمزگشا و بودجه را دارند.','',
    'هر پرس‌وجو، تفسیر معنایی یک جمله را از مرجع ثابت می‌گیرد؛ پاسخ نهایی پرسش هدف هرگز پرسیده نمی‌شود. فقط تفسیر جمله پرسیده‌شده جایگزین می‌شود و اگر پیش‌تر در نامزدها نبوده، همان تفسیر به بانک وارد می‌شود. این فرآیند، نظارت اضافی معنایی و اصلاح موضعی است؛ خوداصلاحی بدون مرجع، القای عمومی قواعد یا دروازه پذیرش مبتنی بر اعتبارسنجی مستقل نیست. پاسخ درست در این مجموعه از ابتدا به سقف رسیده بود؛ پس شاهد اضافی نمی‌توانست دقت پاسخ را بیشتر کند.','',
    'کنترل ساده عدم‌قطعیت برای بازیابی کل برنامه بهتر از انتخاب بر پایه ریسک پاسخ عمل کرد. این نتیجه پنهان نمی‌شود: معیارِ هدف‌گرفته‌شده توسط سیاست ریسک، پاسخ همان پرسش بود؛ خطای قواعدی که در آن پاسخ نقشی ندارند می‌تواند باقی بماند. کنترل برتر یک انتخاب مهندسی پیشنهادی برای مرحله بعد است؛ انتخاب آن پس از مشاهده این داده، تأیید مستقل جدید محسوب نمی‌شود.','']
    for c in comparisons:
        lo,hi=c['cluster_95_ci'];lines.append(f'- {c["policy"]} در برابر {c["comparator"]}، توافق کل برنامه در بودجه ۲: {100*c["gain"]:+.2f} واحد درصد؛ بازه اکتشافی [{100*lo:+.2f}، {100*hi:+.2f}].')
    lines+=['','بازه‌ها با ۱٬۰۰۰ بازنمونه‌گیری در سطح ۴۵۷ زمینه یکتا محاسبه شده‌اند؛ بهبود ساختار کامل، ممیزی توصیفی پس از خروجی پاسخ است و آزمون تأییدی چندمقایسه‌ای یا اثبات نوآوری نیست.','',
    '## کنترل شاهد و معنا','',
    f'در {ex["episodes"]} اپیزود، {ex["positive_negative_proof_checks"]} شاهد مثبت/منفی بازاجرا شد؛ {ex["invalid_program_relative_proofs"]} شاهد نامعتبر نسبت به برنامه انتخاب‌شده ثبت شد. این تعداد شامل تکرار روی ۴۰۰ پرسش دارای پاسخ مثبت/منفی است، نه ۳٬۶۰۰ نمونه مستقل. تمام این شاهدها از لحاظ جمله‌های استفاده‌شده با معلم مرجع هم‌خوان بودند. این با درست‌بودن قواعد استفاده‌نشده، صحت انسانی معنا یا وفاداری عمومی زبان طبیعی یکسان نیست. توضیح‌ها فقط از گام‌های اجرای همان برنامه، به صورت قالبی و با شناسه جمله، ساخته می‌شوند.','',
    '## آزمون انتقال به FOLIO قدیمی','',
    f'از ۲۰۴ نمونه، تنها {folio["structurally_decoded"]} نمونه از نظر ساختاری رمزگشایی شد و {folio["confidence_accepted"]} نمونه از آستانه ثابت اطمینان عبور کرد. تفسیر طلایی FOL استفاده نشد و روی این داده آموزش یا تنظیم انجام نشد. این نتیجه نشان می‌دهد افزودن یک شبکه کوچک، به‌تنهایی دامنه دستور زبان را به منطق مرتبه اول و متن آزاد گسترش نمی‌دهد. پذیرش ساختاری نیز تضمین درستی معنا نیست.','',
    '## بازتولید و تصمیم','',
    'وزن‌های آموزش‌دیده، تقسیم آموزش/اعتبارسنجی، انتخاب مدل تثبیت‌شده، کد، تمام ردهای پرس‌وجو و نمونه توضیح‌ها همراه بسته‌اند. ۳۵ آزمون پیاده‌سازی پاس شد و چهار اپیزود اصلاح، دقیقاً در همان محیط بازتولید شد. آموزش و اجرا روی CPU انجام شد؛ GPU و ورود به حساب خارجی لازم نشد.','',
    'اجرای نخست آموزش به علت ناسازگاری برچسب‌های رشته‌ای با early stopping کتابخانه متوقف شد؛ کدگذاری عددیِ همان برچسب‌ها پیش از ارزیابی عصبی اصلاح شد و گزارش شکست نگه داشته شد. در ممیزی FOLIO، قطعه‌های صرفاً عددی/نشانه‌ای به خودداری تبدیل شدند؛ وزن‌ها و نتایج آزمون اصلی تغییر نکرد.','',
    '**تصمیم: ادامه پژوهش با یک نمونه عصبی–نمادین عملیاتی.** برای هدف اصلی مقاله، هنوز داده دشوارتر، پشتیبانی معنایی گسترده‌تر و یک تمایز پژوهشی روشن لازم است. رمزگشایی مقید، برچسب‌زنی عصبی و انتخاب بر اساس عدم‌قطعیت به‌خودی‌خود نوآوری جدید ادعا نمی‌شوند.','']
    Path('reports/LEARNED_PARSER_FA.md').write_text('\n'.join(lines));print(json.dumps(results,indent=2))
    report=Path('reports/LEARNED_PARSER_FA.md')
    report.write_text(report.read_text()+f'\n## توافق ساختار جمله و محدودیت نمونه‌گیری\n\nاز {len(sent)} جمله یکتای آزمون، ۹۶۲ جمله دقیقاً در آموزش دیده شده بود؛ ۳٬۵۳۳ جمله تازه بود. توافق دقیق ساختار در کل {100*sentencesummary["all"]["raw_exact"]:.2f}٪ و در جمله‌های تازه {100*sentencesummary["unseen_training"]["raw_exact"]:.2f}٪ بود. این توافق با برچسب‌های معلم محاسبه شده است. برنامه مرجع کامل در بانک اولیه ۵۸۹ مورد از ۶۰۰ مورد حضور داشت؛ نبود آن در ۱۱ مورد پنهان نشده است. آموزش فقط با یک بذر انجام شد؛ بازنمونه‌گیری زمینه‌ها، عدم‌قطعیت ناشی از تکرار آموزش یا انتقال به حوزه واقعی را اندازه نمی‌گیرد.\n')

if __name__=='__main__':main()
