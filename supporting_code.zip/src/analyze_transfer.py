"""Question-weighted, theory-clustered analyses of the transfer pilot."""
import collections,csv,json
from pathlib import Path
import numpy as np

def load(p):return list(csv.DictReader(Path(p).open()))

def aggregate(rows):
    # Average random seeds inside each theory before any cluster resampling.
    grouped=collections.defaultdict(lambda:collections.defaultdict(list))
    full=collections.defaultdict(dict)
    for r in rows:
        key=(r['model'],r['policy'],int(r['budget']));seed=int(r['seed']);grouped[key][(r['theory_id'],seed)].append(int(r['correct']));full[key][(r['theory_id'],seed)]=int(r['full_rule_reference_exact'])
    result={}
    for key,values in grouped.items():
        bytheory=collections.defaultdict(list)
        for (theory,seed),correct in values.items():bytheory[theory].append((sum(correct),len(correct),full[key][(theory,seed)]))
        result[key]={theory:np.mean(v,axis=0) for theory,v in bytheory.items()}
    return result

def summaries(groups):
    result=[]
    for key,theories in groups.items():
        a=np.array(list(theories.values()));result.append(dict(model=key[0],policy=key[1],budget=key[2],accuracy=float(a[:,0].sum()/a[:,1].sum()),theory_rule_exact=float(a[:,2].mean()),theories=len(a),questions=int(a[:,1].sum())))
    return result

def compare(groups,a,b,seed=20261030):
    ids=sorted(set(groups[a])&set(groups[b]));x=np.array([groups[a][i] for i in ids]);y=np.array([groups[b][i] for i in ids]);rng=np.random.default_rng(seed);ix=rng.integers(0,len(ids),size=(1000,len(ids)))
    delta=(x[ix,0].sum(axis=1)/x[ix,1].sum(axis=1))-(y[ix,0].sum(axis=1)/y[ix,1].sum(axis=1));ci=np.quantile(delta,[.025,.975])
    return dict(method=list(a),comparator=list(b),gain=float(x[:,0].sum()/x[:,1].sum()-y[:,0].sum()/y[:,1].sum()),cluster_95_ci=list(map(float,ci)),theories=len(ids),questions=int(x[:,1].sum()),status='Exploratory paired theory bootstrap;random seeds averaged within theory;no external replication or multiplicity claim')

def main():
    p=Path('results/transfer_v1');primary=load(p/'episodes.csv');audit=load(p/'audit/episodes.csv');test=primary+[r for r in audit if r['cohort']=='test_source_ablation' and not(r['policy']=='none' and r['budget']=='0')];hold=[r for r in audit if r['cohort']=='heldout_dev'];g=aggregate(test);h=aggregate(hold)
    pairs=[(('adapted','uncertainty',2),('adapted','random',2)),(('adapted','uncertainty',2),('adapted','none',0)),(('adapted','uncertainty',2),('source','uncertainty',2)),(('source','uncertainty',2),('source','random',2)),(('adapted','none',0),('source','none',0))]
    comps=[compare(g,a,b) for a,b in pairs];holdcomps=[compare(h,a,b) for a,b in pairs];result=dict(test=summaries(g),test_comparisons=comps,heldout_development=summaries(h),heldout_comparisons=holdcomps)
    # Fixed, performance-independent fully aligned secondary subset.
    data=json.loads((p/'prepared.json').read_text());ids={r['id'] for r in data['test'] if all(r['annotation_available'])};aligned=aggregate([r for r in test if r['theory_id'] in ids]);result['fully_aligned_secondary']=summaries(aligned)
    (p/'summary.json').write_text(json.dumps(result,indent=2))
    print(json.dumps({'test_comparisons':comps,'heldout_comparisons':holdcomps},indent=2))

if __name__=='__main__':main()
