"""Update checkpoint metadata after both confirmations; preserve prior history."""
import csv,hashlib,json,shutil,zipfile
from pathlib import Path

def main():
    root=Path(__file__).resolve().parents[2];p=root/'project'
    a=json.loads((p/'results/search3r_confirmation/decision.json').read_text());b=json.loads((p/'results/program_action_confirmation/decision.json').read_text())
    for name in ['Scientific_Memory.md','Research_State.md','Module_Execution.csv','Experiment_Registry.csv']:
        target=p/'history'/('pre_search3r_'+name)
        if not target.exists():shutil.copyfile(p/name,target)
    memory=f'''# Scientific Memory — authoritative current checkpoint

Date: 2026-10-28. Original title retained: **Dynamic Neural-Symbolic Reasoning Framework for Cross-Domain Knowledge Integration and Explainable Natural Language Understanding**.

## Objective and decision
User retains broad language-understanding/cross-domain objective, with joint grounding-versus-rule change diagnosis as core. Current state FORMULATED / REVISE. Novelty and full-method gates have NOT passed. No Q1 acceptance probability is estimated. Read reports/CONTINUED_TESTING_FA.md first; prior complete memory is preserved in history/pre_search3r_Scientific_Memory.md.

## Implemented scope
Finite explicit-negative Horn symbolic reasoners, evidence selection, exhaustive bounded repair banks, pointwise and program-constrained Bayesian decisions. No neural encoder, trainable differentiable rule module, text-induced rule verifier, natural-language explanation generator or human evaluation is implemented. No external login/signup or GPU use occurred.

## Prior evidence retained
NS-T0-001: 192 hypotheses collapse into 48 task behavior classes, 11,520 dependent diagnostic episodes, 3,072 rule-deletion checks. Same-environment reproduction passed. Joint grounding/rule distinctions can be observationally ambiguous. Full proof support sets, not mandatory single-rule necessity, handle alternative proofs.
NS-DEEP-002: 32 synthetic worlds, 5,568 episodes. Guarded fixed-confidence VOI failed its predeclared superiority gate. Naive source-proof pruning had 2,068/90,112 disagreements; sound all-candidate cone pruned no rules. Those variants remain STOP. All raw results and post-result diagnostics are retained.

## Recovery event
The unpersisted earlier round-3 process/source was lost during runtime reset; no final metrics were available or used. Version-2 saved project was restored. NS-SEARCH-003R is a newly specified recovered experiment, not a claimed byte-identical replay of the lost run. Its code/config were fixed before execution; no external preregistration.

## Current experiments
NS-SEARCH-003R development: 16 fresh worlds (2000–2015), four candidates plus three controls, 1,568 episodes. Selection is lowest mean weighted error on new unary/pair cases pooled noise. Predictive-risk candidate selected and frozen before confirmation.
NS-SEARCH-003R confirmation: 64 fresh worlds (4000–4063), 3,584 episodes. Primary gate PASS={a['primary_pass']}. Risk accuracy gain versus wide entropy {a['comparisons'][0]['gain']:+.8f}; versus wide EC2 {a['comparisons'][1]['gain']:+.8f}. First gain significant for this generator; second CI includes zero. Do not claim universal superiority.
NS-PROGRAM-004 pilot: 16 new worlds (6000–6015), 896 episodes. Restricts terminal action to one executable retained program and evaluates query values using that same constrained risk. Two-by-two action-space/query-criterion ablation; relative-to-program proof replay audited.
NS-PROGRAM-004 confirmation: 64 new worlds (8000–8063), 3,584 episodes. Primary gate PASS={b['primary_pass']}. Risk gain versus matched program entropy {b['comparisons'][0]['gain']:+.8f}; versus matched program EC2 {b['comparisons'][1]['gain']:+.8f}. See exact intervals and retention checks in results/program_action_confirmation/decision.json.
Current round total: 9,632 dependent episodes, 160 distinct generated worlds, one template family; not 160 domains or model-training seeds.

## Statistical and leakage controls
Held-out raw contexts never task-label queried. Same evidence budget 8, task cost 1, semantic query cost 2. Known uniform input distribution may be used for hypothetical risks, not hidden labels. Selection and confirmations have disjoint seeds. Primary success requires >=2 percentage points versus both matched wide controls, positive Bonferroni paired-world bootstrap intervals, and <=1 point clean-original accuracy loss. Bootstrap 5,000 resamples of worlds, not episodes. No retuning after confirmation.
Clean EC2 implemented exactly; noisy policy is a posterior-edge surrogate, not full noise-expanded EC2. Shared expanded grammar includes all 120 permutations and positive unary/pair added clauses, not arbitrary real-world rule induction. Signed exception stress is outside that family.

## Explanation evidence and limits
Pointwise decisions lacked any single bank-program witness in 12/112 structurally audited episodes. Program constraint repairs this computational mismatch. Positive/negative sufficient-support replay and exact output replay are audited. Unknown is checked by finite closure, not called a positive proof. These are model-relative validity checks, not demonstrated semantic truth, robust proof identifiability, natural-language faithfulness or causal truth of each cited rule.

## Novelty audit
Expected-error reduction/VOI, monotone active learning, new-concept knowledge refinement and joint concept/inference shortcuts are established. Targeted primary review includes Roy/McCallum ICML2001; Kovalerchuk et al. Information Sciences1996; Huang et al. AAAI2023; Bortolotti et al. NeurIPS2025; Tang et al. AISTATS2026. No full end-to-end published model baseline was reproduced. A finite executable action constraint alone does not establish a new algorithm. See reports/SEARCH3R_METHOD.md and reports/PROGRAM_ACTION_METHOD.md.

## Data and provenance
Public pinned FOLIO legacy v0.0 schema/profile and license retained, not used for model training. Missing train conclusion-FOL and validation grouping issues remain documented. Corrected gated FOLIO was not accessed. No unapproved data-sharing terms accepted.
21 implementation tests pass, covering independent scalar Bayes/branch calculations, permutation semantics, monotone certificate conditions and reconstructed program execution/supports. All confirmation traces checked for budgets, no repeats, held-out separation and outcome alphabets. Four episodes per confirmation exactly replayed in the same environment. This is not independent external replication. CPU timings, code/config hashes, traces, world seeds/specs and complete case summaries are retained.

## Claim–evidence boundary and next requirement
Finite ambiguity and model-relative program replay are supported. Conditional risk-selection gains are measured. Generic superiority, a novel method, semantic proof faithfulness, actual cross-domain NLU, human ratings, scalability and publication readiness are PENDING. Original abstract N/M/X/Y/Z/W placeholders must not be filled with synthetic task numbers.
Next scientific requirement: establish a distinct mechanism for semantically grounded, proof-consistent repair under incomplete hypothesis families, or reframe honestly as a diagnostic/benchmark contribution. Do not tune on confirmation worlds, scale rejected gates, or claim known VOI as original. Neural/GPU scaling needs a justified method/data protocol.
'''
    (p/'Scientific_Memory.md').write_text(memory)
    (p/'Research_State.md').write_text(f'''# Research State

2026-10-28 | FORMULATED | REVISE; original broad topic and diagnostic core retained.
First recovered confirmation primary gate: {a['primary_pass']}.
Program-constrained follow-on confirmation primary gate: {b['primary_pass']}.
Computational rule-program witness gap addressed and audited; semantic faithfulness and novelty remain unvalidated.
9,632 new symbolic episodes on 160 generated tasks, not natural domains. 21 tests pass.
Publication gate: NOT READY. No neural, GPU, human or real-domain results.
Read reports/CONTINUED_TESTING_FA.md and Scientific_Memory.md.
''')
    with (p/'Experiment_Registry.csv').open('a') as f:
        w=csv.writer(f)
        w.writerow(['NS-SEARCH-003R','COMPLETE_GATE_'+str(a['primary_pass']),'expanded synthetic Horn bank','configs/search_recovered.json','2000-2015;4000-4063','CPU','2026-10-28','completed','results/search3r_confirmation','1568 development +3584 confirmation; frozen one-candidate selection'])
        w.writerow(['NS-PROGRAM-004','COMPLETE_GATE_'+str(b['primary_pass']),'same generator fresh seeds','configs/program_action_confirmation.json','6000-6015;8000-8063','CPU','2026-10-28','completed','results/program_action_confirmation','896 pilot +3584 confirmation; executable terminal actions and proof replay'])
    rows=list(csv.DictReader((p/'Module_Execution.csv').open()))
    updates={'02':('UPDATED','Scientific_Memory.md'),'04':('REVISE','Known VOI/monotone/joint-shortcut overlap; no validated novel algorithm'),'06':('ENGINEERING_VARIANT','Executable-program constrained VOI; no novelty claim'),'07':('IMPLEMENTATION_CHECKED','21 tests; no new theorem'),'08':('RECOVERED_PROTOCOLS','configs/search_recovered.json;program_action_confirmation.json'),'09':('TWO_CONFIRMATIONS','See per-experiment decision.json; no generic superiority claim'),'13':('CURRENT_EXECUTED','9632 new symbolic episodes; 160 generated tasks'),'14':('UPDATED','Experiment_Registry.csv'),'15':('PAIRED_WORLD_BOOTSTRAP','5000 world resamples; two-comparison adjustment'),'16':('ACTION_SPACE_ABLATION','pointwise vs executable program; risk vs entropy'),'17':('NOISE_AND_MISSPECIFICATION','All noise/case summaries retained'),'18':('REVISE_FULL_FRAMEWORK','Model-relative execution validity; semantic faithfulness unvalidated'),'19':('UPDATED','reports/CONTINUED_TESTING_FA.md'),'20':('CURRENT_PROVENANCE','Code hashes; configs; traces; frozen selection'),'21':('CURRENT_TABLES','All cases and failures retained'),'31':('TARGETED_PRIMARY_REVIEW','Expected error reduction; joint shortcuts; misspecification'),'32':('PASS_IMPLEMENTATION_REPLAY','21 tests;4 exact episode replays per confirmation'),'34':('REVISE','No Q1-readiness or algorithmic novelty claim'),'37':('UPDATED','Scientific_Memory.md'),'38':('CPU_ONLY','Execution durations recorded; no inference overhead comparison'),'39':('UPDATED_CHECKPOINT','All current protocols/code/raw results/reports included')}
    for row in rows:
        if row['module'] in updates:row['status'],row['output_or_reason']=updates[row['module']]
    with (p/'Module_Execution.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    readme=p/'README.md';text=readme.read_text();text=text.replace('Read reports/DEEP_STUDY_FA.md first, then Scientific_Memory.md.','Read reports/CONTINUED_TESTING_FA.md first, then Scientific_Memory.md. Earlier checkpoint: reports/DEEP_STUDY_FA.md.')
    text+='''

## Reproduce the recovered search and program follow-on

Use fresh output directories; runners deliberately refuse existing results.

```bash
OPENBLAS_NUM_THREADS=1 python3 src/search_recovered.py --config configs/search_recovered.json --stage development --out results/new_development
OPENBLAS_NUM_THREADS=1 python3 src/analyze_search_recovered.py --config configs/search_recovered.json --stage development --out results/new_development
OPENBLAS_NUM_THREADS=1 python3 src/search_recovered.py --config configs/search_recovered.json --stage confirmation --selection results/new_development/selection.json --out results/new_confirmation
OPENBLAS_NUM_THREADS=1 python3 src/analyze_search_recovered.py --config configs/search_recovered.json --stage confirmation --selection results/new_development/selection.json --out results/new_confirmation
```

The program pilot/confirmation scripts use their declared result directories. Run `src/probe_program_actions.py` and `src/confirm_program_actions.py` in a fresh copy with those output directories absent; never overwrite original evidence. Analyze the program confirmation with `src/analyze_search_recovered.py --config configs/program_action_confirmation.json --stage confirmation --selection configs/program_action_selection.json --out results/program_action_confirmation`. Run `src/verify_search_traces.py --out ...` on the original named confirmation directories for invariant checks and four exact episode replays each. The program action constraint and classical VOI are specified in reports/PROGRAM_ACTION_METHOD.md. No result here establishes a new neural language system.
'''
    readme.write_text(text)
    (root/'README.md').write_text('# Neuro-symbolic research checkpoint\n\nRead project/reports/CONTINUED_TESTING_FA.md first. The original Research OS v3 files are retained unchanged. Original objective retained; synthetic evidence and limitations are explicit. This is not a Q1 submission package.\n')
    manifest={str(x.relative_to(p)):hashlib.sha256(x.read_bytes()).hexdigest() for x in sorted(p.rglob('*')) if x.is_file() and '__pycache__' not in x.parts and x.name!='SHA256SUMS.json'}
    (p/'SHA256SUMS.json').write_text(json.dumps(manifest,indent=2))
    target=Path('/workspace/scratch/6dfb071ca846/recovered/NeuroSymbolic_Research_OS3_Starter.zip')
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
        for x in sorted(root.rglob('*')):
            if x.is_file() and '__pycache__' not in x.parts:z.write(x,str(x.relative_to(root.parent)))
    with zipfile.ZipFile(target) as z:assert z.testzip() is None
    print(json.dumps(dict(zip=str(target),bytes=target.stat().st_size,first_gate=a['primary_pass'],program_gate=b['primary_pass']),indent=2))

if __name__=='__main__':main()
