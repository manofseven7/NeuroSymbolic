"""CLI: FOL-input interpretation-family certificate, not natural-language NLU."""
import argparse,json
from fol_certifier import parse
from fol_model_reuse import run
from fol_interval_certifier import run as interval_run

def main():
    p=argparse.ArgumentParser();p.add_argument('--theory',required=True);p.add_argument('--question',required=True);p.add_argument('--max-sites',type=int,default=4);p.add_argument('--method',default='interval_gate',choices=['interval_gate','exhaustive','early_stop','selector_only','selector_model_reuse','branch_model_reuse','incremental_early_stop','incremental_model_reuse']);a=p.parse_args()
    if not 0<=a.max_sites<=8:p.error('max-sites must be between 0 and 8')
    got=interval_run(parse(a.theory),parse(a.question),max_sites=a.max_sites) if a.method=='interval_gate' else run(parse(a.theory),parse(a.question),a.method,max_sites=a.max_sites);got.pop('reuse_evidence');got['scope']='Conditional on supplied FOL and enumerated OR/XOR choices; no claim of natural-language semantic completeness.';print(json.dumps(got,indent=2))
if __name__=='__main__':main()
