"""Inference for the fixed ParaRules-positive-theory genre, without gold fields."""
import argparse,json
from pathlib import Path
import joblib
import fulltext_transfer as f
import text_reasoner as t
from closure_certificate import certify_absence

def predict(text,question,model,names,vocab,question_parser='neural'):
    records,info=f.parse_raw(text,names,vocab)
    if not info['complete']:return dict(answer='abstain',reason=info['reason'])
    try:q=model.predict(question.strip().rstrip('.'))[2] if question_parser=='neural' else t.atom(question)
    except (t.ParseError,ValueError):return dict(answer='abstain',reason='Unsupported query syntax')
    positive=q[:3]+(True,);label,pf,known=t.run(records,positive);present=positive in known;answer=bool(present if q[3] else not present)
    out=dict(answer=answer,semantics='Binary closed world,not three-way open-world inference',scope='Positive ParaRules genre,source-known attributes and train-induced names;not arbitrary text.')
    if present:
        explanation=t.verbalize(records,pf,0);explanation.pop('answer',None);explanation['relation']='supports_positive_question' if q[3] else 'refutes_negative_question';out['derivation']=explanation;out['program_relative_proof_valid']=t.verify(records,positive,0,pf)
    else:out['absence_certificate']=dict(absent_positive_literal=positive,finite_closure=list(known),valid=certify_absence(records,positive,known),note='Not an explicit negative-literal derivation.')
    return out

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--theory-file',required=True);ap.add_argument('--question',required=True);ap.add_argument('--question-parser',choices=['neural','symbolic'],default='neural');a=ap.parse_args();sel=json.loads(Path('results/learned_parser_v1/selection.json').read_text());model=joblib.load(Path('results/learned_parser_v1')/(sel['selected']+'.joblib'));names=json.loads(Path('results/fulltext_transfer_v1/name_lexicon.json').read_text());vocab=json.loads(Path('results/transfer_v1/data_audit.json').read_text())['selected']['vocabulary'];print(json.dumps(predict(Path(a.theory_file).read_text(),a.question,model,names,vocab,a.question_parser),indent=2))

if __name__=='__main__':main()
