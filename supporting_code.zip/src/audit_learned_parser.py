"""Frozen-model structural and portability audits; no parameter tuning."""
import hashlib,json,time
from pathlib import Path
import joblib,numpy as np
import learned_parser as l
import text_reasoner as t
import evaluate_learned_parser as e

def main():
    root=Path('results/learned_parser_v1');out=root/'evaluation';sel=json.loads((root/'selection.json').read_text());model=joblib.load(root/(sel['selected']+'.joblib'));linear=joblib.load(root/'logistic0.joblib');cfg=json.loads(Path('configs/learned_parser_v1.json').read_text());data=json.loads(Path('third_party/LogicLM_ProofWriter/test.json').read_text());traces=[json.loads(s) for s in (out/'traces.jsonl').read_text().splitlines()]
    cache={};struct=[];linear_control=[];replayed=0
    for i,r in enumerate(data):
        texts=[s.strip() for s in r['context'].split('.') if s.strip()]+[r['question'].split('?')[-1].strip().rstrip('.')]
        for s in texts:
            if s not in cache:
                w,p=model.distributions(s);cache[s]=(model.candidates(s),float(p.max(axis=1).min()),linear.candidates(s))
        options=[cache[s][0] for s in texts[:-1]]+[[v for v in cache[texts[-1]][0] if v[0][0]=='fact' and '?x' not in v[0][2]]];cc=[cache[s][1] for s in texts];goldasts=[t.sentence(s) for s in texts]
        for trace in (v for v in traces if v['metrics']['id']==r['id']):
            m=trace['metrics'];oo=[list(x) for x in options];seen=[]
            assert len(trace['queries'])<=m['budget']
            for item in trace['queries']:
                q=item['sentence'];assert q not in seen;seen.append(q);ast=t.sentence(texts[q]);assert json.dumps(ast)==json.dumps(item['annotation']);oo[q]=[(ast,0.)]
            path=trace['selected'];complete=path is not None
            exact=complete and all(oo[j][path[j]][0]==goldasts[j] for j in range(len(texts)))
            struct.append(dict(id=r['id'],group=m['group'],policy=m['policy'],budget=m['budget'],correct=m['correct'],complete_program_reference_exact=bool(exact)))
            if i in [0,599] and m['policy']=='risk' and m['budget'] in [1,2]:
                rr=e.adapt(texts,options,cc,'risk',m['budget'],cfg['beam'],lambda q:t.sentence(texts[q]))
                assert rr['prediction']==m['prediction'] and rr['chosen']==tuple(path) and json.dumps(rr['trace'])==json.dumps(trace['queries']);replayed+=1
        # Post-result matched-decoder baseline: fixed logistic weights and same
        # beam, no model choice or tuning based on this additional control.
        lo=[cache[s][2] for s in texts[:-1]]+[[v for v in cache[texts[-1]][2] if v[0][0]=='fact' and '?x' not in v[0][2]]]
        pred=e.adapt(texts,lo,cc,'none',0,cfg['beam'],lambda q:(_ for _ in ()).throw(AssertionError()))['prediction']
        linear_control.append(dict(id=r['id'],prediction=pred,gold='ABC'.index(r['answer'])))
    (out/'program_alignment.json').write_text(json.dumps(struct,indent=2));(out/'matched_linear_decoder.json').write_text(json.dumps(dict(status='post-result matched-decoder ablation,no retuning',records=linear_control),indent=2))
    # Unadapted legacy FOLIO stress. Structural decoding is not an assertion of
    # semantic support for quantifiers/disjunction absent from the AST grammar.
    fr=[json.loads(x) for x in Path('third_party/FOLIO_legacy/data/v0.0/folio-validation.jsonl').read_text().splitlines()];frows=[]
    for i,r in enumerate(fr):
        context=' '.join(r['premises']) if isinstance(r['premises'],list) else r['premises'];ss=[s.strip() for s in context.split('.') if s.strip()]+[r['conclusion'].strip().rstrip('.')];asts=[];conf=[]
        for s in ss:
            if not l.tokens(s):
                # Out-of-grammar numeral/punctuation fragments abstain rather
                # than calling DictVectorizer on an empty token sequence.
                asts.append(None);conf.append(0.);continue
            w,p=model.distributions(s);conf.append(float(p.max(axis=1).min()))
            try:asts.append(l.decode(w,model.labels[p.argmax(axis=1)]))
            except t.ParseError:asts.append(None)
        y=e.raw_answer(ss,asts);accepted=y!=4 and min(conf)>=sel['calibration_threshold'];gold={'True':0,'False':1,'Unknown':2,'Uncertain':2}[r['label']]
        frows.append(dict(index=i,structurally_decoded=y!=4,confidence_accepted=accepted,prediction=y if accepted else 4,gold=gold,correct=bool(accepted and y==gold)))
    result=dict(status='exploratory portability;no adaptation,no gold FOL,not general FOL support',records=len(fr),structurally_decoded=sum(r['structurally_decoded'] for r in frows),confidence_accepted=sum(r['confidence_accepted'] for r in frows),correct_all_records=sum(r['correct'] for r in frows),calibrated_threshold=sel['calibration_threshold'],rows=frows)
    (out/'folio_portability.json').write_text(json.dumps(result,indent=2));(out/'verification.json').write_text(json.dumps(dict(traces_checked=len(traces),budgets_and_unique_semantic_queries='PASS',recorded_annotations_match_reference='PASS',exact_episode_replays=replayed,model_sha256=sel['model_sha256'],code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()),indent=2))
    print({k:v for k,v in result.items() if k!='rows'});print('exact replays',replayed)

if __name__=='__main__':main()
