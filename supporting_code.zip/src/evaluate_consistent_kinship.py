"""Frozen NS023: seen long-depth regression plus untouched gen234 validation.
New confirmation includes lengths2/3/4 only; no fresh5-10 claim.
"""
import csv,json,hashlib,joblib,time
from collections import Counter
import external_kinship as k
from local_kinship_repair import ROOT,read,digest,write_rows,summarize
from run_consistent_kinship import OUT,eval_rows

def main():
 freeze=json.loads((OUT/'FROZEN_SELECTION.json').read_text());protocol=json.loads((OUT/'protocol.json').read_text());protocol['fresh_config']='gen_train234_test2to10/validation.csv; untouched by fitting; after exclusions all2/3/4; no fresh5-10 claim';protocol['long_depth_test_status']='both previous length2to10 tests are now seen regression; no selection on these results';protocol['evaluation_start_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());(OUT/'protocol.json').write_text(json.dumps(protocol,indent=2))
 for seed,fr in freeze.items():assert digest(OUT/f'model_{seed}.joblib')==fr['model_sha256']
 old=read('test.csv');ids=set(json.loads((ROOT/'results/external_kinship_v1/test_split_audit.json').read_text())['test_ids']);old=[r for r in old if r['id'] in ids];second=read('confirmation_gen234_test.csv');ids=set(json.loads((ROOT/'results/local_kinship_repair_v1/confirmation_split_audit.json').read_text()).get('retained_ids',[]))
 # Recreate exactly the NS022 template exclusions; no label-dependent filter.
 prior=[r for name in ['train.csv','validation.csv','test.csv'] for r in read(name)];fp={k.story_fingerprint(r['story']) for r in prior};oldids={r['id'] for r in prior};seen=set();ss=[]
 for r in second:
  f=k.story_fingerprint(r['story'])
  if r['id'] not in oldids and f not in fp and f not in seen:ss.append(r);seen.add(f)
 second=ss;assert len(second)==1026
 allprior=prior+read('confirmation_gen234_test.csv');oldfp={k.story_fingerprint(r['story']) for r in allprior};oldids={r['id'] for r in allprior};seen=set();fresh=[];raw=read('stage023_gen234_validation.csv');exc=Counter()
 for r in raw:
  f=k.story_fingerprint(r['story'])
  if r['id'] in oldids:exc['prior_id']+=1;continue
  if f in oldfp:exc['prior_template']+=1;continue
  if f in seen:exc['within_template']+=1;continue
  seen.add(f);fresh.append(r)
 audit={'raw':len(raw),'retained':len(fresh),'exclusions':dict(exc),'by_hop':dict(Counter(int(r['task_name'].split('.')[-1]) for r in fresh)),'retained_ids':[r['id'] for r in fresh],'sha256':digest(ROOT/'third_party/CLUTRR_external/stage023_gen234_validation.csv'),'note':'fresh published validation becomes evaluation-only test; no fitting/selection; no fresh5to10cases'}
 (OUT/'fresh_split_audit.json').write_text(json.dumps(audit,indent=2));allresults=[]
 for name,rows in [('seen_old',old),('seen_second',second),('fresh_2_4',fresh)]:
  results=[]
  for seed in [42,43,44]:
   fr=freeze[str(seed)];model=joblib.load(OUT/f'model_{seed}.joblib');rr=eval_rows(model,rows,fr['rules'],fr['reciprocal'],seed,'consistent');results+=rr;print(name,seed,'n',len(rr),'correct',sum(x['correct'] for x in rr),flush=True)
   if name=='fresh_2_4':
    from local_kinship_repair import evaluate
    oldfr=json.loads((ROOT/'results/local_kinship_repair_v1/FROZEN_SELECTION.json').read_text())[str(seed)];previous=joblib.load(ROOT/f'results/local_kinship_repair_v1/{oldfr["selected"]}_{seed}.joblib');results+=evaluate(previous,rows,oldfr['rules'],seed,'local_stage022')
  write_rows(OUT/f'{name}_predictions.csv',results);(OUT/f'{name}_summary.json').write_text(json.dumps(summarize(results),indent=2));allresults+=results
 print('COMPLETE',flush=True)
if __name__=='__main__':main()
