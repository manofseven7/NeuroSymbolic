"""Saved-output paired bootstrap and figures for NS023; no fitting."""
import csv,json
from collections import defaultdict
import numpy as np
from local_kinship_repair import ROOT
from run_consistent_kinship import OUT

def load(p,method=None):
 rows=list(csv.DictReader(p.open()))
 return [r for r in rows if method is None or r['method']==method]
def paired(new,old,lo=4,hi=10):
 a={(r['id'],r['seed']):int(r['correct']) for r in new if lo<=int(r['hops'])<=hi};b={(r['id'],r['seed']):int(r['correct']) for r in old if lo<=int(r['hops'])<=hi};assert a.keys()==b.keys()
 per=defaultdict(list)
 for key,value in a.items():per[key[0]].append(value-b[key])
 x=np.array([np.mean(v) for v in per.values()]);rng=np.random.default_rng(23023);bs=np.concatenate([x[rng.integers(0,len(x),(100,len(x)))].mean(axis=1) for _ in range(100)])
 return {'questions':len(x),'delta':float(x.mean()),'ci95':np.quantile(bs,[.025,.975]).tolist(),'bootstrap_samples':10000,'bootstrap_seed':23023,'cluster':'question;3seeds averaged first'}
def main():
 new=load(OUT/'seen_second_predictions.csv');old=load(ROOT/'results/local_kinship_repair_v1/confirmation_predictions.csv','repaired');first=load(OUT/'seen_old_predictions.csv');oldfirst=load(ROOT/'results/local_kinship_repair_v1/predictions.csv');fresh=load(OUT/'fresh_2_4_predictions.csv','consistent');freshold=load(OUT/'fresh_2_4_predictions.csv','local_stage022')
 stats={'seen_second_long':paired(new,old),'seen_old_long':paired(first,oldfirst),'fresh_four_hop':paired(fresh,freshold,4,4),'fresh_all':paired(fresh,freshold,2,4)}
 hop={str(h):{} for h in range(2,11)}
 for h in range(2,11):
  for label,rows in [('stage022',old),('stage023',new)]:
   xs=[int(r['correct']) for r in rows if int(r['hops'])==h];hop[str(h)][label]={'n':len(xs),'accuracy':sum(xs)/len(xs)}
 stats['seen_second_by_hop']=hop
 stats['selected_long_per_seed']={str(s):sum(int(r['correct']) for r in new if r['seed']==str(s) and int(r['hops'])>=4)/sum(r['seed']==str(s) and int(r['hops'])>=4 for r in new) for s in [42,43,44]}
 (OUT/'statistics.json').write_text(json.dumps(stats,indent=2))
 import matplotlib;matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 fig,ax=plt.subplots(1,2,figsize=(10,4.2),gridspec_kw={'width_ratios':[1.6,1]})
 for m,label,mark in [('stage022','Local repair (NS022)','o'),('stage023','Positive + inverse / selected rules (NS023)','^')]:ax[0].plot(range(2,11),[100*hop[str(h)][m]['accuracy'] for h in range(2,11)],marker=mark,label=label)
 ax[0].set(xlabel='Reference hops',ylabel='Accuracy (%)',xticks=list(range(2,11)),ylim=(0,100),title='Seen regression: 1,026 stories')
 ax[0].legend(fontsize=7);ax[0].grid(alpha=.2)
 summ=json.loads((OUT/'fresh_2_4_summary.json').read_text());vals=[100*summ[m]['long']['accuracy'] for m in ['local_stage022','consistent']];ax[1].bar(['NS022','NS023'],vals,color=['#1f77b4','#ff7f0e'],width=.55)
 for i,v in enumerate(vals):ax[1].text(i,v+1,f'{v:.2f}%',ha='center')
 ax[1].set(ylim=(0,100),ylabel='Accuracy (%)',title='Unused split: 1,005 four-hop stories');fig.tight_layout();fig.savefig(OUT/'reasoning_depth.png',dpi=220);fig.savefig(OUT/'reasoning_depth.pdf');plt.close(fig)
 print(json.dumps(stats,indent=2))
if __name__=='__main__':main()
