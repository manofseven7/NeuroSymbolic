"""Consolidate executed formal-core research; no fabricated NLU results."""
import csv,json,shutil
from pathlib import Path
from collections import Counter
ROOT=Path(__file__).resolve().parents[1]
def load(p):return json.loads((ROOT/p).read_text())
def main():
 s=load('results/folio_certified_v1/summary.json');a=load('results/folio_interval_v2/analysis.json');bench=load('results/folio_interval_v2/summary.json');stress=load('results/folio_interval_stress/summary.json');e=load('results/folio_certified_v1/evidence_audit.json')
 def table(d):
  lines=['| روش | زمان متوسط، میلی‌ثانیه | فراخوانی حل‌گر | اختلاف خروجی |','|---|---:|---:|---:|']
  for name,r in d.items():
   if not isinstance(r,dict) or 'runs' not in r:continue
   lines.append(f"| {name} | {r.get('mean_runtime_ms',r.get('mean_ms')):.3f} | {r['mean_solver_checks']:.3f} | {r['certificate_disagreements']} |")
  return '\n'.join(lines)
 fa=f'''# گزارش ادامهٔ پژوهش: هستهٔ استدلال پایدار در برابر تفسیر

تاریخ: ۲۰۲۶-۱۰-۲۸. عنوان اصلی پروژه حفظ شده است:
**Dynamic Neural-Symbolic Reasoning Framework for Cross-Domain Knowledge Integration and Explainable Natural Language Understanding**

این مرحله پس از سقف ParaRules اجرا شد؛ تمام نتایج و کنترل‌های ناموفق قبلی نگهداری شده‌اند. خروجی تازه، یک موتور منطق مرتبهٔ اول و یک الگوریتم گواهی پاسخ با کران پایین/بالای تفسیر است. تصمیم پژوهشی **CONTINUE** است، چون کاهش هزینهٔ محاسباتی قابل اندازه‌گیری داریم. برتری عمومی، نوآوری قطعی و مقالهٔ آمادهٔ ارسال هنوز نتیجهٔ این آزمایش نیستند.

## مسئله و سازوکار

یک اثبات ممکن است نسبت به برداشت اشتباه از متن کاملاً درست باشد. به‌جای انتخاب فوری یک برداشت، مجموعهٔ مشخصی از تفسیرهای مجاز را نگه می‌داریم و بررسی می‌کنیم پاسخ میان آن‌ها ثابت است یا نه. در این پیاده‌سازی، ابهام به انتخاب مستقل OR یا XOR در حداکثر چهار موضع محدود شده است. این گزینه‌ها از فرمول مرجع تولید شده‌اند؛ خروجی یک مدل فهم متن نیستند.

برای هر فرمول، دو کران ساخته می‌شود: کرانی که از تمام تفسیرها قوی‌تر است و کرانی که از تمام آن‌ها ضعیف‌تر است. وجود دو مدل مشترک، یکی موافق و یکی مخالف پرسش، می‌تواند نامعین بودن پاسخ را برای همهٔ تفسیرها ثابت کند. ترکیب مدل شاهد با ردِ کران مقابل، پاسخ درست یا نادرست را گواهی می‌کند. در صورت ناکافی بودن این آزمون، اجرای دقیق افزایشی جایگزین می‌شود. «حل‌گر ناموفق»، «مقدمات متناقض» و «نامعین بودن منطقی» یکی حساب نمی‌شوند.

این یک هستهٔ محاسباتی قابل اتصال به مجموعهٔ پیشنهادهای یک مدل عصبی است. اتصال عمومی آن به متن طبیعی، آموزش پایان‌به‌پایان و استخراج خودکار قواعد در این مرحله انجام نشده است.

## دادهٔ سخت‌تر و ممیزی اولیه

نسخهٔ عمومی بازبینی‌شدهٔ FOLIO از مخزن نویسندگان مقالهٔ Fixing FOLIO and MALLS دریافت و با commit و SHA256 ثبت شد: ۷۳ داستان و ۲۰۲ نتیجه. داده شامل فرمول‌های مرتبهٔ اول، روابط چندآرگومانی، کمیت‌گذار، برابری و نفی است. ورودی موتور، فرمول‌های داده‌شده است؛ بنابراین این آزمایش را دقت فهم متن نمی‌نامیم.

تمام فرمول‌های بازبینی‌شده پس از پشتیبانی عمومی از نام‌های یونیکد خوانده شدند. اجرای فرمول‌ها {s['curated_label_matches']} برچسب از {s['questions']} برچسب مجموعه را بازتولید کرد. هفت نتیجه به مقدمات متناقض تعلق دارند و موتور از پاسخ معمول خودداری می‌کند. شش مورد دیگر با قرارداد صریح جهان باز اختلاف دارند؛ برای هر شش مورد، مدل موافق و مخالف توسط مفسر مستقل پایتون بررسی شده است. این یافته به‌تنهایی ثابت نمی‌کند تمام متن یا برچسب‌های آن موارد اشتباه‌اند؛ فقط اختلاف را تحت قرارداد ثبت‌شده نشان می‌دهد. داده و برچسب‌ها برای کسب امتیاز بالاتر ویرایش نشده‌اند.

در مجموع {e['finite_models']} مدل متناهی به‌صورت مستقل، {e['solver_relative_support_replays']} مجموعهٔ پشتیبان با اجرای مجدد حل‌گر، و {e['inconsistent_core_replays']} هستهٔ تناقض بررسی شد. هیچ مدلِ شاهد نامعتبر نبود. بازاجرای مجموعهٔ پشتیبان، اثبات مستقل از حل‌گر محسوب نمی‌شود.

## کنترل‌هایی که جلوی نتیجه‌گیری اشتباه را گرفتند

۱. انتخاب سؤال بهینه در شبیه‌سازیِ رفع ابهام از تصادفی و عدم‌قطعیت معنایی بهتر بود، اما با label-entropy و EC2 مساوی شد. نوآوری انتخاب سؤال از این نتیجه استنتاج نشد.

۲. نسخهٔ اول بازاستفاده از مدل‌ها فراخوانی کمتری داشت، اما کندتر بود. نسخهٔ بهینه‌شده در مقایسهٔ اولیه سریع‌تر شد، ولی افزودن کنترل افزایشی این برتری را از بین برد. هر دو شکست ثبت شده‌اند.

۳. کران‌گذاریِ اولیه نیز نسبت به کنترل افزایشی کندتر بود. نسخهٔ دوم زیرعبارت‌های بدون ابهام را یک‌بار کامپایل می‌کند و در حالت بدون ابهام مستقیماً به مسیر دقیق می‌رود. فقط همین نسخه در نتایج جاری معرفی می‌شود؛ نسخه‌های قبلی حذف نشده‌اند.

## نتیجهٔ اصلی: ۲۰۲ پرسش، سه تکرار زمانی

{table(bench)}

نسخهٔ کران‌گذاری همان پاسخ/خودداری مرجع را در تمام ۶۰۶ اجرای خود بازتولید کرد. نسبت به کنترل افزایشی، فراخوانی‌ها **{a['primary']['solver_check_reduction_percent']:.2f}٪** کمتر شدند؛ بازهٔ اکتشافی ۹۵٪ با بازنمونه‌گیری ۷۳ داستان: **[{a['primary']['checks_95pct_cluster_interval'][0]:.2f}، {a['primary']['checks_95pct_cluster_interval'][1]:.2f}]٪**. کاهش میانگین زمان **{a['primary']['timing_reduction_percent']:.2f}٪** بود، اما بازهٔ آن **[{a['primary']['timing_95pct_cluster_interval'][0]:.2f}، {a['primary']['timing_95pct_cluster_interval'][1]:.2f}]٪** شامل صفر است؛ بنابراین برتری زمانی قطعی ادعا نمی‌شود. سه تکرار، ۶۰۶ نمونهٔ مستقل نیستند.

در مجموعهٔ تفسیرها، ۱۸۱ پرسش بدون رفع ابهام پاسخ ثابت دارند؛ ۱۷۵ مورد با برچسب مجموعه موافق‌اند. همان شش اختلاف قرارداد/برچسب باقی می‌مانند. گواهی ثبات تفسیر، به‌خودی‌خود صحت معنای متن را تضمین نمی‌کند.

## آزمون بزرگ‌تر با کد ثابت

شش پرسش از سه داستان، پنج تا هفت محل ابهام دارند. پس از ثابت شدن الگوریتم، تمام این محل‌ها فعال شدند. این پرسش‌ها قبلاً دیده شده‌اند؛ خانوادهٔ بزرگ‌تر جدید است و این آزمایش را مجموعه‌دادهٔ خارجی مستقل نمی‌نامیم.

{table(stress['curated_larger_family'])}

زمان نسخهٔ کران‌گذاری نسبت به سریع‌ترین کنترل دیگر، بازاستفادهٔ افزایشی، حدود **{a['larger_real']['timing_reduction_percent']:.2f}٪** کمتر است. سه خوشه برای ادعای آماری قوی کافی نیست و بازهٔ اکتشافی شامل صفر است. کنترل بازاستفاده در تعداد فراخوانی‌ها بهتر است؛ کاهش زمان و کاهش تعداد فراخوانی‌ها را یکی نمی‌گیریم.

برای بررسی رفتار خارج از همین فرمول‌ها، ۳۲ مسئلهٔ مصنوعی تازه با شش محل ابهام و seedهای 16000–16031، پیش از دیدن خروجی آن‌ها ساخته شد. این‌ها آزمون محاسباتی‌اند، نه ۳۲ دامنهٔ واقعی.

{table(stress['fresh_synthetic'])}

در این آزمون، کران‌گذاری از شمارش افزایشی سریع‌تر است، اما نسبت به کنترل قویِ بازاستفادهٔ افزایشی حدود **{-a['synthetic_strongest']['timing_reduction_percent']:.2f}٪ کندتر** است. بنابراین برندهٔ عمومی نداریم. در همهٔ روش‌ها خروجی‌های گواهی‌شده یکسان مانده‌اند. کنترل‌های قوی‌ترِ این جدول پس از آزمایش اولیه افزوده شدند؛ الگوریتم عوض نشد و نتایج اولیه نیز نگهداری شده‌اند.

## مرز نوآوری و مقاله

تفکیک خطای ترجمه و استدلال در SymDiag نیز بررسی شده است. چندتفسیره بودن زبان در AmP و تصحیح تعاملی در INSPIRED سابقه دارند. کران‌گذاری معنایی به تفسیر انتزاعی و پاسخ‌های قطعی در اطلاعات ناقص مرتبط است؛ بازاستفاده از مدل‌های حل‌گر نیز سابقه دارد. پس هیچ‌یک از این عناوین به‌تنهایی ادعای «اولین روش» ما نیست.

چیزی که اکنون قابل دفاع است: پیاده‌سازی یک مسیر گواهی تفسیر با قرارداد روشن، قضیهٔ صحت مشروط، کنترل‌های قوی، مثال‌های نقضِ مستقل و اندازه‌گیری هزینه. پرسش نوآوریِ ادامهٔ پروژه این است که چگونه مجموعهٔ تفسیرهای دارای پوشش معنایی معتبر را در تغییر دامنه یاد بگیریم و دانش را با حفظ گواهی به‌روزرسانی کنیم. این قسمت نباید با چند گزینهٔ مصنوعی یا نتایج ParaRules پرشده فرض شود.

## وضعیت اجرا و فایل‌ها

۶۹ آزمون پیاده‌سازی گذشت. تمام اجراها CPU بودند. کد، دادهٔ مجاز، پروتکل‌ها، محیط، نسخه‌های شکست‌خورده، نتایج خام، بوت‌استرپ و پیش‌نویس مقاله در بسته هستند. مقاله هنوز نتایج عصبی، مقایسهٔ منصفانه با مدل‌های منتشرشده، دامنه‌های واقعی متعدد یا ارزیابی انسانی جدید را ادعا نمی‌کند.

فایل محوری: `src/fol_interval_certifier.py`. پیش‌نویس یکپارچه: `manuscript/PILOT_MANUSCRIPT.md`. شرح ریاضی هسته: `manuscript/INTERPRETATION_CERTIFICATE_METHOD.md`. دستورهای بازتولید: `reports/REPRODUCE_FOL.md`.
'''
 (ROOT/'reports/FOL_CONTINUATION_FA.md').write_text(fa)
 method=r'''# Interpretation-stable reasoning: implemented formal core

Original project title: **Dynamic Neural-Symbolic Reasoning Framework for Cross-Domain Knowledge Integration and Explainable Natural Language Understanding**.

This is a working Methods and theory extension. It specifies the implementation in `fol_interval_certifier.py`; it does not establish original invention of abstract interpretation or certain-answer semantics.

## Task and semantic contract

Let $C(x)$ be a finite set of candidate interpretations, indexed by $\theta$. Each gives premises $K_\theta$ and query $Q_\theta$. For a consistent premise theory, the logical answer is True if it entails the query, False if it entails its negation, and Uncertain if both query values have a model. Inconsistency and solver failure are separately reported. This is classical first-order, open-world semantics over a nonempty uninterpreted domain, without a unique-name axiom or domain closure.

The implemented family independently changes OR to XOR or XOR to OR at selected structural occurrences. At most four are used in the primary experiment; larger-family tests use up to seven. Choice is global across quantified entities, rather than selected independently for each grounding. The front end consumes supplied FOL, not natural-language text or a neural distribution. General candidate generation and valid coverage of the intended interpretation remain separate research problems.

The exact reference enumerates the candidates, checks each polarity using an incremental solver and abstains as soon as two consistent candidates yield different labels. Inconsistent candidates are explicitly excluded from the admissible set. A remaining solver-unknown status prevents a certificate. Uniformity is a conditional logical guarantee, not evidence that the candidate set contains the intended meaning.

## Must/may construction

For each formula $F$, construct $F^-$ and $F^+$ such that for every allowed choice $\theta$,

$$F^-\Rightarrow F_\theta\Rightarrow F^+.$$

Atoms and equality have identical bounds. Negation reverses them: $(\neg A)^-=\neg A^+$ and $(\neg A)^+=\neg A^-$. Conjunction and disjunction apply their connective to the respective lower or upper bounds. Implication reverses the antecedent bound: $(A\to B)^-=(A^+\to B^-)$ and $(A\to B)^+=(A^-\to B^+)$. Quantifiers apply to both bounds within the original lexical scope.

For XOR, sound bounds are

$$ (A\oplus B)^-=(A^-\land\neg B^+)\lor(\neg A^+\land B^-), $$
$$ (A\oplus B)^+=(A^+\land\neg B^-)\lor(\neg A^-\land B^+). $$

An occurrence permitting either OR or XOR has the lower XOR bound and upper $A^+\lor B^+$. Equivalence uses the reversed complements of XOR bounds. If a subtree has no ambiguity, it is compiled once and reused as both bounds. This optimization changes implementation cost, not semantics.

**Proposition 1 (sound bounds).** The displayed implication holds for every implemented formula and every shared interpretation assignment.

**Proof.** Atoms and equality are immediate. Negation is antitone, while conjunction, disjunction and each fixed quantifier are monotone in their formula arguments. Implication is antitone in its antecedent and monotone in its consequent. The XOR lower bound requires one operand always true and the other always false; the upper bound permits either such possibility. XOR implies OR, so taking the XOR lower bound and OR upper bound is sound for either choice. Structural induction completes the proof. Quantifier bounds need not be tight: existential choice and a quantifier cannot in general be interchanged. The implementation preserves the original binding and uses only sound inclusions. This is an application of established abstract-interpretation reasoning, not a new foundational theorem.

## Certificates and fallback

A common positive model satisfies $K^-\land Q^-$. A common negative model satisfies $K^-\land\neg Q^+$. If both exist, every candidate has models with both query values; Uncertain is certified.

True is certified by

$$\operatorname{SAT}(K^-\land Q^-),\qquad
\operatorname{UNSAT}(K^+\land\neg Q^-).$$

False is certified by

$$\operatorname{SAT}(K^-\land\neg Q^+),\qquad
\operatorname{UNSAT}(K^+\land Q^+).$$

**Proposition 2 (conditional answer soundness).** A completed bound certificate returns the same logical answer for every candidate interpretation. If no sufficient certificate is found, exact incremental enumeration preserves the reference decision, subject to definitive and sound solver results.

**Proof.** A common model satisfies every candidate premise theory and the corresponding query polarity by Proposition 1. For True, any candidate countermodel would satisfy $K^+$ and $\neg Q^-$, contradicting the UNSAT obligation. The common positive model prevents a vacuous result due to inconsistency. False is symmetric. Two common models establish both query possibilities for every candidate. Failure to find a common model establishes nothing about individual candidates and therefore triggers the exact fallback. The fallback follows the same admissibility, solver-failure and answer-uniformity contract as the reference. QED.

The implementation stores obligation names and solver statuses. A successful SAT model can be exported as a finite relational structure. A separate Python evaluator checks the input AST over the full finite universe without importing Z3. For UNSAT, this pilot replays source support sets with the same solver; it does not provide an independently checked general FOL proof calculus. Thus these are solver-relative certificates, and must not be described as the complete natural-language proof-generation mechanism in the original abstract.

## Coverage and semantic risk

If the intended interpretation is consistent and lies in $C(x)$, a sound completed uniform certificate is correct relative to that interpretation. Without membership, certainty within a wrong family can still produce a wrong semantic answer. If a future parser establishes $P(\theta^*\notin C(X))\leq\epsilon$ and verification failure probability is bounded by $\delta$, then

$$P(\widehat Y\ne Y, A)\leq\epsilon+\delta,$$

where $A$ is certificate acceptance and $Y$ denotes the intended logical semantics, not necessarily a corpus label. Selective risk is bounded only by $\min(1,(\epsilon+\delta)/P(A))$. This pilot does not estimate $\epsilon$, prove exchangeability under domain shift or claim a calibrated semantic guarantee. The bound is a standard containment/union-bound observation, not a new statistical result.

## Implemented comparisons and limits

The audit compares exhaustive and early-stopping enumeration, selector-parameterized solving, finite-model reuse, incremental model reuse, and bound certification with exact fallback. All primary methods reproduce the same 202 certification decisions in each timing repetition. CPU times include bound construction, model extraction where used, checking and fallback. Calls and runtime are separate outcomes: a method can make fewer calls yet run more slowly.

All development revisions remain available, including the first model-reuse and interval implementations that lost to stronger controls. The final implementation has a modest primary timing improvement whose story-cluster interval includes zero. Larger-family and synthetic results are separately reported; the latter do not establish dominance over incremental model reuse. No end-to-end FOLIO NLU claim follows from supplied FOL.

## Relation to the original research objective

The intended reusable rule structure can be the typed logic and certification contract; a learned domain-specific grounding module can supply the candidate set. Dynamic rule admission would then have to maintain semantic coverage and consistency under updates. This pilot implements the downstream certificate, not that learned guarantee. The prior controlled-English neural front end remains implemented for its limited fragment; it has not been silently promoted to a general FOL parser.

A credible further contribution must show how candidate coverage and safe knowledge adaptation are learned under real domain shift. Simply adding an LLM parser to this verifier, renaming known error-reduction or claiming first use of multiple interpretations is insufficient to establish novelty.

## Primary references and closest overlap

- Cousot and Cousot (1977), Abstract interpretation. https://www.di.ens.fr/~cousot/COUSOTpapers/POPL77.shtml
- Imieliński and Lipski (1984), Incomplete Information in Relational Databases. DOI: 10.1145/1634.1886. Certain-answer reasoning is a relevant established analogy; this work does not claim equivalence of all relational and FOL settings.
- Brunello et al. (2026), Fixing FOLIO and MALLS. https://aclanthology.org/2026.emnlp-main.576/ . Public curated dataset: https://huggingface.co/datasets/DSAVlab-UNIUD/FOLIO_validation-curated .
- Cui et al. (2026), SymDiag. https://arxiv.org/abs/2608.08786 . Translation-versus-reasoning diagnosis is not claimed as exclusive to our work.
- Stengel-Eskin, Rawlins and Van Durme (2024), Zero and Few-shot Semantic Parsing with Ambiguous Inputs. https://proceedings.iclr.cc/paper_files/paper/2024/hash/eae78bf2712f222f101bd7d12f875a57-Abstract-Conference.html .
- Mo et al. (2022), Towards Transparent Interactive Semantic Parsing via Step-by-Step Correction. https://aclanthology.org/2022.findings-acl.28/ .
- Aquino, Denaro and Pezzè (2021), Reusing Solutions Modulo Theories. DOI: 10.1109/TSE.2019.2898199. https://boa.unimib.it/handle/10281/228173 . Model reuse itself is prior art.
'''
 (ROOT/'manuscript/INTERPRETATION_CERTIFICATE_METHOD.md').write_text(method)
 archive=ROOT/'history/pre_fol_core_PILOT_MANUSCRIPT.md'
 if not archive.exists():shutil.copy2(ROOT/'manuscript/PILOT_MANUSCRIPT.md',archive)
 paper=archive.read_text();paper=paper.replace('The evidence below concerns controlled-language and paraphrased-rule transfer, not general cross-domain natural-language understanding.','The evidence concerns controlled-language/style transfer and FOL-input certification efficiency, not general cross-domain natural-language understanding.')
 paper=paper.replace('## 1. Introduction','An additional formal-core study uses 202 curated FOLIO conclusions with supplied formulas. Must/may interpretation bounds reproduce exact certification decisions while reducing solver checks by 41.39% relative to incremental enumeration. The mean timing reduction is 8.08%, with a 95% exploratory story-cluster interval spanning zero. Stronger synthetic controls show that the approach is not uniformly fastest.\n\n## 1. Introduction',1)
 core='''### 3.5 Interpretation-stable formal core

The new downstream core retains a finite family of interpretations rather than equating a proof in one parsed program with semantic certainty. In the current experiment, independent OR/XOR choices generate the family from supplied FOL. Sound lower/upper formulas satisfy $F^- \\Rightarrow F_\\theta \\Rightarrow F^+$ for every choice. Common models and refutations of upper envelopes can certify a shared True, False or Uncertain answer; insufficient bounds fall back to exact incremental enumeration. Quantifier binding is preserved and no finite-domain closure is assumed. The construction and conditional correctness proof are specified in `INTERPRETATION_CERTIFICATE_METHOD.md`. It is grounded in established abstract interpretation and certain-answer principles, not claimed as an entirely new theory.

'''
 paper=paper.replace('## 4. Data and evaluation',core+'## 4. Data and evaluation',1)
 data='''### 4.1 Curated FOL audit and efficiency protocol

The public author-curated FOLIO validation release has 73 premise stories and 202 conclusions. Repository commit, data hashes and CC BY 4.0 attribution are retained. This is distinct from the earlier legacy corpus and is not described as the official gated revised release. Inputs are curated formulas, so scores do not measure raw-language understanding. The primary interpretation family contains up to four OR/XOR sites. Three rotated timing repetitions are averaged within question before 10,000 paired story-cluster bootstrap samples. Implementation selection follows exploratory revisions on the same corpus. A frozen-code stress test expands six existing questions from three stories to five–seven sites, and evaluates 32 fresh seeded synthetic problems. These are computational stress tests, not independent domain-transfer datasets.

'''
 paper=paper.replace('## 5. Results',data+'## 5. Results',1)
 results='''### 5.1 Formal-core results and negative controls

All 202 curated inputs parse after a generic Unicode identifier fix, whose earlier failure is retained. Execution agrees with 189 corpus labels: seven conclusions have inconsistent premises, and six further labels disagree with the stated open-world contract. For those six, independently evaluated finite models establish both query possibilities; no dataset labels are altered. Across the curated formulas, 276 finite witnesses/countermodels pass a separate Python relational interpreter, 114 UNSAT supports replay and seven inconsistent cores replay. UNSAT replay still trusts the solver.

Without clarification, 181 questions have a uniform admissible-family answer, of which 175 agree with corpus labels. Thus stability alone does not eliminate annotation or semantic mismatch. Every tested certifier returns the same decision as exact enumeration. The final bound implementation averages 2.797 checks and 5.897 ms versus 4.772 checks and 6.416 ms for incremental early stopping. This is a 41.39% check reduction (exploratory 95% story-cluster interval [25.86,53.68]%) and 8.08% mean timing reduction (interval [-7.53,22.42]%). Timing superiority is therefore not established. Initial model-reuse and interval versions were slower and remain archived.

For the six larger real-formula families, the bound method averages 12.318 ms versus 17.076 ms for the fastest other control, incremental model reuse. The 27.86% point reduction has a wide three-story interval spanning zero. Model reuse makes fewer solver calls than bounds in that subset. On 32 fresh synthetic problems, bounds take 11.165 ms versus 10.005 ms for incremental model reuse, an 11.59% slowdown. These outcomes support a useful conditional efficiency path, not universal dominance. A separate clarification simulation finds exact-budget acquisition ties established label-entropy and EC2 controls; it does not establish a new acquisition algorithm.

'''
 paper=paper.replace('## 6. Explanation analysis',results+'## 6. Explanation analysis',1)
 paper=paper.replace('## 8. Conclusion','The new FOL certificate is conditional on the candidate family and the stated semantics. No general neural FOL parser, semantic-coverage calibration, real cross-domain update guarantee or independent FOL proof checker is established. Existing work on abstract interpretation, incomplete-information query answering, ambiguous semantic parsing, interactive correction, model reuse and SymDiag diagnosis prevents treating these ingredients as exclusive inventions.\n\n## 8. Conclusion',1)
 paper=paper.replace('The practical outcome is a transparent implementation with separate interpretation, inference and explanation checks.','The practical outcome is a transparent implementation with separate interpretation, inference and explanation checks, supplemented by a sound interpretation-bound certificate and audited efficiency comparisons.',1)
 paper+='\n5. Brunello et al. (2026). Fixing FOLIO and MALLS. https://aclanthology.org/2026.emnlp-main.576/\n6. Cousot and Cousot (1977). Abstract interpretation. https://www.di.ens.fr/~cousot/COUSOTpapers/POPL77.shtml\n7. Imieliński and Lipski (1984). Incomplete Information in Relational Databases. DOI: 10.1145/1634.1886.\n8. Cui et al. (2026). SymDiag. https://arxiv.org/abs/2608.08786\n9. Stengel-Eskin et al. (2024). Zero and Few-shot Semantic Parsing with Ambiguous Inputs. ICLR.\n10. Mo et al. (2022). Towards Transparent Interactive Semantic Parsing via Step-by-Step Correction. https://aclanthology.org/2022.findings-acl.28/\n11. Aquino et al. (2021). Reusing Solutions Modulo Theories. DOI: 10.1109/TSE.2019.2898199.\n'
 (ROOT/'manuscript/PILOT_MANUSCRIPT.md').write_text(paper)
 print('Persian report, formal Methods and consolidated manuscript written.')
if __name__=='__main__':main()
