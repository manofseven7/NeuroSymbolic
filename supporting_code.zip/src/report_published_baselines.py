"""Build the NS024 report/figure solely from audited prediction files."""
import csv,json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'results/published_baselines_v1'
NAMES={'Ours_NS023':'Our frozen NS023 adapter','cot':'CoT / Qwen-7B',
       'faithful':'Faithful CoT / author rules','faithful_training_only':'Faithful CoT / training rules',
       'htt':'HtT / Qwen-7B','EpiGNN2025_shared_grounder':'EpiGNN / query labels',
       'EpiGNN2025_shared_grounder_program':'EpiGNN / program labels'}

def main():
    summary=json.loads((OUT/'comparison_summary.json').read_text())
    metrics=summary['metrics'];methods=list(dict.fromkeys(x['method'] for x in metrics))
    get=lambda m,s:next(x for x in metrics if x['method']==m and x['subset']==s)
    rows=[]
    for m in methods:
        all_,short,long=[get(m,s) for s in ['all','short_2_3','long_4_10']]
        rows.append(f"| {NAMES[m]} | {all_['accuracy_percent']:.2f} | {short['accuracy_percent']:.2f} | {long['accuracy_percent']:.2f} | {all_['macro_f1_percent']:.2f} |")
    header='''# مقایسهٔ اجرایی بیس‌لاین‌های منتشرشده، NS024

این گزارش از پیش‌بینی‌های ذخیره‌شده محاسبه شده است؛ هیچ عدد عملکردی از جدول مقاله‌های دیگر جایگزین اجرای ما نشده است.

## شرایط و حدود مقایسه

- ۱٬۰۲۶ سؤال یکسان CLUTRR، شامل ۱۲۳ سؤال دو/سه‌مرحله‌ای و ۹۰۳ سؤال چهار تا ده‌مرحله‌ای؛ سه بذر ۴۲، ۴۳ و ۴۴.
- برای هر بذر، همان ۲۵۶ داستان آموزشی و ۱۲۸ سؤال انتخاب مدل مرحلهٔ NS023 استفاده شد. پنج مثال ثابت مدل‌های زبانی از همان مخزن آموزشی انتخاب شدند.
- مدل مشترک روش‌های زبانی Qwen2.5-7B-Instruct با وزن ثابت، دقت bfloat16، تولید حریصانه و سقف ۷۶۸ توکن است. استفاده از Qwen و مثال‌های آموزشی مشترک، انطباق کنترل‌شدهٔ روش‌هاست؛ بازتولید دقیق مدل بسته و بودجهٔ مقالهٔ اصلی نیست.
- Faithful CoT از حل‌کنندهٔ نویسندگان استفاده می‌کند. جدول قواعد کامل نویسندگان دانش پیشین اضافی دارد؛ نسخهٔ جدول قواعد آموزشی نیز جداگانه گزارش می‌شود.
- HtT از RuleLibrary و قالب دانش نویسندگان استفاده می‌کند؛ قواعد از همان داستان‌های آموزشی القا می‌شوند، با حد پوشش ۲ و اطمینان ۰٫۷.
- EpiGNN از کد مدل نویسندگان، ۱۰۰ دوره، ۹ دور انتشار و انتخاب صرفاً با مجموعهٔ ۱۲۸‌سؤالی استفاده می‌کند. گراف آزمون از استخراج‌کنندهٔ منجمد NS023 می‌آید. هم آموزش پاسخ نهایی و هم آموزش اتم‌های برهان اجرا شده‌اند؛ همان اطلاعات مراحل میانی و جنسیت آموزشی که در اختیار روش ما بود، در نسخهٔ دوم فراهم شده است. در هر سه بذر، نسخهٔ پاسخ نهایی روی مجموعهٔ انتخاب بهتر بود.
- برچسب آزمون به پیش‌بینی‌کننده وارد نمی‌شود؛ قطع ارتباط گراف یا خروجی نامعتبر خطا شمرده می‌شود. سؤال ناموفق حذف نمی‌شود.
- این آزمون قبلاً در توسعهٔ روش ما دیده شده است. اختلاف‌ها شاهد مقایسهٔ رگرسیونی‌اند؛ تعمیم مستقل به زنجیره‌های بلند هنوز نیازمند آزمون تازه است. بودجهٔ داستان‌ها برابر است؛ سابقهٔ پیش‌آموزش و هزینهٔ محاسباتی روش‌ها یکسان نیست.

## نتایج واقعی

همهٔ اعداد درصد هستند؛ ستون‌های دقت میانگین روی سه بذرند. Macro-F1 تجمیعی با فضای برچسب ثابت محاسبه شده است.

| روش | دقت کل | دقت کوتاه | دقت بلند | Macro-F1 کل |
|---|---:|---:|---:|---:|
'''
    text=header+'\n'.join(rows)+'\n\n'
    if not summary['complete']:
        text+='**وضعیت: اجرای سه روش زبانی هنوز کامل نشده و رتبه‌بندی نهایی ارائه نشده است. جدول فعلی فقط شامل اجراهای کامل است.**\n\n'
    text+='## عدم قطعیت اختلاف\n\nبازه‌ها از ۱۰٬۰۰۰ بازنمونه‌گیری جفت‌شدهٔ داستان‌ها به دست آمده‌اند؛ سه بذر هر داستان کنار هم نگه داشته شده‌اند. این بازه‌ها مشروط به همین سه مخزن آموزشی و همین آزمون دیده‌شده هستند.\n\n| بیس‌لاین | برتری روش ما در بلند (واحد درصد) | بازهٔ ۹۵٪ |\n|---|---:|---:|\n'
    for x in summary['paired']:
        if x['subset']=='long_4_10':text+=f"| {NAMES[x['baseline']]} | {x['ours_minus_baseline_pp']:+.2f} | [{x['ci95_low']:.2f}, {x['ci95_high']:.2f}] |\n"
    resource_file=OUT/'llm_generation_resources.csv'
    if resource_file.exists():
        text+='\n## هزینهٔ تولید مدل زبانی\n\nزمان‌های زیر مجموع زمان دسته‌های تولید هستند؛ زمان بارگذاری مدل و القای قواعد جداست. زمان تکرارشده در هر رکورد فقط یک بار برای هر دسته محاسبه شده است. مقایسهٔ زمان CPU روش ما با GPU این مدل‌ها به‌عنوان برتری سخت‌افزاری گزارش نمی‌شود.\n\n| روش | میانگین توکن ورودی | میانگین توکن خروجی | ثانیهٔ تولید کل | خروجی قطع‌شده (%) |\n|---|---:|---:|---:|---:|\n'
        for r in csv.DictReader(resource_file.open()):
            text+=f"| {NAMES[r['method']]} | {float(r['mean_input_tokens']):.1f} | {float(r['mean_output_tokens']):.1f} | {float(r['generation_seconds']):.1f} | {float(r['truncated_percent']):.2f} |\n"
    text+='''
## ممیزی و بازتولید

اجرای اولیهٔ Faithful CoT فاقد زیرسؤال‌های متنی کامل و نمونه‌های متنی HtT فاقد مراحل استخراج مسیر بود. این نقص با ممیزی قالب، پیش از تحلیل دقت آزمون، شناسایی شد. خروجی اولیه در `payload/llm_initial_codeonly` حفظ و از مقایسهٔ اصلی کنار گذاشته شد. اجرای اصلاح‌شده مراحل را بازگرداند؛ مرز نام برچسب‌ها نیز اصلاح شد تا `great-grandfather` به‌اشتباه `grandfather` شمرده نشود. اندازهٔ دسته برای سرعت از ۳۲ به ۱۲۸ تغییر کرد. مدل، داستان‌ها، مثال‌ها و سقف تولید ثابت ماندند. آزمون اولیهٔ اصلاح‌شده روی ۸ سؤال مجموعهٔ انتخاب انجام شد.

پیش‌بینی‌های منجمد روش ما در هر ۳٬۰۷۸ مورد با خروجی قبلی یکسان بودند. ۹۹ آزمون نرم‌افزاری پروژه، شامل چهار آزمون جدید کنترل مقایسه، پاس شدند. داده‌های خام، کد منبع پین‌شده، وزن‌های EpiGNN، خروجی متنی مدل زبانی، تنظیمات و تحلیل قابل محاسبه در پروژه نگهداری می‌شوند؛ وزن ۱۵ گیگابایتی Qwen در بسته گنجانده نشده و شناسهٔ دقیق نسخهٔ آن ثبت شده است.

دستور تحلیل: `python3 src/analyze_published_baselines.py` و سپس `python3 src/report_published_baselines.py`. دستور آزمون: `PYTHONPATH=src python3 -m unittest discover -s tests`.

وجود برتری در این مقایسه به‌تنهایی به معنی شکست همهٔ روش‌های معروف، SOTA یا آمادگی قطعی Q1 نیست. نتیجه به همین داده، مدل و بودجه محدود است و باید همراه با برنده‌شدن یا باختن مقابل تمام بیس‌لاین‌ها گزارش شود.
'''
    (ROOT/'reports/Published_Baseline_Comparison_FA.md').write_text(text)
    fig,axes=plt.subplots(1,2,figsize=(11.7,4.8),gridspec_kw={'width_ratios':[1,1.2]})
    colors=['#146b8c' if m=='Ours_NS023' else '#929ca5' for m in methods]
    yy=np.arange(len(methods))
    axes[0].barh(yy,[get(m,'long_4_10')['accuracy_percent'] for m in methods],color=colors)
    axes[0].set_yticks(yy,[NAMES[m] for m in methods],fontsize=8)
    axes[0].invert_yaxis();axes[0].set_xlabel('Accuracy (%)');axes[0].set_title('903 seen stories, hops 4-10')
    for i,m in enumerate(methods):
        v=get(m,'long_4_10')['accuracy_percent'];axes[0].text(v+.5,i,f'{v:.2f}',va='center',fontsize=8)
    axes[0].set_xlim(0,max(get(m,'long_4_10')['accuracy_percent'] for m in methods)+9)
    hoprows=list(csv.DictReader((OUT/'comparison_by_hop_seed.csv').open()))
    for m in methods:
        hops=sorted({int(r['hops']) for r in hoprows if r['method']==m})
        vals=[np.mean([float(r['accuracy_percent']) for r in hoprows if r['method']==m and int(r['hops'])==h]) for h in hops]
        axes[1].plot(hops,vals,marker='o',markersize=3,linewidth=2 if m=='Ours_NS023' else 1,label=NAMES[m])
    axes[1].set_xlabel('Reference reasoning hops');axes[1].set_ylabel('Accuracy (%)')
    axes[1].set_title('Identical inputs, three training subsets');axes[1].legend(fontsize=7)
    for ax in axes:
        ax.spines[['top','right']].set_visible(False);ax.grid(axis='y',alpha=.14);ax.set_axisbelow(True)
    fig.suptitle('NS024: executed adaptations; previously seen regression test',fontsize=11)
    fig.tight_layout()
    for suffix in ['png','pdf']:fig.savefig(OUT/f'published_baselines.{suffix}',dpi=180,bbox_inches='tight')
    print('Report and figure generated; complete:',summary['complete'])

if __name__=='__main__':main()
