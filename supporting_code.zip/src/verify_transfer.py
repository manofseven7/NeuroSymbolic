"""Independent reference, metadata separation, traces and closure checks."""
import csv,hashlib,json
from pathlib import Path
import joblib
import text_reasoner as t
import transfer_rules as x
import fulltext_transfer as f
from closure_certificate import certify_absence

def main():
    root=Path('results/transfer_v1');data=json.loads((root/'prepared.json').read_text());cfg=json.loads(Path('configs/transfer_v1.json').read_text());sel=json.loads((root/'selection.json').read_text());old=json.loads(Path('results/learned_parser_v1/selection.json').read_text());sourcepath=Path('results/learned_parser_v1')/(old['selected']+'.joblib');assert hashlib.sha256(sourcepath.read_bytes()).hexdigest()==sel['source_model_sha256'];assert hashlib.sha256((root/'adapted.joblib').read_bytes()).hexdigest()==sel['adapted_model_sha256']
    labels=json.loads((root/'target_labels.json').read_text());testtexts={s for r in data['test'] for s in r['units']};assert not testtexts&{r['text'] for group in labels.values() for r in group}
    # Upstream IDs are partition-local and repeat across splits. Compare actual
    # context/canonical contents instead of incorrectly assuming global IDs.
    reused_ids=len({r['id'] for r in data['train']}&{r['id'] for r in data['test']})
    assert not ({r['upstream_theory_sha256'] for r in data['train']}&{r['upstream_theory_sha256'] for r in data['test']})
    semantic=lambda r:json.dumps(sorted(json.dumps(a,sort_keys=True) for a in r['facts']+r['rule_gold']))
    assert not ({semantic(r) for r in data['train']}&{semantic(r) for r in data['test']})
    traces=[json.loads(v) for v in (root/'traces.jsonl').read_text().splitlines()];byid={r['id']:r for r in data['test']};models={'source':joblib.load(sourcepath),'adapted':joblib.load(root/'adapted.joblib')};vocab=json.loads((root/'data_audit.json').read_text())['selected']['vocabulary'];cache={};checks=0
    for tr in traces:
        r=byid[tr['theory_id']];qs=tr['queried_rule_units'];assert len(qs)<=tr['budget'] and len(qs)==len(set(qs));assert set(tr['admitted_units'])|set(tr['unavailable_annotation_units'])==set(qs)
        for i,got in enumerate(tr['chosen_rules']):
            if i in tr['admitted_units']:expected=x.asttuple(r['rule_gold'][i])
            else:
                key=(tr['model'],r['units'][i])
                if key not in cache:cache[key]=x.choices(models[tr['model']],r['units'][i],vocab)
                cc=cache[key];expected=cc[0][0] if cc else None
            assert json.dumps(got)==json.dumps(expected)
        checks+=1
    canonical=0;badcanonical=0
    for r in data['test']:
        gold=[x.asttuple(a) for a in r['rule_gold']]
        for q in r['questions']:
            y,*_=x.infer(r['facts'],r['units'],gold,q['query']);canonical+=1;badcanonical+=y!=q['answer']
    (root/'verification.json').write_text(json.dumps(dict(theory_policy_traces=checks,only_queried_interpretations_modified='PASS',budgets_and_unique_queries='PASS',frozen_weights_hashes='PASS',target_selected_text_overlap=0,partition_local_ids_reused=reused_ids,identical_train_test_contexts=0,identical_train_test_canonical_programs=0,reference_questions_checked=canonical,reference_answer_disagreements=badcanonical),indent=2))
    # Entire raw-text predictor uses only raw theory, raw question, fixed source
    # vocabulary, unlabeled-train names and frozen neural query parser.
    out=Path('results/fulltext_transfer_v1');raw=[json.loads(v) for v in Path('third_party/RuleTaker_NatLang/meta-test.jsonl').read_text().splitlines()];names=json.loads((out/'name_lexicon.json').read_text());preds={(r['theory_id'],r['question_id']):int(r['prediction']) for r in csv.DictReader((out/'questions.csv').open())};absence=invalid=0;replayed=0;example=None
    symbolic_correct=0;symbolic_n=0
    for ti,r in enumerate(raw):
        records,info=f.parse_raw(r['theory'],names,vocab)
        for qid,q in r['questions'].items():
            qa=models['source'].predict(q['question'].strip().rstrip('.'))[2];positive=qa[:3]+(True,);y,pf,known=t.run(records,positive);present=positive in known;answer=present if qa[3] else not present
            assert int(answer)==preds[(r['id'],qid)]
            sq=t.atom(q['question']);sp=sq[:3]+(True,);_,_,sk=t.run(records,sp);sa=(sp in sk) if sq[3] else not(sp in sk);symbolic_correct+=sa==q['answer'];symbolic_n+=1
            if not present:
                ok=certify_absence(records,positive,known);absence+=1;invalid+=not ok
                if example is None:example=dict(theory_id=r['id'],question=q['question'],absent_positive_literal=positive,answer_under_cwa=bool(answer),finite_closure=list(known),certificate_valid=ok,scope='Non-entailment/closed-world answer;not an explicit negative-literal derivation')
            if ti in [0,len(raw)-1]:replayed+=1
    result=dict(all_raw_predictions_recomputed=len(preds),first_last_theory_prediction_replays=replayed,absence_certificates_checked=absence,invalid_absence_certificates=invalid,prediction_inputs='Raw theory,raw question,source-trained vocabulary,unlabeled-train names,frozen MLP. No supplied goldfacts,querymeanings,rulecountorformula.',scope='All certificate claims conditional on parsed finite positive-Horn program;not human semantic proof or general FOL validity.')
    (out/'verification.json').write_text(json.dumps(result,indent=2));(out/'absence_certificate_example.json').write_text(json.dumps(example,indent=2));print(result)
    (out/'symbolic_query_ablation.json').write_text(json.dumps(dict(status='Post-result necessity ablation,no retuning',question_parser='Existing fixed symbolic atom parser',questions=symbolic_n,correct=symbolic_correct,accuracy=symbolic_correct/symbolic_n,conclusion='This benchmark result does not demonstrate necessity or superiority of the neural query parser.'),indent=2))

if __name__=='__main__':main()
