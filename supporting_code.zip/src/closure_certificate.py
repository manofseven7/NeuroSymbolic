"""Finite positive-Horn least-closure certificates, not general FOL proofs."""
import itertools
import text_reasoner as t

def certify_absence(records,query,known):
    if query in known:return False
    mapping={sid:a for sid,text,a in records};seen=set();entities={v for a in known for v in a[1:3] if v and v!='?x'}|{v for v in query[1:3] if v and v!='?x'}
    # Every included derived atom must actually be derivable from earlier nodes.
    for atom,node in known.items():
        if node['id'] not in mapping:return False
        kind,body,head=mapping[node['id']]
        if kind=='fact':
            if atom!=head:return False
        else:
            x=node.get('binding','');bb=tuple(t.ground(a,x) for a in body)
            if atom!=t.ground(head,x) or not all(a in seen for a in bb):return False
        seen.add(atom)
    # The set must contain all premises and be closed under every rule instance.
    for sid,text,(kind,body,head) in records:
        if kind=='fact':
            if head not in seen:return False
        else:
            variable=any('?x' in a for a in (*body,head))
            for x in sorted(entities) if variable else ['']:
                if all(t.ground(a,x) in seen for a in body) and t.ground(head,x) not in seen:return False
    return True
