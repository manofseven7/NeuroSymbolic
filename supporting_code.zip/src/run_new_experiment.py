"""Non-overwriting wrapper for the exact reference; preserves recorded runs."""
import argparse
from pathlib import Path
import preflight

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--config',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    args=p.parse_args()
    if args.out.exists():
        p.error('Output already exists. Choose a new directory; recorded runs are immutable.')
    preflight.run(args.config,args.out)
