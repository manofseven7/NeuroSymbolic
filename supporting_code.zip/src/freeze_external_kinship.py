import csv,json,hashlib,time,joblib
from pathlib import Path
from external_kinship import *
ROOT=Path(__file__).resolve().parents[1]
def main():
 out=ROOT/'results/external_kinship_v1';val=list(csv.DictReader((ROOT/'third_party/CLUTRR_external/validation.csv').open(encoding='utf-8-sig')));by={r['id']:r for r in val};frozen={'experiment':'NS-EXTERNAL-KINSHIP-020','test_read':False,'frozen_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'seeds':{}}
 for seed in [42,43,44]:
  rec=json.loads((out/f'train_{seed}.json').read_text());model=joblib.load(out/f'model_{seed}.joblib');gate=[by[i] for i in rec['gate_ids']];audit=[by[i] for i in rec['audit_ids']];gp=[model.prepare(r['story'],parse_query(r['query'])) for r in gate];labels=[r['target_text'] for r in gate];candidates=[(tuple(x['rule']),x['training_support']) for x in rec['admission_log']];rules,log=admit_rule_bundle(gp,labels,candidates)
  scores={}
  for kind in ['ungated','no_composition','direct','prototype']:
   rr=rec['candidate_rules'] if kind=='ungated' else []
   scores[kind]=sum((p[kind] if kind in ['direct','prototype'] else execute(selected_facts(p),p['query'],rr)['preferred'])==y for p,y in zip(gp,labels))
  best=min(scores,key=lambda k:(-scores[k],k));rec['bundle_rules']=rules;rec['bundle_admission']=log;rec['selected_control']=best;rec['control_validation_correct']=scores;ap=[model.prepare(r['story'],parse_query(r['query'])) for r in audit];rec['audit']['bundle']={'correct':sum(execute(selected_facts(p),p['query'],rules)['preferred']==r['target_text'] for p,r in zip(ap,audit)),'n':len(audit)};(out/f'frozen_{seed}.json').write_text(json.dumps(rec,indent=2));frozen['seeds'][str(seed)]={'bundle':log,'control_validation_correct':scores,'selected_control':best,'audit_bundle':rec['audit']['bundle']};print(seed,frozen['seeds'][str(seed)],flush=True)
 frozen['sha256']={s:hashlib.sha256((ROOT/s).read_bytes()).hexdigest() for s in ['src/external_kinship.py','src/train_external_kinship.py','src/freeze_external_kinship.py','configs/external_kinship_v1.json']+[f'results/external_kinship_v1/{name}_{seed}.{ext}' for seed in [42,43,44] for name,ext in [('model','joblib'),('frozen','json')]]};(out/'FROZEN_BEFORE_TEST.json').write_text(json.dumps(frozen,indent=2))
if __name__=='__main__':main()
