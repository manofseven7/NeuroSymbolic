"""Retrieve the exact public author-repository files recorded in provenance."""
import hashlib,json,urllib.request
from pathlib import Path

def main():
    p=Path('third_party/LogicLM_ProofWriter');meta=json.loads((p/'provenance.json').read_text())
    for name,item in meta['files'].items():
        target=p/name
        if target.exists() and hashlib.sha256(target.read_bytes()).hexdigest()==item['sha256']:continue
        with urllib.request.urlopen(item['url'],timeout=60) as r:data=r.read()
        assert hashlib.sha256(data).hexdigest()==item['sha256'],name
        target.write_bytes(data)
    print('Exact pinned files available; SHA256 verified.')

if __name__=='__main__':main()
