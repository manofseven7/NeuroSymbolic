"""Integrate NS022/023 measured results; retain old negative stage020 results."""
import json,shutil
from pathlib import Path
from local_kinship_repair import ROOT
D=ROOT/'manuscript/review_version';P=D/'main.tex';O=ROOT/'results/consistent_kinship_v1'
def main():
 hist=ROOT/'history/manuscript_revision13_before_ns023';hist.mkdir(exist_ok=True)
 for name in ['main.tex','main.pdf','Article_Review_Source.zip']:
  if not (hist/name).exists():shutil.copy2(D/name,hist/name)
 s=P.read_text()
 if r'\label{sec:repairprotocol}' in s:raise RuntimeError('NS023 already integrated; rebuild the existing manuscript instead')
 start=s.index('\\begin{abstract}');end=s.index('\\end{abstract}',start)+len('\\end{abstract}')
 abstract=r'''\begin{abstract}
A valid symbolic derivation can remain unreliable when its program misinterprets language. We study an interpretation-stable interface separating a preferred answer and executed proof from agreement across retained meanings. Sound must/may bounds provide sufficient certificates, with exact fallback when inconclusive. On 202 curated FOLIO conclusions supplied as formulas, the interface preserves exact certification decisions and reduces solver calls by 41.39\% relative to incremental early stopping; runtime evidence is mixed against stronger controls. A frozen controlled-English integration increases certificate coverage from 48.33\% to 53.83\% on 600 previously used questions with simulated semantic corrections, without improving an already perfect preferred-answer baseline. An initial CLUTRR kinship adapter fails under reasoning-length shift. Two subsequent, explicitly separated repair studies address local grounding, incomplete negative labels, inverse relations and learned relation types. On a now-seen regression set of 903 four-to-ten-hop stories, mean accuracy across three seeds increases from 18.79\% after the first repair to 31.38\% after the second. On 1,005 previously unused four-hop stories, it increases from 45.07\% to 48.39\%, a paired difference of 3.32 points with exploratory 95\% interval [0.66,5.97]. Inverse-example training uses additional training-only gender annotations. The evidence supports auditable certification and practical depth-robustness improvements, while leaving unrestricted domain transfer and fresh five-to-ten-hop confirmation unestablished.
\end{abstract}'''
 s=s[:start]+abstract+s[end:]
 s=s.replace('Research manuscript for scientific review\\\\30 October 2026','Research manuscript for scientific review, revision 14\\\\30 October 2026')
 s=s.replace('including a negative generalization result and a bounded short-depth benefit.','including the initial negative result, two grounding repairs, a longer-depth regression improvement and separate confirmation at four hops.')
 protocol=r'''
\subsection{Separated repair protocols: NS022 and NS023}\label{sec:repairprotocol}
The initial test was subsequently used for error diagnosis and is therefore a \emph{seen regression set} for the repairs, not an unused confirmation set. NS022 compares two fixed local-input variants on the original admission validation, retaining the same 256 training programs per seed and original rule bundle. It selects the shortest sentence containing both ordered endpoints, falling back to a two-sentence window, delexicalizes entity names, and optionally omits negative pairs that reverse a reference proof leaf. All three seeds select this omission. A second test split, \texttt{gen\_train234\_test2to10/test.csv}, is accessed only after NS022 model selection: 1,026 deduplicated stories remain, including 903 four-to-ten-hop cases. No IDs or name-normalized complete stories overlap any raw split of the first configuration. This is another split of the same corpus, not another real-world domain.

NS023 is a separate, fixed $2\times2$ development study. The base front end trains on positive proof leaves and inverse examples rather than treating non-reference local pairs as definite negatives. Inverse labels use the subject's \emph{training-only gender annotation}, in addition to the original proof supervision. The 256 training-story budget remains fixed, but the annotation information is richer; gains cannot be attributed solely to decoding at an identical label budget. At inference, only text and the query are accepted. Candidate edges join names co-occurring in one sentence. Two optional factors are tested: reciprocal type/gender decoding and gender-typed generalization of composition rules. Four variants are evaluated only on the original 128 admission stories; ties use the fixed listed order, followed by a separate 128-story validation audit. No hyperparameter or architecture search follows their test results.

For reciprocal decoding, let $p_{uv}(r)$ be the local classifier probability and $\tau(r)$ its gender-independent relation type. The type for an unordered pair is chosen by
\[
 t^*_{uv}=\arg\max_t\left(\sum_{r:\tau(r)=t}p_{uv}(r)\right)
 \left(\sum_{r:\tau(r)=\operatorname{inv}(t)}p_{vu}(r)\right).
\]
Conditional gender probabilities from incoming selected types are pooled by summed log probability for each entity. Both directions then receive labels consistent with their chosen inverse types and the predicted target gender. Typed rules first replace each relation in training composition triples with its type. For each body-type pair, the most frequent training head type is retained, with deterministic tie resolution. Instantiation preserves the second premise's target gender. Neither procedure reads held-out gender, proof, path or answer annotations.

After selection and model hashing, NS023 is evaluated on both previously seen two-to-ten-hop tests and an unused split: \texttt{gen\_train234\_test2to10/validation.csv}. Its original name does not assign it a development role here: none of its examples fits or selects these models. Excluding IDs and normalized complete stories in \emph{all} earlier raw train, validation and test files leaves 2,601 questions: 1,596 two/three-hop and 1,005 four-hop. It contains no five-to-ten-hop questions. This split therefore confirms the four-hop comparison only. Both NS022 and NS023 use these identical retained questions, without semantic corrections. Paired bootstrap intervals average the three seed differences within each story before 10,000 story resamples. These intervals condition on the three selected training subsets.

The repair outcomes measure preferred-program answers and replayed proofs. They do not re-evaluate family certificates: reciprocal constraints couple edge choices and would require a newly specified retained-family construction before a selective-coverage comparison. The original certification results and conditional guarantee remain separately scoped.
'''
 s=s.replace('\\section{Results}\\label{sec:results}',protocol+'\n\\section{Results}\\label{sec:results}')
 results=r'''
\subsection{Repairing path construction and depth generalization}\label{sec:repairresults}
NS022 improves the initial grounder's long-depth regression accuracy from 2.49\% to 19.34\% on the original 1,003 longer questions, with reference-edge recall increasing from 20.90\% to 61.86\%. On its then-unused second test, four-to-ten-hop accuracy is 18.79\%, compared with 2.44\% for the initial grounder and 8.75\% for direct classification. This establishes a scoped grounding improvement, rather than an effect of extra oracle corrections.

Table~\ref{tab:repairselection} reports all four fixed NS023 admission comparisons. Different seeds select different variants, so reciprocal decoding is not claimed to be uniformly beneficial. The resulting validation-selected adapter improves both seen long-depth sets (Table~\ref{tab:repaircomparison}). On the 903-story second regression set, the improvement over NS022 is 12.59 percentage points [10.00,15.21]. Long reference-edge recall rises from 62.99\% to 77.70\%, and answer coverage rises from 42.12\% to 60.43\%. The paired interval describes a seen regression comparison; it does not erase the development history.

\begin{table}[tbp]\centering\small
\caption{NS023 admission-validation correct answers out of 128. All variants share positive/inverse-example training. D denotes directed local predictions; R denotes reciprocal decoding; O denotes original induced rules; T denotes typed learned rules. Audit uses a separate 128-story set.}\label{tab:repairselection}
\begin{tabular}{lrrrrlr}\toprule
Seed & D+O & R+O & D+T & R+T & Selected & Audit\\\midrule
42 & 80 & 78 & 80 & 78 & D+O & 83\\
43 & 77 & 77 & 78 & 79 & R+T & 84\\
44 & 80 & 77 & 82 & 79 & D+T & 84\\\bottomrule
\end{tabular}\end{table}

\begin{table}[tbp]\centering\small
\caption{Depth repair: mean preferred-answer accuracy across three seeds. Four-to-ten-hop tests are now seen regression sets. Only the last row is unused confirmation, at four hops. Brackets are paired story-bootstrap 95\% intervals for the NS023-minus-NS022 difference in percentage points.}\label{tab:repaircomparison}
\begin{tabular}{p{55mm}rrrr}\toprule
Evaluation & Stories & NS022 & NS023 & Difference [interval]\\\midrule
Original seen test, hops 4--10 & 1,003 & 19.34 & 32.14 & 12.79 [10.47,15.15]\\
Second seen test, hops 4--10 & 903 & 18.79 & 31.38 & 12.59 [10.00,15.21]\\
Unused split, hop 4 & 1,005 & 45.07 & 48.39 & 3.32 [0.66,5.97]\\\bottomrule
\end{tabular}\end{table}

On the unused split, accuracy over all 2,601 questions is 57.04\% versus 53.11\% for NS022. Four-hop accuracy improves by 3.32 points [0.66,5.97]; reference-edge recall improves from 76.29\% to 81.83\%. Answer coverage falls from 72.47\% to 70.48\%, showing that the accuracy gain is not simply more aggressive answering. All returned selected proofs replay. The complete suite has 95 passing tests, including a ten-edge symbolic-chain proof test; that test verifies executor capability and is not a raw-language accuracy result.

Figure~\ref{fig:depthrepair} separates the observed longer-chain regression behavior from unused four-hop confirmation. These results support a practical path-construction repair with additional training supervision. They neither establish fresh five-to-ten-hop generalization nor isolate the entire gain as a new reasoning algorithm: positive/inverse training, graph construction, optional reciprocal decoding and rule typing change together. The fixed-factor admission table records the tested variants without a further test-driven search. Accuracy at long depths remains limited, despite substantially fewer missing reference edges.

\begin{figure}[tbp]\centering
\includegraphics[width=\linewidth]{figures/reasoning_depth.pdf}
\caption{Measured depth behavior of the two repairs. Left: the same 1,026-story test, now a seen regression set for NS023, broken down by reference hop length. Right: evaluation-only four-hop questions from an unused split. Both panels average three training subsets; the panels have different data histories and should not be pooled.}\label{fig:depthrepair}
\end{figure}
\FloatBarrier
'''
 s=s.replace('\\section{Discussion and limitations}',results+'\n\\section{Discussion and limitations}')
 s=s.replace('The expanded implementation suite has 87 passing tests, including 11 new adapter tests and exhaustive comparisons with generated small candidate families.','At the initial NS020 stage, the suite had 87 passing tests, including 11 adapter tests and exhaustive comparisons with generated small candidate families. The repair-stage suite is reported separately below.')
 old='The negative full-test result, the reference-facts diagnostic and the short-versus-long decomposition identify grounding and reasoning-length shift as concrete boundaries.'
 s=s.replace(old,'The initial negative result and reference-facts diagnostic motivated the explicitly separated repairs. The later accuracy and edge-recall gains show that grounding defects are partly repairable; the unused split confirms an improvement at four hops, while longer-depth gains remain seen regression evidence.')
 s=s.replace('The post-hoc short-depth gain is useful evidence for a restricted next application, while its diagnostic status prevents it from rescuing a universal transfer claim.','The fixed repair studies provide a practical improvement beyond the initial short-depth observation, without establishing universal transfer. Inverse-example supervision additionally uses training genders, and the revised front end assumes that same-sentence entity pairs are candidate relationships. This assumption can introduce spurious edges in less structured prose.')
 s=s.replace('The fresh kinship test adds a restricted matched-depth benefit but fails on longer chains, despite valid selected proofs; broader semantic transfer is not established.',r'The initial kinship adapter fails under length shift, but subsequent grounding and path-construction repairs increase seen four-to-ten-hop accuracy to 31.38\% and improve unused four-hop accuracy from 45.07\% to 48.39\%. These are useful scoped improvements with richer training-only supervision; broader semantic transfer and fresh five-to-ten-hop confirmation remain open.')
 P.write_text(s);shutil.copy2(O/'reasoning_depth.pdf',D/'figures/reasoning_depth.pdf')
 print('updated',P)
if __name__=='__main__':main()
