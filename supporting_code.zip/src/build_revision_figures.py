"""Deterministic post-hoc visualization of immutable NS-015/016/017 outputs.
No training, inference rerun, threshold selection or new performance experiment.
"""
import csv,json,hashlib
from pathlib import Path
from collections import Counter,defaultdict
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'manuscript/review_version/figures';OUT.mkdir(exist_ok=True)
REPORT=ROOT/'reports/manuscript_revision_v12';REPORT.mkdir(exist_ok=True)
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'savefig.bbox':'tight'})
C='#176b87';G='#81919b';O='#c87936'
paths=['results/folio_interval_v2/runs.csv','results/folio_interval_v2/summary.json','results/folio_interval_v2/analysis.json','results/folio_interval_stress/summary.json','results/text_certificate_v1/questions.csv']
def readcsv(s):return list(csv.DictReader((ROOT/s).open()))
def save(fig,name):
 fig.savefig(OUT/(name+'.pdf'));fig.savefig(OUT/(name+'.png'),dpi=180);plt.close(fig)
r=readcsv(paths[0]);b=json.loads((ROOT/paths[1]).read_text());a=json.loads((ROOT/paths[2]).read_text());t=readcsv(paths[-1])
methods=['incremental_early_stop','selector_only','selector_model_reuse','incremental_model_reuse','interval_gate'];labels=['Incremental stop','Selector','Selector + reuse','Incremental + reuse','Must/may + fallback']
fig,axs=plt.subplots(1,2,figsize=(10,3.5),layout='constrained')
for ax,key,title in zip(axs,['mean_solver_checks','mean_runtime_ms'],['(a) Solver calls per question','(b) End-to-end time (ms/question)']):
 vals=[b[m][key] for m in methods];ax.barh(labels,vals,color=[G]*4+[C]);ax.invert_yaxis();ax.set_xlabel(title);ax.set_xlim(0,max(vals)*1.21)
 for i,v in enumerate(vals):ax.text(v+.07,i,f'{v:.3f}',va='center',fontsize=9)
save(fig,'primary_efficiency')
fig,axs=plt.subplots(1,2,figsize=(10,3),layout='constrained')
keys=['primary','larger_real','synthetic_strongest'];names=['Primary: 73 stories','Larger families: 3 stories','Synthetic: 32 cases']
for ax,metric,title in zip(axs,['solver_check','timing'],['(a) Solver-call reduction (%)','(b) Runtime reduction (%)']):
 for i,k in enumerate(keys):
  point=a[k][metric+'_reduction_percent'];lo,hi=a[k][('checks' if metric=='solver_check' else 'timing')+'_95pct_cluster_interval'];ax.errorbar(point,i,xerr=[[point-lo],[hi-point]],fmt='o',color=C,capsize=4)
 ax.axvline(0,color=G,ls='--',lw=1);ax.set_yticks(range(3),names);ax.invert_yaxis();ax.set_xlabel(title);ax.grid(axis='x',alpha=.15)
save(fig,'uncertainty')
rr=[x for x in r if x['method']=='interval_gate' and x['rep']=='0'];counts=Counter(x['certificate_kind'] for x in rr)
amb=[x for x in rr if int(x['branches'])>1];assert len(rr)==202 and len(amb)==97
kinds=['no_ambiguity_exact','two_common_models','positive_model_and_upper_refutation','negative_model_and_upper_refutation','exact_fallback'];names2=['No ambiguity: exact','Common models: Uncertain','Positive model + refutation','Negative model + refutation','Ambiguous: exact fallback']
fig,ax=plt.subplots(figsize=(8,3.2),layout='constrained');vs=[counts[k] for k in kinds];ax.barh(names2,vs,color=[G,C,C,C,O]);ax.invert_yaxis();ax.set_xlabel('Questions (one decision per question; n = 202)');ax.set_xlim(0,119)
for i,v in enumerate(vs):ax.text(v+1,i,str(v),va='center')
save(fig,'certificate_paths')
# Average repetitions within a question, then average distinct questions in a stratum.
groups=defaultdict(list)
for x in r:groups[x['id'],x['method']].append(x)
strata=[]
for branch in [1,2,4,8,16]:
 row={'branches':branch,'questions':sum(int(x['branches'])==branch for x in rr)}
 for m in ['incremental_early_stop','interval_gate']:
  qq=[v for (qid,mm),v in groups.items() if mm==m and int(v[0]['branches'])==branch]
  row[m+'_checks']=float(np.mean([np.mean([float(x['solver_checks']) for x in v]) for v in qq]));row[m+'_ms']=float(np.mean([np.mean([float(x['runtime_seconds'])*1000 for x in v]) for v in qq]))
 strata.append(row)
with (REPORT/'family_size_analysis.csv').open('w') as f:w=csv.DictWriter(f,list(strata[0]));w.writeheader();w.writerows(strata)
fig,axs=plt.subplots(1,2,figsize=(9,3.3),layout='constrained')
for ax,metric,title in zip(axs,['checks','ms'],['(a) Mean calls/question','(b) Mean time (ms/question)']):
 for m,lab,col in [('incremental_early_stop','Incremental stop',G),('interval_gate','Must/may + fallback',C)]:ax.plot(range(5),[x[m+'_'+metric] for x in strata],marker='o',label=lab,color=col)
 ax.set_xticks(range(5),[str(x['branches'])+'\n(n='+str(x['questions'])+')' for x in strata]);ax.set_xlabel('Retained interpretations per question');ax.set_ylabel(title);ax.grid(alpha=.15);ax.legend(fontsize=8)
save(fig,'family_size')
by={(x['id'],x['budget']):x for x in t};trans=Counter((x['accepted'],by[x['id'],'2']['accepted']) for x in t if x['budget']=='0');annotations=Counter(int(x['annotations']) for x in t if x['budget']=='2')
assert trans=={('1','1'):290,('0','0'):277,('0','1'):33};assert sum(k*v for k,v in annotations.items())==605
fig,axs=plt.subplots(1,2,figsize=(9,3.3),layout='constrained')
for i,budget in enumerate(['0','2']):
 sel=[x for x in t if x['budget']==budget];nc=sum(int(x['accepted']) for x in sel);axs[0].bar(i,nc,color=C);axs[0].bar(i,600-nc,bottom=nc,color='#d7dde0');axs[0].text(i,nc/2,str(nc)+' certified',ha='center',va='center',color='white');axs[0].text(i,nc+(600-nc)/2,str(600-nc)+' uncertified',ha='center',va='center',fontsize=9)
axs[0].set_xticks([0,1],['No corrections','Up to two']);axs[0].set_ylabel('Questions (n = 600)');axs[0].set_title('(a) Family-certificate coverage')
axs[1].bar([0,1,2],[annotations[i] for i in [0,1,2]],color=[G,O,O]);axs[1].set_xticks([0,1,2]);axs[1].set_xlabel('Semantic corrections requested per question');axs[1].set_ylabel('Questions');axs[1].set_title('(b) Observed annotation cost')
for i in [0,1,2]:axs[1].text(i,annotations[i]+4,str(annotations[i]),ha='center')
axs[1].set_ylim(0,335);save(fig,'text_coverage_cost')
out={'analysis_id':'NS-MANUSCRIPT-REANALYSIS-019','kind':'post-hoc descriptive analysis of existing outputs','new_performance_runs':0,'formal_paths':dict(counts),'ambiguous_questions':len(amb),'direct_bound_certificates':len(amb)-counts['exact_fallback'],'direct_bound_fraction_ambiguous':(len(amb)-counts['exact_fallback'])/len(amb),'text_transitions':{'remain_certified':290,'gain_certificate':33,'lose_certificate':0,'remain_uncertified':277},'annotation_histogram':dict(annotations),'annotations_per_added_certificate':605/33,'input_sha256':{s:hashlib.sha256((ROOT/s).read_bytes()).hexdigest() for s in paths},'figures':{'primary_efficiency':'NS-FOL-INTERVAL-015: all five controls, separate calls and time','uncertainty':'NS-015/016: existing paired-cluster bootstrap; comparator differs by regime','certificate_paths':'NS-015: rep0 decision paths; no duplicate timing repetitions','family_size':'NS-015: post-hoc observational strata, no uncertainty or causal scalability claim','text_coverage_cost':'NS-TEXT-CERT-017: all600 records and actual request counts'}}
(REPORT/'descriptive_analysis.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
