"""Fresh-world pilot: restrict every terminal answer to one executable program.

This is an action-space ablation of classical VOI, not a novelty claim.
Monkeypatches are confined to this separate process; original run is unchanged.
"""
import csv,itertools,json,time
from pathlib import Path
import numpy as np
import search_recovered as s

ORIGINAL_DECIDE=s.decide
ORIGINAL_SCORES=s.scores

def prepare(b):
    acts,indices=np.unique(b['pred'],axis=0,return_index=True)
    coeff=np.zeros((len(acts),3,32));ix=np.arange(32);source=b['pred'][0]
    for i,a in enumerate(acts):
        coeff[i,a,ix]-=1
        coeff[i,source,ix]+=.5*(a!=source)
    b['actions']=acts;b['action_indices']=indices;b['coeff']=coeff.reshape(len(acts),96)/32
    # Reconstruct the retained representative program for execution/proof replay.
    programs=[];seen=set();w=b['w']
    clauses=[x for n in (1,2) for x in itertools.combinations(range(5),n)]
    for rs in w.programs:
        for cl in [None]+clauses:
            rr=rs if cl is None else rs+(s.d.Rule('new_clause',tuple(f'p{i}' for i in cl),'approve'),)
            tab=tuple(s.d.evaluate(x,w.mappings[0],rr) for x in w.contexts)
            if tab not in seen:seen.add(tab);programs.append(rr)
    b['canonical_programs']=programs;b['all_maps']=list(itertools.permutations(range(5)))
    assert len(programs)*120==len(b['pred'])
    return b

def program_decide(b,p):
    risk=1+b['coeff']@(b['onehot']@p)
    k=int(risk.argmin());return b['actions'][k],float(risk[k])

def program_scores(b,p,pn,noise,method,obs,lk):
    if method!='predictive_risk':return ORIGINAL_SCORES(b,p,pn,noise,method,obs,lk)
    joint=lk*p;prob=joint.sum(axis=2)
    mar=b['onehot']@joint.reshape(-1,len(p)).T
    risks=prob.reshape(-1)[None,:]+b['coeff']@mar
    return program_decide(b,p)[1]-risks.min(axis=0).reshape(prob.shape).sum(axis=1)

def replay(b,z):
    # Select a bank witness, execute its actual rules, then replay cited supports.
    hid=int(np.flatnonzero(np.all(b['pred']==z,axis=1))[0]);n=len(b['canonical_programs'])
    m=b['all_maps'][hid//n];rs=b['canonical_programs'][hid%n]
    counts={'predictions_checked':0,'positive_or_negative_proofs':0,'support_replays':0,'invalid':0,'unknown':0}
    for x,label in zip(b['w'].contexts,z):
        facts=s.d.facts(x,m);known=s.d.closure(facts,rs)
        counts['predictions_checked']+=1
        if s.d.signed_label(known)!=label:counts['invalid']+=1
        if label==2:counts['unknown']+=1;continue
        atom='approve' if label==0 else '!approve';supports=s.d.proof_supports(facts,rs).get(atom,set())
        if not supports:counts['invalid']+=1;continue
        counts['positive_or_negative_proofs']+=1
        support=min(supports,key=lambda v:(len(v),sorted(v)))
        ff={v[5:] for v in support if v.startswith('fact:')};rr=tuple(r for r in rs if 'rule:'+r.name in support)
        counts['support_replays']+=1
        if atom not in s.d.closure(ff,rr):counts['invalid']+=1
    return counts

def main():
    cfg=json.loads(Path('configs/program_action_pilot.json').read_text());out=Path('results/program_action_pilot');out.mkdir(exist_ok=False)
    start=time.time();rows=[];audits=[]
    with (out/'traces.jsonl').open('w') as f:
        for seed in cfg['seeds']:
            b=prepare(s.bank(seed))
            for case,noise,mode,policy in itertools.product(s.CASES,[0.,.1],['point','program'],['wide_entropy','predictive_risk']):
                s.decide=program_decide if mode=='program' else ORIGINAL_DECIDE
                s.scores=program_scores if mode=='program' else ORIGINAL_SCORES
                row,trace=s.episode(b,case,noise,policy);row['method']=mode+'_'+policy;rows.append(row)
                f.write(json.dumps({'metrics':row,'queries':trace})+'\n');f.flush()
                if mode=='program':
                    p=b['prior'].copy()
                    for q,o in trace:
                        k=5 if b['w'].queries[q][0]=='anchor' else 3
                        p*=np.where(b['resp'][:,q]==o,1-noise,noise/(k-1))
                        if p.sum()<1e-200:break
                        p/=p.sum()
                    z=b['pred'][0] if p.sum()<1e-200 else program_decide(b,p)[0]
                    audits.append(dict(seed=seed,case=case,noise=noise,policy=policy,**replay(b,z)))
            print(f'program pilot seed={seed} rows={len(rows)}',flush=True)
    with (out/'episodes.csv').open('w') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    (out/'proof_replay.json').write_text(json.dumps(audits,indent=2))
    summary={}
    for m in sorted(set(r['method'] for r in rows)):
        rr=[r for r in rows if r['method']==m and r['case'] in s.CASES[4:6]]
        summary[m]={k:float(np.mean([r[k] for r in rr])) for k in ['accuracy','weighted_loss','damage']}
    counts={k:sum(r[k] for r in audits) for k in ['predictions_checked','positive_or_negative_proofs','support_replays','invalid','unknown']}
    result=dict(summary=summary,proof_checks=counts,seconds=time.time()-start,code_sha=s.sha(__file__),scope=cfg['scope'])
    (out/'summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))

if __name__=='__main__':main()
