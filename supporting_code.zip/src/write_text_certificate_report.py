import json,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
 s=json.loads((ROOT/'results/text_certificate_v1/summary.json').read_text());a,b=s['budgets']['0'],s['budgets']['2']
 report=f'''# اتصال ورودی متنی به هستهٔ گواهی استدلال

تاریخ: ۲۰۲۶-۱۰-۲۹ — مرحلهٔ NS-TEXT-CERT-017

طبق تصمیم ادامهٔ پروژه، معماری جدیدی جست‌وجو نشد. مدل عصبی ذخیره‌شده و قرارداد گواهیِ تفسیر مرحلهٔ قبل ثابت ماندند. اتصال عملی متن، تولید برنامه‌های کاندید، بررسی گواهی و نمایش توضیح اجرا شد.

## کاری که انجام شد

۱. مدل MLP قبلی، از متن انگلیسی کنترل‌شده تا سه برداشت برای هر جمله تولید می‌کند؛ حداکثر ۱۶ برنامهٔ کامل نگه داشته می‌شود. هیچ فرمول مرجعی به تولید کاندید یا صدور گواهی داده نمی‌شود.

۲. یک آداپتور Horn همان قرارداد کران پایین/بالا را برای خانوادهٔ برنامه‌ها اجرا می‌کند: قواعد مشترک و اجتماع قواعد، حدود استنتاج را تعیین می‌کنند. اگر کران‌ها کافی نباشند، خانوادهٔ نگه‌داشته‌شده دقیق اجرا می‌شود. این تخصصی‌سازی، کد و نتیجهٔ موتور عمومی FOL مرحلهٔ قبل را تغییر نمی‌دهد.

۳. برای جلوگیری از خطای تغییر معنای نفی، گزارهٔ مثبت و منفی در ترجمه به FOL دو محمول مستقل‌اند. بنابراین استنتاج عکس نقیضِ کلاسیک به‌اشتباه به معنای قواعد قبلی اضافه نمی‌شود. تبدیل برنامهٔ منتخب برای هر ۶۰۰ پرسش با موتور FOL موجود کنترل شد؛ هیچ اختلافی نبود.

۴. ابزار قابل اجرا اکنون «پاسخ برنامهٔ منتخب»، «وضعیت گواهی خانواده» و «اثبات برنامهٔ منتخب» را جداگانه نشان می‌دهد. نداشتن گواهی خانواده به‌صورت منطقی با نامعین بودن پاسخ یکی نیست و پاسخ مدل را پنهان نمی‌کند. اثبات برنامهٔ منتخب، اثبات مشترک همهٔ تفسیرها معرفی نمی‌شود.

## نتیجهٔ آزمایش محدود

همان ۶۰۰ پرسش قبلی از ۴۵۷ متن متمایز استفاده شد؛ این مرحله آزمون اتصال اجزاست، نه مجموعهٔ آزمون مستقل تازه.

| حالت | پاسخ‌های دارای گواهی | پوشش گواهی | صحیح میان پاسخ‌های گواهی‌شده | تعداد حاشیه‌نویسی معنایی |
|---|---:|---:|---:|---:|
| بدون اصلاح معنایی | {a['accepted']} از ۶۰۰ | {100*a['coverage']:.2f}٪ | {100*a['accepted_accuracy']:.0f}٪ | {a['semantic_annotations']} |
| حداکثر دو اصلاح هنگام نبود گواهی | {b['accepted']} از ۶۰۰ | {100*b['coverage']:.2f}٪ | {100*b['accepted_accuracy']:.0f}٪ | {b['semantic_annotations']} |

پاسخِ برنامهٔ نخستِ مدل در همین دادهٔ قبلاً استفاده‌شده، در هر دو حالت ۶۰۰/۶۰۰ صحیح است. بنابراین افزایش دقت نسبت به این خط پایه ادعا نمی‌کنیم. افزایش پوشش گواهی ۵٫۵ واحد درصد است و هزینهٔ ۶۰۵ حاشیه‌نویسی شبیه‌سازی‌شده دارد؛ این ارزیابی انسانی نیست. اگر خودداری از پاسخ را خطا حساب کنیم، دقتِ مسیر فقط-گواهی به‌ترتیب ۴۸٫۳۳٪ و ۵۳٫۸۳٪ است؛ عدد ۱۰۰٪ جدول فقط دقت پاسخ‌های پذیرفته‌شده است.

مدل و آستانه‌ها برای بهتر شدن این جدول بازتنظیم نشدند. گزینه‌های کم‌احتمالِ باقی‌مانده می‌توانند گواهی را محافظه‌کارانه محدود کنند. قصد معنایی مرجع در ۵۸۹ خانوادهٔ اولیه و ۵۹۱ خانوادهٔ پس از اصلاح وجود داشت؛ بنابراین گواهیِ درون خانواده، تضمین قطعی فهم منظور متن نیست.

تمام ۱۲۰۰ خروجیِ خانواده با اجرای دقیق کنترل شدند. ۶۰۰ ترجمهٔ برنامه به FOL و ۲۳۸ بررسی اثبات در دو پیکربندی گذشتند. مجموعهٔ آزمون‌ها اکنون ۷۶ مورد است. تمام اجراها CPU بودند.

## استفاده

```bash
OPENBLAS_NUM_THREADS=1 python3 src/predict_text_certificate.py \\
  --context-file results/text_certificate_v1/demo_context.txt \\
  --statement 'Bob is blue'
```

متن نمونه: `Bob is red. If someone is red then they are blue.` خروجی ابزار شامل پاسخ، وضعیت گواهی و مراحل استنتاج با ارجاع به جملهٔ ورودی است.

برای بازتولید:

```bash
OPENBLAS_NUM_THREADS=1 python3 src/evaluate_text_certificate.py
PYTHONPATH=src OPENBLAS_NUM_THREADS=1 python3 -m unittest discover -s tests -v
python3 src/write_text_certificate_report.py
```

برای بازتولید تمام مراحل مقاله، پس از نویسنده‌های گزارش‌های تاریخی، این نویسنده را آخر اجرا کنید. داده و وابستگی‌ها همان بستهٔ قبلی‌اند و آموزش یا GPU تازه لازم نیست.

## تصمیم این مرحله

اتصال عملی متن کامل شد. بهبود ۴۱٫۴٪ فراخوانی حل‌گر مربوط به آزمایش FOL مرحلهٔ قبل باقی می‌ماند و به این آزمایش متنی نسبت داده نمی‌شود. محدودیت پوشش گواهی و انگلیسی کنترل‌شده در مقاله ثبت شده‌اند؛ به‌خاطر این محدودیت‌ها وارد چرخهٔ تغییر روش یا افزودن خط پایه‌های تازه نشدیم.

## ترمیم بستهٔ قبلی

نسخهٔ ذخیره‌شدهٔ پیشین در آخرین عضو ZIP ناتمام بود. ۵۲۹ عضو کامل با CRC بازیابی شدند؛ تنها فایل دادهٔ ناتمام از نسخهٔ قبلی با SHA256 کاملاً یکسان جایگزین شد. تمام ۴۷۱ فایل فهرست قبلی با هش کنترل شدند و هیچ اختلافی نبود. کد و نتایج مرحلهٔ قبل از دست نرفته‌اند. جزئیات در `reports/ARCHIVE_RECOVERY.json` ثبت شده است.
'''
 (ROOT/'reports/TEXT_CERTIFICATE_INTEGRATION_FA.md').write_text(report)
 before=ROOT/'history/pre_text_certificate_PILOT_MANUSCRIPT.md'
 if not before.exists():shutil.copy2(ROOT/'manuscript/PILOT_MANUSCRIPT.md',before)
 p=before.read_text()
 methods='''### 3.6 Frozen neural-text integration

The existing MLP and typed decoder now supply up to three sentence interpretations and a 16-program beam directly from controlled English. A signed-Horn adapter instantiates the same must/may certification contract using intersection/union clause bounds and exact retained-family fallback. Positive and negative predicates remain independent, preserving the original explicit-negation semantics. Every selected initial program is also exported to equality-free definite FOL and checked by the existing general FOL engine. The original FOL certificate implementation and efficiency numbers are unchanged.

The user-facing interface reports the selected-program answer and its executed proof alongside a separate interpretation-family certificate status. A missing family certificate does not suppress the model answer or masquerade as logical uncertainty. The proof belongs to the selected program, not necessarily to every interpretation. Semantic annotations are requested only when no family certificate exists, with at most two least-confidence sentence corrections. The annotator supplies sentence meanings, never task labels, and is simulated by the existing grammar rather than a human.

'''
 p=p.replace('## 4. Data and evaluation',methods+'## 4. Data and evaluation',1)
 results='''### 5.2 Text-to-certificate integration check

The frozen integration is evaluated on the same previously used 600 ProofWriter questions, covering 457 unique contexts. All 600 selected-program signed-Horn/FOL translations agree, and all 1,200 family decisions match exact retained-program evaluation. Without semantic corrections, 290/600 questions receive a family certificate; with up to two corrections, 323/600 do. Accepted-answer accuracy is 100% in both settings, but coverage is only 48.33% and 53.83%; abstention-counted accuracies equal these values. The second configuration consumes 605 simulated semantic annotations to gain 33 certificates. The selected first-program answer is already correct for all 600 examples, so this integration does not demonstrate an accuracy improvement over that baseline. It adds a separately inspectable certificate status.

The reference program is present in 589 initial beams and 591 corrected beams. Thus family completeness and intended-meaning coverage are not guaranteed. Low-probability interpretations retained in the beam can reduce certification coverage; neither weights nor thresholds are retuned to raise the reported numbers. Across the two configurations, 238 positive/negative proof checks pass. The full implementation suite has 76 passing tests. This is an exploratory component integration, not an independent NLU confirmation dataset or an unrestricted FOL semantic parser.

'''
 p=p.replace('## 6. Explanation analysis',results+'## 6. Explanation analysis',1)
 (ROOT/'manuscript/PILOT_MANUSCRIPT.md').write_text(p)
 print('Text integration report and manuscript updated.')
if __name__=='__main__':main()
