"""Post-hoc depth diagnostic; does not replace the primary full-test result."""
import json,numpy as np
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
 p=ROOT/'results/external_kinship_v1';rr=[json.loads(l) for seed in [42,43,44] for l in (p/f'predictions_{seed}.jsonl').read_text().splitlines()];out={}
 for group,pred in [('matched_2_3',lambda r:r['hops']<=3),('longer_4_10',lambda r:r['hops']>=4)]:
  ids=sorted({r['id'] for r in rr if pred(r)});sub=[r for r in rr if pred(r)];res={}
  for m in sorted({r['method'] for r in sub}):
   a=[r for r in sub if r['method']==m];res[m]={'n_decisions':len(a),'accuracy':sum(x['prediction']==x['gold'] for x in a)/len(a),'annotations':sum(x['annotations'] for x in a)}
  by={(r['id'],r['seed'],r['method']):r for r in sub};rng=np.random.default_rng(20021);idx=rng.integers(len(ids),size=(10000,len(ids)));cs=[]
  for a,b in [('bundle_0','direct_logistic'),('bundle_unc2','direct_logistic'),('bundle_unc2','bundle_rand2')]:
   dif=np.array([np.mean([int(by[id,sd,a]['prediction']==by[id,sd,a]['gold'])-int(by[id,sd,b]['prediction']==by[id,sd,b]['gold']) for sd in [42,43,44]]) for id in ids]);cs.append({'method':a,'control':b,'accuracy_difference_pp':float(dif.mean()*100),'ci95':list(np.quantile(dif[idx].mean(axis=1)*100,[.025,.975]))})
  out[group]={'questions':len(ids),'methods':res,'comparisons':cs}
 out['status']='Post-hoc diagnostic stratification by known training lengths2-3; full test remains primary; not an independently confirmed positive test.';(ROOT/'reports/external_transfer_v1/length_diagnostic.json').write_text(json.dumps(out,indent=2))
if __name__=='__main__':main()
