"""Frozen external-study summary, paired question-cluster uncertainty and plots."""
import json,csv,hashlib,os
from pathlib import Path
from collections import Counter,defaultdict
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1];R=ROOT/'results/external_kinship_v1';D=ROOT/'reports/external_transfer_v1';F=ROOT/'manuscript/review_version/figures'

def main():
 s=json.loads((R/'summary.json').read_text());data=[json.loads(l) for seed in [42,43,44] for l in (R/f'predictions_{seed}.jsonl').read_text().splitlines()];methods=s['methods'];ids=sorted({r['id'] for r in data});by={(r['id'],r['seed'],r['method']):r for r in data};rng=np.random.default_rng(20020);idx=rng.integers(len(ids),size=(10000,len(ids)))
 def arr(method,metric='correct'):
  return np.array([np.mean([(by[i,seed,method]['prediction']==by[i,seed,method]['gold']) if metric=='correct' else by[i,seed,method]['annotations'] for seed in [42,43,44]]) for i in ids])
 comparisons=[]
 for a,b in [('bundle_0','direct_logistic'),('bundle_0','validation_selected_control'),('bundle_0','greedy_gate_0'),('bundle_unc2','bundle_rand2'),('bundle_unc2','bundle_0'),('bundle_unc2','ungated_always2')]:
  diff=arr(a)-arr(b);boot=diff[idx].mean(axis=1)*100;comparisons.append({'method':a,'control':b,'endpoint':'accuracy_pp','estimate':float(diff.mean()*100),'ci95':list(np.quantile(boot,[.025,.975])),'independent_units':len(ids),'seeds_averaged_within_question':3})
 diff=arr('ungated_always2','annotations')-arr('bundle_unc2','annotations');boot=diff[idx].mean(axis=1);comparisons.append({'method':'bundle_unc2','control':'ungated_always2','endpoint':'saved_annotations_per_question','estimate':float(diff.mean()),'ci95':list(np.quantile(boot,[.025,.975])),'independent_units':len(ids)})
 hops=sorted({r['hops'] for r in data});hoprows=[]
 for hop in hops:
  for m in ['direct_logistic','bundle_0','bundle_unc2','bundle_rand2']:
   rr=[r for r in data if r['hops']==hop and r['method']==m];hoprows.append({'hops':hop,'method':m,'questions':len({r['id'] for r in rr}),'seed_question_decisions':len(rr),'accuracy':sum(r['prediction']==r['gold'] for r in rr)/len(rr)})
 with (D/'by_hop.csv').open('w') as f:w=csv.DictWriter(f,list(hoprows[0]));w.writeheader();w.writerows(hoprows)
 (D/'paired_statistics.json').write_text(json.dumps({'bootstrap_samples':10000,'seed':20020,'unit':'heldout story/question; average3seeds before resampling','comparisons':comparisons,'caveat':'Exploratory benchmark estimate; normalized full-story templates excluded but constituent phrases may overlap; no multiple-testing significance claims.'},indent=2))
 plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'savefig.bbox':'tight'});F.mkdir(exist_ok=True)
 ms=['direct_logistic','nearest_prototype','no_composition','greedy_gate_0','bundle_0','bundle_unc2','bundle_rand2'];labels=['Direct logistic','Nearest prototype','No composition','Strict greedy gate','Coherent bundle','Bundle + uncertainty (2)','Bundle + random (2)'];fig,axs=plt.subplots(1,2,figsize=(10,4),layout='constrained')
 vals=[methods[m]['accuracy']*100 for m in ms];axs[0].barh(labels,vals,color=['#81919b']*3+['#c87936','#176b87','#176b87','#81919b']);axs[0].invert_yaxis();axs[0].set_xlim(0,max(vals)*1.25);axs[0].set_xlabel('Preferred-answer accuracy (%)')
 for i,v in enumerate(vals):axs[0].text(v+.3,i,f'{v:.2f}',va='center',fontsize=9)
 for m,label,col in [('bundle_unc2','Certificate-triggered','#176b87'),('ungated_always2','Always two','#c87936')]:axs[1].scatter(methods[m]['annotations']/methods[m]['n'],methods[m]['accuracy']*100,s=65,label=label,color=col)
 axs[1].set_xlabel('Mean simulated corrections/question');axs[1].set_ylabel('Preferred-answer accuracy (%)');axs[1].set_xlim(0,2.2);axs[1].set_ylim(0,15);axs[1].legend(fontsize=8,loc='upper left');axs[1].annotate('1.91 corrections; 8.18%',xy=(1.914,8.178),xytext=(.2,5),arrowprops={'arrowstyle':'-','color':'#81919b'},fontsize=8);axs[1].annotate('2.00 corrections; 8.33%',xy=(2.,8.326),xytext=(.2,10),arrowprops={'arrowstyle':'-','color':'#81919b'},fontsize=8);axs[1].grid(alpha=.2)
 fig.savefig(F/'external_accuracy_cost.pdf.partial',format='pdf');os.replace(F/'external_accuracy_cost.pdf.partial',F/'external_accuracy_cost.pdf');fig.savefig(F/'external_accuracy_cost.png',dpi=180);plt.close(fig)
 fig,ax=plt.subplots(figsize=(8,3.5),layout='constrained')
 for m,label,col in [('direct_logistic','Direct logistic','#81919b'),('bundle_0','Bundle, no correction','#c87936'),('bundle_unc2','Bundle, uncertainty (2)','#176b87'),('bundle_rand2','Bundle, random (2)','#72996c')]:
  rr=[r for r in hoprows if r['method']==m];ax.plot([r['hops'] for r in rr],[r['accuracy']*100 for r in rr],marker='o',label=label,color=col)
 counts=[next(r['questions'] for r in hoprows if r['hops']==h) for h in hops];ax.set_xticks(hops,[str(h)+'\n(n='+str(n)+')' for h,n in zip(hops,counts)]);ax.set_ylabel('Preferred-answer accuracy (%)');ax.set_xlabel('Published reasoning length');ax.legend(fontsize=8,ncol=2);ax.grid(alpha=.15);fig.savefig(F/'external_hops.pdf.partial',format='pdf');os.replace(F/'external_hops.pdf.partial',F/'external_hops.pdf');fig.savefig(F/'external_hops.png',dpi=180);plt.close(fig)
 stats={}
 for seed in [42,43,44]:stats[str(seed)]=json.loads((R/f'extraction_{seed}.json').read_text())
 denom=sum(v['extraction_predicted'] for v in stats.values());ref=sum(v['extraction_reference'] for v in stats.values());tp=sum(v['extraction_tp'] for v in stats.values());(D/'grounding_audit.json').write_text(json.dumps({'true_positive':tp,'predicted':denom,'reference':ref,'precision':tp/denom if denom else None,'recall':tp/ref if ref else None,'scope':'directly asserted reference proof-leaf pairs; postprediction audit; annotation imperfections possible'},indent=2))
 print(json.dumps({'comparisons':comparisons,'grounder_precision':tp/denom,'grounder_recall':tp/ref,'hops':Counter({str(h):n for h,n in zip(hops,counts)})},indent=2))
if __name__=='__main__':main()
