"""Freeze development choice; paired world analysis, never episode bootstrap."""
import argparse, csv, hashlib, json
from pathlib import Path
import numpy as np
from search_recovered import CANDIDATES, METHODS, CASES

def read(path):
    rows=list(csv.DictReader((Path(path)/'episodes.csv').open()))
    for r in rows:
        for k in r:
            if k not in ('method','case'):r[k]=float(r[k])
    return rows
def mean(rows,key):return float(np.mean([r[key] for r in rows]))
def analyze(path,stage,cfg,selection):
    p=Path(path);rows=read(p)
    summary=[]
    for m in dict.fromkeys(r['method'] for r in rows):
        for case in CASES:
            for noise in (0.,.1):
                rs=[r for r in rows if r['method']==m and r['case']==case and r['noise']==noise]
                summary.append(dict(method=m,case=case,noise=noise,**{k:mean(rs,k) for k in ('accuracy','weighted_loss','damage','source_accuracy','empty_bank','certificate_coverage','order_violation','wide_contains_truth')},certificate_errors=sum(r['certificate_errors'] for r in rs),certificate_covered=sum(r['certificate_covered'] for r in rs)))
    (p/'summary.json').write_text(json.dumps(summary,indent=2))
    if stage=='development':
        ranks=[dict(method=m,loss=mean([r for r in rows if r['method']==m and r['case'] in CASES[4:6]],'weighted_loss')) for m in CANDIDATES]
        ranks.sort(key=lambda r:(r['loss'],CANDIDATES.index(r['method'])))
        out=dict(selected=ranks[0]['method'],rankings=ranks,frozen=True,development_csv_sha256=hashlib.sha256((p/'episodes.csv').read_bytes()).hexdigest(),rule=cfg['selection'])
        target=p/'selection.json'
        if target.exists():raise RuntimeError('Refuse selection overwrite')
        target.write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2));return
    selected=json.loads(Path(selection).read_text())['selected'];seeds=cfg['confirmation_seeds'];comparisons=[]
    rng=np.random.default_rng(cfg['bootstrap_seed']);ix=rng.integers(0,len(seeds),size=(cfg['bootstrap_replicates'],len(seeds)))
    def paired(method,cases,noise=None):
        return np.array([mean([r for r in rows if r['seed']==s and r['method']==selected and r['case'] in cases and (noise is None or r['noise']==noise)],'accuracy')-mean([r for r in rows if r['seed']==s and r['method']==method and r['case'] in cases and (noise is None or r['noise']==noise)],'accuracy') for s in seeds])
    for m in ('wide_entropy','wide_ec2'):
        v=paired(m,CASES[4:6]);ci=np.quantile(v[ix].mean(axis=1),[.0125,.9875]);retain=float(paired(m,CASES[:4],0.).mean())
        comparisons.append(dict(comparator=m,gain=float(v.mean()),bonferroni_95_ci=list(map(float,ci)),clean_original_gain=retain,passes=bool(v.mean()>=.02 and ci[0]>0 and retain>=-.01)))
    out=dict(selected=selected,primary_pass=all(x['passes'] for x in comparisons),comparisons=comparisons,worlds=len(seeds),episodes=len(rows),bootstrap_unit='world',selection_sha256=hashlib.sha256(Path(selection).read_bytes()).hexdigest())
    (p/'decision.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);ap.add_argument('--stage',required=True);ap.add_argument('--config',required=True);ap.add_argument('--selection');a=ap.parse_args();analyze(a.out,a.stage,json.loads(Path(a.config).read_text()),a.selection)
