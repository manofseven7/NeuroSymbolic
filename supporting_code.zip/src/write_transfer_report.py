"""Consolidate successes,failed extensions and a factual pilot manuscript."""
import json,csv
from pathlib import Path
from analyze_transfer import aggregate,summaries,compare,load

def main():
    p=Path('results/transfer_v1');r=json.loads((p/'summary.json').read_text());raw=json.loads(Path('results/fulltext_transfer_v1/summary.json').read_text());v=json.loads(Path('results/fulltext_transfer_v1/verification.json').read_text());symbolic=json.loads(Path('results/fulltext_transfer_v1/symbolic_query_ablation.json').read_text());data=json.loads((p/'data_audit.json').read_text());proof=json.loads((p/'audit/proof_status_summary.json').read_text())
    committee=aggregate(load('results/transfer_committee_v1/episodes.csv'));co=dict(summary=summaries(committee),comparisons=[compare(committee,('adapted','neural_disagreement',2),b) for b in [('lexical','random',2),('lexical','none',0),('adapted','neural_entropy',2)]])
    Path('results/transfer_committee_v1/summary.json').write_text(json.dumps(co,indent=2))
    lines=['# نتیجه یکپارچه انتقال، آزمون‌های کنترل و اجرای متن خام','',
    'این مرحله تا پایانِ اجرای آزمون انتقال، بررسی کنترل قوی‌تر، آزمون تازه، بازاجرای متن خام و تهیه پیش‌نویس یکپارچه مقاله ادامه یافت. عنوان و هدف اصلی پروژه حفظ شده‌اند. آستانه قدیمی ۲ واحد درصد شرط ادامه نیست و شکست‌های قبلی از تاریخچه حذف نشده‌اند.','',
    '## نتیجه اصلیِ عملی','',
    '**مسیر متن خام ParaRules تا برنامه و پاسخ اجرا شد:** ۸٬۰۰۸ پرسش از ۴۸۲ نظریه، با دقت ۱۰۰٪. مجموعه حقایق و قواعد استخراج‌شده و تفسیر پرسش‌ها، در این آزمون با منطق مرجع داده تطابق کامل داشتند. حقایق طلایی، معنای طلایی پرسش و تعداد یا مرز طلایی قواعد به پیش‌بین داده نشد.','',
    'این نتیجه مربوط به یک روش پایه ساده و قابل بازرسی است: واژگان ویژگی‌ها از داده منبع، نام‌ها از فراوانی واژه‌های بزرگ‌نویسی‌شده در متنِ بدون برچسبِ آموزش مقصد، استخراج گروه حقایق از نام‌ها/ضمیرها، و یک قاعده ترتیب واژگان برای تفسیر قواعد. مبدل عصبی ثابت، پرسش‌های قالبی را تفسیر می‌کند. **کنترل با تفسیر کاملاً نمادین پرسش نیز ۱۰۰٪ گرفت**؛ بنابراین ضرورت یا برتری بخش عصبی از این نتیجه اثبات نمی‌شود.','',
    'این یک نتیجه اکتشافی پس از مشاهده نتایج جزءبه‌جزء همان معیار است؛ پیش از نخستین اجرای کامل متن خام، دستور اجرای آن ثابت شد و پس از مشاهده خروجی کامل تنظیم نشد. آن را ارزیابی بیرونی مستقل یا اثبات فهم عمومی زبان نمی‌نامیم.','',
    '| سنجه روی متن خام آزمون | نتیجه |','|---|---:|',
    '| نظریه‌ها / پرسش‌ها | ۴۸۲ / ۸٬۰۰۸ |','| دقت پاسخ | ۱۰۰٪ |','| توافق مجموعه کامل برنامه با منطق مرجع | ۱۰۰٪ |','| توافق تفسیر پرسش با مرجع | ۱۰۰٪ |','| گواه‌های استنتاجِ یک گزاره مثبت | ۴٬۰۰۴؛ بدون گام نامعتبر |','| گواه‌های عدم‌استنتاج با بسته‌بودن نقطه ثابت | ۴٬۰۰۴؛ بدون گواه نامعتبر |','',
    'این مجموعه معنای دودویی و جهان‌بسته دارد. در نیمی از موارد، یک گزاره مثبت یا نقیض پرسشِ منفی واقعاً استنتاج می‌شود؛ در موارد عدم‌استنتاج، پاسخ جهان‌بسته بر اساس نبود گزاره در بستار است و شاهد مثبت برای نفی جعل نمی‌شود. گواه بسته‌بودن، مشتق‌شدن اعضای بستار، حضور مقدمات و بسته‌بودن تحت همه نمونه‌های قواعد را کنترل می‌کند. این تضمین نسبت به برنامه محدود استخراج‌شده است، نه منطق مرتبه اول عمومی یا تأیید انسانی معنا.','',
    '## چرا نتیجه فقط یک معماری پیچیده‌تر نیست؟','',
    'کنترل‌های قوی‌تر را اضافه کردیم، حتی وقتی به نفع نسخه پیشنهادی نبودند. این ترتیب، نتایج قبلی را بازنویسی نمی‌کند:','',
    '| آزمایش | نتیجه و تفسیر |','|---|---|',
    '| انتقال کم‌نمونه تفسیر قواعد | با ۶۴ برچسب آموزش و ۳۲ اعتبارسنجی، آموزش به‌تنهایی دقت پاسخ را بهتر نکرد. |',
    '| اصلاح فعال، همان مدل و بودجه | دو برچسب معنایی برای هر نظریه: عدم‌قطعیت ۹۸٫۹۶٪، تصادفی ۹۷٫۲۵٪. |',
    '| کنترل ترتیب واژه | آخرین ویژگی به‌عنوان نتیجه قاعده: ۹۹٫۰۴٪؛ بهتر از نسخه قبلی با شاهد اضافی. |',
    '| طراحی بعدی روی ۹۳۷ نظریه کنارگذاشته‌شده | ۱۵٬۶۲۴ پرسش؛ همه سیاست‌ها ۹۹٫۱۲٪ گرفتند. ترکیب عصبیِ جدید سود اضافه نداشت. |',
    '| مسیر متن خام | با اصلاح رابط و استخراج مستقیم گروه‌های حقیقت/قاعده، تمام متن خام به‌درستی بازیابی شد. |','',
    'یافته قابل دفاع این است که **رابط تفسیر متن و کنترل‌های ساختاری قوی، در این معیار مهم‌تر از افزودن انتخاب‌گر عصبی پیچیده‌تر بودند**. این را به نوآوری اثبات‌شده الگوریتمی تبدیل نمی‌کنیم. برای متن خام، واژگان بسته، نظریه‌های مثبت و ترتیب حقایق پیش از قواعد، فرض‌های مؤثر روش هستند.','',
    '## جزئیات آزمون انتقال جزءبه‌جزء','',
    'داده مقصد، قسمت NatLang/ParaRules از انتشار رسمی RuleTaker است: ۱٬۶۸۱ نظریه آموزش، ۲۴۰ توسعه و ۴۸۲ آزمون. در این زیرآزمایش، حقایق و معنای پرسش و رابط تقریبی واحدهای قاعده برای همه روش‌ها یکسان و آماده بودند. پس این بخش، آزمایش کامل متن آزاد نبود. ۶۴ تفسیر قاعده برای یادگیری و ۳۲ برای انتخاب تعداد به‌روزرسانی، با هش متن و بدون توجه به دقت آزمون انتخاب شدند. متن هیچ‌یک از این ۹۶ واحد عیناً در آزمون نبود.','',
    'هم‌ترازی واحدهای پیشنهادی با منطق مرجع، با نشانه‌های واژگانی ممیزی شد: ۲٬۹۰۵ واحد از ۲٬۹۷۱ واحد آزمون قابل هم‌ترازی بود؛ ۲۶ نظریه کاملاً هم‌تراز نبودند. هیچ‌یک از ۴۸۲ نظریه از نمره اصلی حذف نشد؛ درخواست برچسب ناموجود نیز بودجه مصرف کرد. این ممیزی از برچسب‌های رسمی مجموعه استفاده کرده است؛ شمار ۶۴+۳۲ معادل هزینه واقعی جمع‌آوری و غربال انسانی همه داده نیست.','',
    '| مدلِ همان رابط جزءبه‌جزء | بدون اصلاح | تصادفی، بودجه ۲ | عدم‌قطعیت، بودجه ۲ |','|---|---:|---:|---:|']
    for model in ['source','adapted']:
        def acc(policy,budget):return next(x['accuracy'] for x in r['test'] if x['model']==model and x['policy']==policy and x['budget']==budget)
        lines.append(f'| {model} | {100*acc("none",0):.2f}٪ | {100*acc("random",2):.2f}٪ | {100*acc("uncertainty",2):.2f}٪ |')
    lines+=['','تصادفی با پنج بذر ثابت اجرا شد؛ پیش از بازنمونه‌گیری، نتایج بذرها درون هر نظریه میانگین شدند. هر برچسب معنایی فقط برای همان قاعده وارد می‌شد و میان تمام پرسش‌های آن نظریه به اشتراک گذاشته شد. برچسب پاسخ پرسش هدف به روش داده نشد.','']
    for c in r['test_comparisons'][:3]:
        lo,hi=c['cluster_95_ci'];lines.append(f'- {c["method"]} در برابر {c["comparator"]}: {100*c["gain"]:+.2f} واحد درصد؛ بازه اکتشافی [{100*lo:+.2f}، {100*hi:+.2f}].')
    lines+=['','در بررسی داخلی دیگری، ۲۷ نظریه توسعه با ۴۵۲ پرسش و بدون هم‌پوشانی با واحدهای ۶۴+۳۲ برچسب کنار گذاشته شد. عدم‌قطعیت با بودجه ۲ به ۱۰۰٪ رسید؛ تصادفیِ مدل سازگارشده ۹۸٫۹۴٪ بود. حجم این بررسی کوچک است و بازه اختلاف صفر را لمس می‌کند؛ آن را تأیید قاطع یا تکرار بیرونی نمی‌نامیم.','',
    '## توضیح معتبر نسبت به چه چیزی؟','',
    f'در آزمون جزءبه‌جزء، {proof["derived_literal_proofs"]} مورد دارای استنتاجِ گزاره مثبت بود. اجرای شاهدهای مدل معتبر بود؛ اما ۲۴ مورد، تفسیری از قاعده را به کار می‌برد که با منطق مرجع تفاوت داشت. از این موارد، {proof["certified_proofs"]} شاهد فقط به حقایق آماده و قواعدی متکی بود که تفسیرشان با پرس‌وجو تأیید شده بود؛ در این زیرمجموعه اختلافی ثبت نشد. این نتیجه مشروط به درستی حقایق آماده و مرجع پاسخ‌گو است.','',
    'توضیح‌های قابل خواندن، هر گام را به‌صورت «حقیقت ساخت‌یافته آماده»، «تفسیر تأییدشده با پرس‌وجو» یا «تفسیر عصبی تأییدنشده» نشان می‌دهند. در مسیر متن خام، هیچ‌کدام را تأیید انسانی خودکار نمی‌نامیم؛ توافق با منطق رسمی فقط یک ممیزی پژوهشی است.','',
    '## ممیزی و بازتولید','',
    'شناسه‌های عددی داده در سطح هر بخش هستند و میان train/dev/test تکرار می‌شوند. ممیزی بر اساس شناسه تنها، اشتباه بود و اصلاح شد. هیچ متن نظریه یکسان و هیچ برنامه رسمی یکسانی بین آموزش و آزمون پیدا نشد. متن ۹۶ واحد برچسب‌خورده نیز در آزمون تکرار نشده بود. خطای ممیز شناسه، وزن‌ها یا پیش‌بینی‌های مدل را تغییر نداد و گزارش آن حفظ شد.','',
    'تمام ۸٬۰۰۸ پیش‌بینی متن خام دوباره از ورودی خام محاسبه شد. ۶٬۷۴۸ رد انتخابِ آزمون اولیه از نظر بودجه و تغییرکردنِ فقط واحدهای پرسیده‌شده کنترل شد. وزن‌ها، داده، نسخه منبع، هش‌ها، تقسیم‌ها، شکست مسیرهای اضافی و نمونه توضیح‌ها در بسته‌اند. ۴۴ آزمون پیاده‌سازی پاس شد. همه اجراها روی CPU بودند.','',
    '## مقاله و محدودیت ادعا','',
    'پیش‌نویس یکپارچه انگلیسی در manuscript/PILOT_MANUSCRIPT.md نوشته شد. عنوان اصلی حفظ شده، اما متن آن صریحاً یک مطالعه مقدماتی است. این نتایج، برتری نسبت به مدل‌های زبانی قوی بازتولیدشده، ضرورت جزء عصبی، فهم عمومی زبان، انتقال موفق به FOLIO، نوآوری الگوریتمی یا آمادگی ارسال Q1 را اثبات نمی‌کنند. شکست FOLIO در مرحله قبل همچنان برقرار است.','',
    'داده ParaRules بازنویسی انسانی دارد، اما ویژگی‌های اصلی واژگان در آن حفظ شده‌اند و ساختار آن محدود است. نتیجه ۱۰۰٪ برای این معیار، نتیجه ۱۰۰٪ روی زبان طبیعی عمومی نیست. استفاده از تمام متن بدون برچسبِ آموزش مقصد برای استخراج نام‌ها نیز مانع نام‌گذاری این مسیر به‌عنوان zero-shot خالص می‌شود.','',
    'منابع اولیه: Clark, Tafjord & Richardson (IJCAI 2020)، https://www.ijcai.org/Proceedings/2020/0537.pdf ؛ Tafjord et al. (Findings ACL 2021)، https://aclanthology.org/2021.findings-acl.317.pdf . هیچ عدد منتشرشده‌ای به‌عنوان نتیجه اجرای خودمان وارد نشده است.','']
    Path('reports/TRANSFER_COMPLETE_FA.md').write_text('\n'.join(lines))
    manuscript='''# Dynamic Neural-Symbolic Reasoning Framework for Cross-Domain Knowledge Integration and Explainable Natural Language Understanding

**Working pilot manuscript — not a submission-ready or novelty-validated paper.** The title records the project's intended objective. The evidence below concerns controlled-language and paraphrased-rule transfer, not general cross-domain natural-language understanding.

## Abstract

We implement and audit components of an adaptive neural-symbolic reasoning pipeline, distinguishing answer accuracy, program interpretation and executed explanations. A source-trained neural role tagger is combined with typed program decisions and targeted semantic annotations. In an isolated ParaRules rule-transfer experiment, 64 target training annotations and 32 validation annotations support model adaptation; requesting two rule interpretations per theory yields 98.96% answer accuracy versus 97.25% for equal-budget random selection. However, a transparent positional baseline reaches 99.04%, invalidating a general advantage claim for that configuration. A subsequent fixed-design check on 937 unused theories finds no benefit from the proposed committee extension. A simpler raw-text pipeline then recovers all reference programs and answers all 8,008 official test questions correctly, under a closed attribute vocabulary and the dataset's positive-theory conventions. An entirely symbolic query-parser ablation matches this result. These findings support interface-level correctability and reproducible program proofs while showing that this benchmark does not establish neural necessity or general semantic transfer.

## 1. Introduction

The project seeks to integrate adaptable symbolic knowledge with inspectable natural-language reasoning. Three distinctions are essential. A correct answer need not imply a correct interpretation of every rule. A logically valid proof can be faithful to an erroneous parsed program. Finally, an apparent gain over a weak reference may disappear when a simpler structural baseline is added.

We study these distinctions through a sequence of explicitly scoped pilots. Earlier controlled-English experiments established executable program decisions and a learned token-role front end. The present experiments transfer rule interpretation to crowdworker paraphrases, test equal annotation budgets, audit stronger alternatives and evaluate a raw-text baseline. We preserve negative outcomes rather than selecting only favorable comparisons. The implemented mechanisms are established engineering tools; this manuscript does not claim a new acquisition principle or a completed novel framework.

## 2. Related work and scope

RuleTaker studies reasoning over language and includes ParaRules, where crowdworkers rephrase attribute-preserving fact groups and rules [1]. ProofWriter generates implications and associated inference steps, motivating faithful computational explanations [2]. Our public source subset is distributed by the Logic-LM authors [3]; we do not reproduce Logic-LM model outputs. The expected-risk query criterion used in earlier pilots is an application of expected-error reduction [4], not a newly invented principle.

These publications motivate the tasks, not a claim that their end-to-end models were reproduced. In particular, the isolated rule experiment supplies formal facts and query meanings and is not comparable to a full-text language-model score. The raw-text experiment removes those supplied interpretations but retains closed-vocabulary and dataset-order assumptions. An exhaustive novelty review and a fair contemporary language-model comparison remain outside this pilot.

## 3. Implemented system

### 3.1 Learned semantic interface

A 64-unit MLP predicts token roles within facts and rule antecedents/conclusions. It uses lexical, local-window and position features, with a typed copying decoder. Source supervision is distilled from a fixed grammar. Model selection uses 2,821 training and 773 sentence-disjoint validation utterances. The selected model is frozen before neural test evaluation. Typed decoding raises source answer accuracy from 98.67% to 100% on the 600-record source test; a matched linear-parser control also reaches 100%. Thus this result supports the decoder rather than superiority of a nonlinear architecture.

### 3.2 Isolated rule-language transfer

The destination is the official NatLang/ParaRules release. This subexperiment supplies structured facts, query meanings and approximate rule units to every method. Units are constructed using the upstream rule count and sentence boundaries, then audited for attribute alignment. All 482 test theories remain in the primary evaluation, including 26 not fully aligned theories. Missing interpretations are flagged; an unavailable annotation consumes its allocated unit without correction.

The shared decoder assumes one positive unary implication per supplied unit, with a consequent chosen among mentioned source-vocabulary attributes and the remaining attributes used as antecedents. The source MLP is updated using 64 target rule interpretations with source replay. Thirty-two disjoint target interpretations select among 1, 5 and 20 update epochs; epoch 20 is fixed before transfer-test outcomes are evaluated. Counts describe labels used for learning/model selection, not empirically measured human annotation cost. Dataset eligibility auditing itself uses available canonical metadata.

### 3.3 Semantic correction and proof status

At inference, a policy requests up to two rule interpretations per theory and shares each response across that theory's questions. Random selection uses five fixed seeds; uncertainty uses normalized neural head entropy. Only the requested rule may be replaced by its canonical interpretation. No target answer label is queried.

Every answer is evaluated through one executable program. Positive-literal derivations retain their source facts, rules and bindings. A separate checker validates those steps. We label whether a cited rule interpretation was explicitly queried; model-relative validity is not equated with agreement with the source reference. Because alternative proofs can coexist, we do not require deletion of every cited rule to flip the answer.

### 3.4 Stronger baselines and raw-text path

A late structural control chooses the last mentioned attribute as the rule head. Its stronger result motivates a fixed committee follow-on, evaluated on 937 previously unused training-partition theories excluding all target training/validation rule strings. This follow-on has no accuracy benefit over its lexical base.

The raw-text baseline separately induces names from high-frequency capitalized words in unlabeled destination training text. It extracts positive fact attributes within the named-person prefix, carries singular pronouns forward, and interprets subsequent rule units using the last-attribute prior. Low-attribute continuation fragments are merged with the preceding unit. The source-trained neural model interprets the templated question. No gold facts, query meanings, rule count or logical formulas are passed to this predictor. A fully symbolic question-parser ablation is also reported. This path is target-aware and uses unlabeled destination text; it is not strict zero-shot transfer.

## 4. Data and evaluation

The destination release contains 1,681 training, 240 development and 482 test theories, with 8,008 official test questions. Selected training/validation rule strings do not occur exactly in test. Upstream numeric IDs are partition-local: IDs repeat across splits even though raw contexts and canonical programs do not. Checks therefore use split-qualified identifiers and content signatures.

ParaRules uses binary closed-world answers. Absence of a positive literal can support a closed-world response without deriving its explicit negation. We keep this distinct from the earlier three-way open-world source task. Random-query seeds are averaged within theory before 1,000 paired theory-cluster bootstrap resamples. Reported intervals are exploratory, not multiplicity-adjusted superiority tests. The 27-theory internal check is small and not external replication. Training-seed uncertainty is not measured.

## 5. Results

In the isolated interface, the frozen source model scores 96.94%; target adaptation without inference annotations scores 96.39%. Adaptation alone therefore has no demonstrated benefit. With two semantic annotations, adapted uncertainty selection scores 98.96% and adapted random selection averages 97.25%. Their difference is 1.71 percentage points, with exploratory paired-theory interval [1.19, 2.25]. The same-budget frozen-model uncertainty control scores 98.34%. A small internal holdout yields 100% for adapted uncertainty and 98.94% for random, but its interval touches zero.

The last-attribute baseline scores 99.04% in that isolated interface. On the subsequent 937-theory, 15,624-question cohort, the lexical base and all committee-correction policies score 99.12%; no added value is observed. These failures remain part of the evidence.

The raw-text path answers all 8,008 official test questions correctly and exactly matches every reference program and query interpretation. The symbolic question-parser control matches its answer accuracy. All 4,004 derived-positive-literal cases pass program proof checks and reference-program support checks. The remaining 4,004 cases receive independently checked least-closure absence certificates rather than fabricated positive proofs. The certificates verify inclusion of premises, derivability of closure members and closure under all relevant rule instances.

These results do not establish neural necessity. They show that the benchmark's structural regularities permit a stronger transparent baseline than the earlier neural-transfer configuration. All raw-text predictions are recomputed without supplied gold interpretations. The source vocabulary, unlabeled-target name induction and predictor source are included for inspection.

## 6. Explanation analysis

The isolated adapted uncertainty run contains 3,923 question cases with a positive-literal derivation. All computed proofs are internally valid, yet 24 use rule interpretations that disagree with the canonical reference. Among 1,371 proof cases whose rule interpretations were all queried, no such disagreement occurs. This is conditional on trusted reference annotations and supplied facts; it is not a learned human-semantic guarantee.

The raw-text path agrees completely with this dataset's canonical programs. That agreement does not prove that arbitrary natural-language narratives have been understood correctly. Nor does a finite Horn closure certificate establish validity in general first-order logic. Source interpretation and computational inference remain separately auditable.

## 7. Limitations and relation to the intended framework

The intended title is broader than the present evidence. Transfer here concerns linguistic style within a familiar attribute ontology, not new professional domains or arbitrary new predicates. The raw parser assumes positive theories, a closed attribute vocabulary, named fact groups before universal rules and attribute-preserving paraphrases. The later full-text design follows earlier component-level results on the same benchmark; it is an exploratory result, not a new external confirmation corpus. More varied FOLIO text remains unsupported in the preceding learned-parser study.

No published large-language-model baseline is rerun under matched assumptions. No human explanation ratings or inter-annotator agreement are available. The full differentiable reasoning layer, automatic verifier-gated text rule induction and counterfactual training objective from the original proposal are not implemented by these pilots. A model-independent structural parser matching or exceeding neural configurations prevents a generic neural-superiority claim. The observation that a useful baseline is simple does not establish its novelty; a complete prior-art review remains necessary.

## 8. Conclusion

The pilots yield executable, correctable reasoning and a reproducible raw-text ParaRules baseline, while rejecting unsupported claims about neural advantage. The practical outcome is a transparent implementation with separate interpretation, inference and explanation checks. A publishable general framework still requires a distinct research contribution and evidence on less structurally constrained language; the present findings should be treated as validated engineering evidence and benchmark analysis rather than a completed Q1 claim.

## References

1. Clark, P., Tafjord, O., Richardson, K. (2020). *Transformers as Soft Reasoners over Language*. IJCAI, 3882–3890. DOI: 10.24963/ijcai.2020/537. https://www.ijcai.org/Proceedings/2020/0537.pdf
2. Tafjord, O., Dalvi, B., Clark, P. (2021). *ProofWriter: Generating Implications, Proofs, and Abductive Statements over Natural Language*. Findings ACL, 3621–3634. DOI: 10.18653/v1/2021.findings-acl.317. https://aclanthology.org/2021.findings-acl.317/
3. Pan, L., Albalak, A., Wang, X., Wang, W. Y. (2023). *Logic-LM: Empowering Large Language Models with Symbolic Solvers for Faithful Logical Reasoning*. Findings EMNLP. Author data/code repository: https://github.com/teacherpeterpan/Logic-LLM .
4. Roy, N., McCallum, A. (2001). *Toward Optimal Active Learning through Monte Carlo Estimation of Error Reduction*. ICML. https://groups.csail.mit.edu/rrg/papers/icml01.pdf
'''
    Path('manuscript/PILOT_MANUSCRIPT.md').write_text(manuscript)
    print('Consolidated Persian report and complete factual pilot manuscript written.')

if __name__=='__main__':main()
