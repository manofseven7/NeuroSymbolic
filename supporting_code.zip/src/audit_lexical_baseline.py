import json
from pathlib import Path
import transfer_rules as x
from transfer_committee import lexical

def main():
    p=Path('results/transfer_v1');data=json.loads((p/'prepared.json').read_text());vocab=set(json.loads((p/'data_audit.json').read_text())['selected']['vocabulary']);rows=[]
    for r in data['test']:
        asts=[lexical(s,vocab) for s in r['units']]
        for q in r['questions']:
            answer,*_=x.infer(r['facts'],r['units'],asts,q['query']);rows.append(dict(theory_id=r['id'],question_id=q['id'],correct=int(answer==q['answer'])))
    result=dict(status='post-result transparent lexical baseline,no tuning;goldfacts/query andsameunitinterface',rule='Last mentioned source-vocabulary attribute is head;all other distinct mentioned attributes antecedents',accuracy=sum(r['correct'] for r in rows)/len(rows),rows=rows)
    (p/'audit/lexical_baseline.json').write_text(json.dumps(result,indent=2));print(result['accuracy'])

if __name__=='__main__':main()
